/* $Id: passiveTCP.c,v 1.1 2001/10/23 21:30:02 eric Exp $ */

/* SUMMARY
 *
 * passiveTCP.c - passiveTCP 
 *
 * Create a passive socket for use in a TCP server
 * From Comer, Internetworking with TCP/IP Vol III, Linux/POSIX Version
 *
 *
 * REVISION HISTORY
 *
 * $Log: passiveTCP.c,v $
 * Revision 1.1  2001/10/23 21:30:02  eric
 * Initial revision
 *
 */

int	passivesock(const char *service, const char *transport,
		int qlen);

int passiveTCP(const char *service, int qlen)
/*
 * Arguments:
 *      service - service associated with the desired port
 *      qlen    - maximum server request queue length
 */
{
	return passivesock(service, "tcp", qlen);
}
