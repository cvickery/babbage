/* $Id: errexit.c,v 1.1 2001/10/23 21:30:02 eric Exp $ */

/* SUMMARY
 *
 * errexit.c - errexit
 *
 * Print an error message and exit
 * From Comer, Internetworking with TCP/IP Vol III, Linux/POSIX Version
 *
 *
 * REVISION HISTORY
 *
 * $Log: errexit.c,v $
 * Revision 1.1  2001/10/23 21:30:02  eric
 * Initial revision
 *
 */


#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

int errexit(const char *format, ...)
{
	va_list	args;

	va_start(args, format);
	vfprintf(stderr, format, args);
	va_end(args);
	exit(1);
}
