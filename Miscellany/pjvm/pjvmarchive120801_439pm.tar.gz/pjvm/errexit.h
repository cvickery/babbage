/* $Id: errexit.h,v 1.1 2001/10/23 21:30:02 eric Exp $ */

/* SUMMARY
 *
 * errexit.h - errexit header
 *
 * Print an error message and exit
 * From Comer, Internetworking with TCP/IP Vol III, Linux/POSIX Version
 *
 *
 * REVISION HISTORY
 *
 * $Log: errexit.h,v $
 * Revision 1.1  2001/10/23 21:30:02  eric
 * Initial revision
 *
 */

#ifndef ERREXIT_H
#define ERREXIT_H

int errexit(const char *format, ...);

#endif
