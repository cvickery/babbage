/* $Id: connectTCP.h,v 1.1 2001/10/23 21:30:02 eric Exp $ */

/* SUMMARY
 * connectTCP.h - connectTCP header
 *
 * Connect to a specified TCP service on a specified host.
 * From Comer, Internetworking with TCP/IP Vol III, Linux/POSIX Version
 *
 *
 * REVISION HISTORY
 *
 * $Log: connectTCP.h,v $
 * Revision 1.1  2001/10/23 21:30:02  eric
 * Initial revision
 *
 */

int	connectsock(const char *host, const char *service,
		const char *transport);

int connectTCP(const char *host, const char *service );
/*
 * Arguments:
 *      host    - name of host to which connection is desired
 *      service - service associated with the desired port
 */
