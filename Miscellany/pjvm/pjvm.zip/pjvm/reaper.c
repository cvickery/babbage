/* $Id: reaper.c,v 1.1 2001/10/23 21:30:02 eric Exp $ */

/* SUMMARY
 *
 * reaper.c - reaper
 *
 * Cleans up zombie children
 * From Comer, Internetworking with TCP/IP Vol III, Linux/POSIX Version
 *
 *
 * REVISION HISTORY
 *
 * $Log: reaper.c,v $
 * Revision 1.1  2001/10/23 21:30:02  eric
 * Initial revision
 *
 */

#define _USE_BSD
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>

/*  Function reaper()
 *  --------------------------------------------------------------------
 *
 *    Cleans up zombie children.
 *
 */

void reaper( int sig )
{
   int status;
   while( wait3( &status, WNOHANG, ( struct rusage * ) 0 ) >= 0 )
      /* empty */;
}
