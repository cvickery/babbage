/* $Id: passiveTCP.h,v 1.1 2001/10/23 21:30:02 eric Exp $ */

/* SUMMARY
 *
 * passiveTCP.h - passiveTCP header
 *
 * Create a passive socket for use in a TCP server
 * From Comer, Internetworking with TCP/IP Vol III, Linux/POSIX Version
 *
 *
 * REVISION HISTORY
 *
 * $Log: passiveTCP.h,v $
 * Revision 1.1  2001/10/23 21:30:02  eric
 * Initial revision
 *
 */


int	passivesock(const char *service, const char *transport,
		int qlen);

int passiveTCP(const char *service, int qlen);
