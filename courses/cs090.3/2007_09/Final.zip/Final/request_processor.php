<?php

require_once('strip_quotes.php');

	class Datas
	{
		public $name, $email, $passwd;
		public function __construct($email, $passwd, $name = '')
		{
			$this->email = $email;
			$this->passwd = $passwd;
			$this->name = $name;
		}
	}

	if (isset($_SERVER) && array_key_exists('REQUEST_METHOD', $_SERVER) 
			&& $_SERVER['REQUEST_METHOD'] === 'POST')
	{
		$infoStr = $_POST['info'];
		$infoObj = json_decode($infoStr);
		$replyObj = new Datas($infoObj->email, $infoObj->passwd, "Christopher Vickery");
		$replyStr = json_encode($replyObj);
		echo $replyStr;
	}