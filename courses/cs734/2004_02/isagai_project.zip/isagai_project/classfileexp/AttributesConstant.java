// Assignment 4 - AttributesConstant.java
// Created on: 3/14/04

/** Defines Attributes in Constant pool entries
  *  
  *@author Itoe Sagai
  *     
  *******************************************************************/

  public interface AttributesConstant
  {
    static final int CONSTANT_VALUE = 0; 
    static final int CODE = 1;
    static final int EXCEPTIONS = 2;
    static final int INNER_CLASSES = 3;
    static final int SYNTHETIC = 4;
    static final int SOURCEFILE = 5;
    static final int LINE_NUMBER_TABLE = 6;
    static final int LOCAL_VARIABLE_TABLE = 7;
    static final int DEPRECATED = 8;
    static final int ATTRIBUTES_TABLE_LENGTH = 9;
  }    

