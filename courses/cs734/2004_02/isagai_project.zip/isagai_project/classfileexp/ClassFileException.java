// Assignment 4 
// 11/02/01

/********************************************************************
  * Exception used by ClassFile class
  *
  * @author Itoe Sagai
  *
  */


  public class ClassFileException extends Exception
  {

    /*****************************************************************
     * Default no arg constructor
     *
     * @param none
     *
     ****************************************************************/
  
    ClassFileException ()
    {
      super("Something wrong with Class File.");
    }

    /*****************************************************************
     * Constructor
     * 
     * @param msg Message associated with an exception
     * 
     ****************************************************************/
   
    ClassFileException (String msg)
    {
      super(msg);
    }
  }


