/*
 * Method.java
 *
 * Created on February 4, 2004, 4:47 PM
 */

import java.io.*;

/** A method in Java class file
 *
 *
 * @author Itoe Sagai
 *
 *******************************************************************/

class Method implements ConstantPoolTag, AttributesConstant, 
    ClassFileConstant,Access_Flags


{
    
    ClassFile class_file; ;  //a class in which this method belongs to
    //ConstantPoolEntry [] cp_table;
    //MethodEntry method_entry;
    int access_flags;
    int name_index;
    //    String field_name;
    int descriptor_index;
    int attributes_count;
    Attribute [] attribute_table;
    
    
    int name_type_index = 0;
    int method_ref_index = 0;
    //int methodOffsetEnd = 0;
    
    String name = "";   //name of the method
    String descriptor = ""; //descriptor
    
    int code_offset = 0;      
    // code offset computed from the beginning of a class
    int code_length = 0; // length of opcode
    int num_param = 0; // number of parameters
    int return_type =0;  //return type
    //return_type
    int num_locals = 0;  // number of local variables
    int max_stacks = 0;
    byte[] code = null;
    
    
    /*****************************************************************
     * A constructor for a method in Java Class file
     *
     * @param   dis Data Input Stream object represending class file.
     * @param   cf class file to which this method belongs
     * @return  none
     * @throws  ClassFileException in case of IO Error or unsupported
     *          encoding error.
     ****************************************************************/
    
    public Method(DataInputStream dis, ClassFile cf)
    // MethodEntry method_entry)
    throws ClassFileException
    
    {
        try {
            
            
            class_file  = cf;
           
            access_flags = dis.readUnsignedShort();
            name_index = dis.readUnsignedShort();
            descriptor_index = dis.readUnsignedShort();
            attributes_count = dis.readUnsignedShort();
            
            // check access flags
            if ((access_flags & ACC_STATIC) != 0)
                System.out.println(name +"--this is static method" );
            else
                System.out.println(name 
                    +"--this is NOT static method" );
            
            //update method entry table in a class file
            
            name=class_file.cp_table[name_index].utf8_string;
            descriptor
                =class_file.cp_table[descriptor_index].utf8_string;
            //num_param = countParameter( descriptor);
            decomposeDescriptor(descriptor);
            
            //System.out.println("hello2"  );
            // find a name and type reference in constant pool
            
            for (int i = 1; i < class_file.cp_table.length; i++) {
                
                //System.out.println("hello in loop"+i  );
                if (class_file.cp_table[i].tag 
                    == CONSTANT_NameAndType) {
                    //System.out.println("hello in if"   );
                    if (class_file.cp_table[i].name_index 
                        == name_index &&
                        class_file.cp_table[i].descriptor_index 
                        == descriptor_index) 
                    {
                        name_type_index
                            =class_file.cp_table[i].cpIndex;
                        break;
                    }
                }
                
                if ( class_file.cp_table [i].isTwoEntries()) {
                    i++;
                    
                }
            }
            // System.out.println("hello"  );
            // find a method reference in constant pool
            for (int i = 1; i < class_file.cp_table.length; i++) {
                if (class_file.cp_table[i].tag == CONSTANT_MethodRef)
                {
                    if (class_file.cp_table[i].name_and_type_index 
                        == name_type_index) {
                        if (class_file.cp_table[i].class_index 
                            == class_file.this_class) {
                  //method_entry.index=class_file.cp_table[i].cpIndex;
                            method_ref_index 
                                = class_file.cp_table[i].cpIndex;
                            class_file.cp_table[i].method = this;
                            break;
                        }
                        else {
                            System.out.println(name +
                            "--a method of other classes "
                            + " is not supported at this time");
                        }
                        
                    }
                }
                
                if ( class_file.cp_table [i].isTwoEntries()) {
                    i++;
                    
                }
            }
            
            
            // methodOffsetEnd+=8;
            attribute_table = new Attribute[attributes_count];
            for (int i = 0; i < attributes_count; i++) {
                attribute_table [i] = new Attribute( dis, class_file);
                if (attribute_table [i].attribute_type ==CODE) {
                    
                    
                    code_length = attribute_table [i].code_length;
                    num_locals = attribute_table [i].max_locals;
                    max_stacks = attribute_table [i].max_stack;
                    code =attribute_table [i].code;
                    
                }
                //   methodOffsetEnd += attribute_table[i].getOffSet();
            }
            //methodOffsetEnd = offset;
            //System.out.println( method_entry );
            
           /*
            if (method_entry.name.equals("<init>"))
                cf.startInit = method_entry.code_offset;
            
            // class initializer
            if (method_entry.name.equals("<clinit>"))
                cf.startClinit = method_entry.code_offset;
            
            // class initializer
            if (method_entry.name.equals(CLASS_MAIN))
                cf.startMain = method_entry.code_offset;
            */
            
            
        }
        catch (IOException ioe) {
            throw new ClassFileException(ioe.toString());
        }
        
    }
    
    
    
    
    /*****************************************************************
     *
     * Returns an offset(length) in bytes of a start of code
     *
     * @param  none
     * @return offset or length in bytes
     *
     ****************************************************************/
    
    public int getCodeOffset() {return code_offset;}
    
    /****************************************************************
     *
     * Returns name index in constant pool entry
     *
     * @param   none
     * @return  name index in constant pool entry
     *
     *
     ****************************************************************/
    
    
    public int getName_index() {return name_index;}
    
    /****************************************************************
     *
     * Returns descriptor index in constant pool entry
     *
     * @param   none
     * @return  descriptor index in constant pool entry
     *
     *
     ****************************************************************/
    
    
    public int getDescriptor_index() {return descriptor_index;}
    
    
   
    
    /****************************************************************
     *
     * computes number of parameters and return type from a descriptor
     *
     * @param   descriptor a descriptor of this method
     * @return  void
     *
     *
     ****************************************************************/
    
    public void decomposeDescriptor(String descriptor) {
        String msg = "";
        int num=0;
        if ((access_flags & ACC_STATIC) != 0)
            num=0;
        else
            num=1;
        
        int i =1;  //skip the first character '('
        
        while (descriptor.charAt(i)!=')') {
            
            // array
            if (descriptor.charAt(i)=='[') {
                //skip until base type is found
                i++;
                while (descriptor.charAt(i)=='[') {
                    i++;
                }
                num++;
                
                //skip one if not L
                if (descriptor.charAt(i)=='L') {
                    i++;
                    while (descriptor.charAt(i)!=';') {
                        i++;
                    }
                    i++;
                }
                else {
                    i++;
                }
            }
            
            else if (descriptor.charAt(i)=='L') {
                i++;
                while (descriptor.charAt(i)!=';') {
                    i++;
                }
                i++;
                num++;
                
            }
            
            // long or double
            else if(descriptor.charAt(i)=='D' 
                || descriptor.charAt(i)=='J' ) {
                i++;
                num=num+2;
            }
            
            else {
                i++;
                num++;
            }
            
        }
        num_param= num;
        i++;  // skip )
        switch (descriptor.charAt(i)) {
            case 'V':
                return_type = 0;//void
                break;
            case 'B':
                return_type = 1; //byte or char
                break;
            case 'C':
                return_type = 1; //byte or char
                break;
            case 'S':
                return_type = 2; //short
                break;
            case 'I':
                return_type = 4; //int, boolean, reference, float
                break;
            case 'Z':
                return_type = 4; //int, boolean, reference, float
                break;
            case '[':
                return_type = 4; //int, boolean, reference, float
                break;
            case 'L':
                return_type = 4; //int, boolean, reference, float
                break;
            case 'F':
                return_type = 4; //int, boolean, reference, float
                break;
            default:
                return_type = 8; //double and long
                
                
                
        }
        
        
    }
    
    
    
    
    /****************************************************************
     *
     * Returns a string representation of a method
     *
     * @param   none
     * @return  a string representation of a method
     *          
     *
     ****************************************************************/
    
    public String toString() {
        String str ="\n";
        
        str = "method name: " +name;
        str += "\n"+ " descriptor: " + descriptor;
        str += "\n"+ " local variables: " + num_locals;
        str += "\n"+ " stack size: " + max_stacks;
        str += "\n"+ " return type: " + return_type;
        str += "\n"+ " parameters: " + num_param;
        str += "\n"+ " code length: " + code_length;
        str += "\n"+ " code start address: " + code_offset;
        
        return str;
        
    }
}
