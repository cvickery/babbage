// Assignment 4 - Project to analyze Class file format
// Created on : 11/2/2001
//
// modified - Spring 2004 for JVM project


import java.io.*;
import java.util.*;


/** a class representing a Java class file
 *
 *
 * @author Itoe Sagai
 *
 */


public class ClassFile extends File implements Access_Flags,
    AttributesConstant,ConstantPoolTag, ClassFileConstant{
    
    // define instance variables
    //
    ConstantPoolEntry [] cp_table;
    // a table of constant pool entries
    
    //MethodEntry [] methodEntryTable;
    
    
    // a table of methods
    Vector fileList;
    Vector classNameTable;
    
    int  minorVersion,    // u2 minor version number
    majorVersion,    // u2 major version number
    numEntries,      // u2 number of entries
    //    in constant pool
    access_flags,    // u2 access permission
    this_class,      // u2 index to constant pool
    super_class,     // u2 index to constant pool
    interface_count, // u2 no of direct superinterfaces
    
    
    fields_count,     // u2 no of FieldInfo objects
    methods_count,     // u2 no of MethodInfo objects
    attributes_count, // u2 no of AttributeInfo objects
    offset;          // offset in byte -- total length
    
    // essential info
    int startaddress = 0;   //
    int startInit = 0;
    int startClinit = 0;
    int startMain = 0;
    int classSize = 0;
    int max_stacks = 0;
    int max_locals = 0;
    int max_frames = 0;
    int cp_table_size = 0;  
        //the size of constant pool table in a loaded file
    int m_table_size =0;    
        //the size of methods table in a load file
    int static_fields_size = 0;
        //the size of static fields in a load file
    
    //int static_field_memory_size = 0;
    
    
    
    int [] interfaces;    // array of index to constant pool
    Field [] field_table;  // array of class fields
    Method [] method_table;  // array of methods
    Attribute [] attribute_table;  // array of class attributes
    
    int attributesIndex [];
    // mapping of attributes name and index
    static String attributesName []=
    {"ConstantValue","Code", "Exceptions","InnerClasses",
     "Synthetic","SourceFile","LineNumberTable",
     "LocalVariableTable","Deprecated"};
     
     
     PrintWriter audit = null;  //audit output
     /****************************************************************
      *
      * Constructor to receive a pathname, and test if it is a valid
      * Java class file, and read binary information into
      * instance variables.
      *
      * @param   pathname path/file name
      * @param   classNameTable table containing class name string
      * @param   fileList table containing class files
      *
      * @return  none
      * @throws  ClassFileException if a file is not a valid class
      *          file or in case of IO error
      *
      ***************************************************************/
     
     public ClassFile( String pathName, Vector classNameTable,
     Vector fileList) throws ClassFileException
     
     {
         
         // invoke superclass constructor
         
         super( pathName );
         System.out.println( "****processing a new class file***"
            + pathName);
         this.classNameTable = classNameTable;
         this.fileList =fileList;
         // set offset to 0
         
         offset =0;
         
         attributesIndex = new int [ATTRIBUTES_TABLE_LENGTH];
         
         // Test 1: if the file can be read
         if (! canRead()) {
             throw new ClassFileException(
             "Can not read file \"" + pathName + "\".");
         }
         
         // Test 2: if the file name ends with .java
         if (! getName().endsWith(".class")) {
             throw new ClassFileException(
             "File \"" + pathName             
             + "\" does not end with \".class\".");
         }
         
         // Test 3: if the file's first 4 bytes are 0xcafebabe
         
         try {
             DataInputStream dis = new DataInputStream(
             new FileInputStream( this ));
             
             if (dis.readInt() != 0xcafebabe ) {
                 throw new ClassFileException(
                 "File \"" + pathName + "\" has bad magic numbers.");
             }
             offset +=4;  // read 4 bytes
             // all tests passed, read class file information.
             // read minor & major version numbers
             
             minorVersion = dis.readUnsignedShort();
             majorVersion = dis.readUnsignedShort();
             offset +=4;  // read 4 bytes
             
             // build constant pool entry table
             numEntries = dis.readUnsignedShort();
             offset +=2;  // read 2 bytes
             
             cp_table = new ConstantPoolEntry [ numEntries ];
             
             // initialize the first entry as null
             cp_table[0] = null;
             for (int i = 1; i < numEntries; i++) {
                 cp_table [i] 
                    =new ConstantPoolEntry(dis,this,i,classNameTable);
                 
                 if (cp_table [i].isTwoEntries()) {
                     i++;
                     
                 }
             }
             
             // scan for class names
             
             for (int i = 1; i < numEntries; i++) {
               // System.out.println( "scanning for class names" +i );
                 
                 int cpIndex = -1;
                 
                 if (cp_table[i].tag ==CONSTANT_FieldRef
                 || cp_table[i].tag ==CONSTANT_MethodRef) {
                     int class_index = cp_table[i].class_index;
                     cpIndex =cp_table[class_index].name_index;
                 }
                 
                 if (cp_table[i].tag ==CONSTANT_Class ) {
                     cpIndex =cp_table[i].name_index;}
                 
                 
                 if (cpIndex!=-1 ) {
                     String fileString 
                        = cleanUp(cp_table[cpIndex].utf8_string);
                     fileString+=".class";
                     //System.out.println("check CP="+ fileString );
                     if (isNewClass(fileString)) {
                         classNameTable.add(fileString);
                         System.out.println
                         ("class found in CP- added to a table"
                         + cp_table[cpIndex].utf8_string );
                     }
                     
                 }
                 if (cp_table [i].isTwoEntries()) {
                     i++;
                     
                 }
                 
             }
             
   // scan for entries to keep in a load file and compute a total size
             
             for (int i = 1; i < numEntries; i++) {
                 //System.out.println( "scanning for keep" +i );
                 
                 
                 if (cp_table[i].keep) {
                  cp_table_size = cp_table_size + cp_table[i].cp_size;
                 }
                 
                 
                 if (cp_table [i].isTwoEntries()) {
                     i++;
                     
                 }
                 
             }
             
             System.out.println
                ("size of constant pool is "+ cp_table_size );
             
             
             // print attributes table
             printCPTable();
             printAttributesIndexTable();
             
             //System.out.println(" offset CP:" + offset);
             // read & print access flags
             access_flags = dis.readUnsignedShort();
             offset +=2;  // read 2 bytes
             
             // read this_class, super_class indexes.
             this_class = dis.readUnsignedShort();
             super_class = dis.readUnsignedShort();
             
             // add superclass
             
             
             offset +=4;  // read 4 bytes
             
             // read interface count & create an array
             interface_count = dis.readUnsignedShort();
             offset +=2;  // read 2 bytes
             interfaces = new int [interface_count];
             
             for (int i = 0 ; i < interface_count ; i++) {
                 interfaces [i] = dis.readUnsignedShort();
                 offset +=2;  // read 2 bytes
             }
             
             
             //System.out.println(" offset:" + offset);
             
             // read fields count and create an array
             fields_count = dis.readUnsignedShort();
             offset +=2;  // read 2 bytes
             field_table = new Field [fields_count];
             
             //System.out.println("fcount:"+fields_count+" offset:" +
             //offset);
             
             for (int i = 0 ; i < fields_count ; i++) {
                 field_table  [i] = new Field(dis, this);
                 // field_table  [i].setFieldOffSet(offset);
                 // offset += field_table [i].getOffSet();
                 
                 // check field descriptor
                 
                 // check descriptor
                 
                 int descIndex =field_table[i].descriptor_index;
                 System.out.println
                 ("**decode field descripter for class name*"
                 +descIndex );
                 String fileString =  getFieldDescriptor
                 (cp_table[descIndex].utf8_string);
                 if (fileString != null){
                     fileString+=".class";
                     //System.out.println("check CP="+ fileString );
                     if (isNewClass(fileString)) {
                         classNameTable.add(fileString);
                         System.out.println
                         ("class found in field type-added to a table"
                         + fileString );
                     }
                 }
                 
                 
             }
             
             
             // print field table
             System.out.println("***print field table** " );
             for (int i = 0 ; i < fields_count ; i++) {
                 System.out.println(field_table  [i].toString()  );
             }
             
             
             
             // read methods count and create an array
             methods_count = dis.readUnsignedShort();
             offset +=2;  // read 2 bytesof
             method_table = new Method [methods_count];
             
             
             for (int i = 0 ; i < methods_count ; i++) {
                 
                 method_table  [i] = new Method(dis, this);
                 //offset = method_table [i].getOffset();
                 String methodDescriptors[]= null;
                 
                 String tempDescriptors =
                 cp_table
                  [method_table [i].descriptor_index].utf8_string;
                 
                 methodDescriptors = getMethodDescriptor
                 (tempDescriptors, method_table[i].num_locals+1);
                 
                 
                 
                 for (int j = 0 ; j < methodDescriptors.length ; j++){
                  
                     
                     if (methodDescriptors[j]== null){break;}
                     else{
                         
                         
                         String fileString
                            =methodDescriptors[j]+".class";
                         System.out.println
                            ("check method="+fileString);
                         if (isNewClass(fileString)) {
                             classNameTable.add(fileString);
                             System.out.println
                             ("class found in method descriptor," +
                             "added to table" + fileString );
                         }
                     }
                 }
             }
             
             
             
             // read class attributes count and create an array
             attributes_count = dis.readUnsignedShort();
             offset +=2;  // read 2 bytesof
             attribute_table = new Attribute [attributes_count];
             
             for (int i = 0 ; i < attributes_count ; i++) {
                 attribute_table  [i] = new Attribute(dis, this);
                 offset += attribute_table [i].getOffSet();
                 
             }
             System.out.println("byte code length:"+offset);
         }
         
         catch (IOException ioe) {
             throw new ClassFileException(ioe.getMessage());
         }
     }
     
     
     /****************************************************************
      *
      * Returns name of the class, major & minor version of the file
      *
      * @param   none
      * @return  ClassName, major version and minor version of
      *          the class file
      *
      ***************************************************************/
     
     public String toString() {
         
         return getClassName() + ":" + majorVersion 
         + "." + minorVersion;
         
     }
     
     /****************************************************************
      * returns class name as appears in binary class file
      * using values in this_class and constant pool entries
      *
      * @param  none
      * @return name of a class
      *
      ***************************************************************/
     
     public String getClassName() {
         
         int name_index = cp_table[this_class].getNameIndex();
         return cp_table[name_index].getUtf8_info();
         
     }
     
     /*****************************************************************
      *
      * returns minor version
      * @param  none
      * @return minor version
      *
      ****************************************************************/
     
     public int getMinorVersion() {return minorVersion;}
     
     /*****************************************************************
      *
      * returns major version
      * @param  none
      * @return minor version
      *
      ****************************************************************/
     
     public int getMajorVersion() {return majorVersion;}
     
     /*****************************************************************
      *
      * returns number of entries in constant pool table
      * @param none
      * @return number of entries in constant pool table
      *
      ****************************************************************/
     
     public int getConstantPoolCount() {return numEntries;}
     
     /*****************************************************************
      *
      * returns a value of access flags
      * @param none
      * @return a value of access flags
      *
      ****************************************************************/
     
     public int getAccessFlagsValue() {return access_flags;}
     
     
     /*****************************************************************
      *
      * returns the interpretation of access flags
      * @param access flags value
      * @return the interpretation of access flags
      *
      ****************************************************************/
     
     public String getAccessFlagsInfo() {
         String msg = "";
         if ((access_flags & ACC_PUBLIC) != 0)
             msg = "Declared public:";
         if ((access_flags & ACC_FINAL) != 0)
             msg += "Declared final:";
         if ((access_flags & ACC_SUPER) != 0)
             msg += "Treat superclass methods specially:";
         if ((access_flags & ACC_INTERFACE ) != 0)
             msg += "Type is interface:";
         if ((access_flags & ACC_ABSTRACT ) != 0 )
             msg += "Type is abstract";
         
         return msg;
     }
     
     
     /***************************************************************** 
      *
      * returns a index value of this class
      * @param  none
      * @return a value of this class
      *
      ****************************************************************/
     
     public int getThis_Class() {return this_class;}
     
     /*****************************************************************
      *
      * returns a index value of superclass
      * @param  none
      * @return a value of superclass
      *
      ****************************************************************/
     
     public int getSuper_Class() {return super_class;}
     
     /*****************************************************************
      *
      * returns interface count, a number of direct interfaces
      * @param  none
      * @return interface count
      *
      ****************************************************************/
     
     public int getInterface_Count() {return interface_count;}
     
     /****************************************************************
      *
      * returns Constant Pool Entry array
      * @param none
      * @return constant pool entry array'
      *
      ***************************************************************/
     
     public ConstantPoolEntry [] getConstantPoolEntries() {
         return cp_table;
     }
     
     /****************************************************************
      *
      * returns Field array
      * @param none
      * @return Field array'
      *
      ***************************************************************/
     
     public Field [] getFieldTable() {
         return field_table;
     }
     
     
     /****************************************************************
      *
      * returns Methods array
      * @param none
      * @return Mwthod array
      *
      ***************************************************************/
     
     public Method [] getMethodTable() {
         return method_table;
     }
     
     /****************************************************************
      *
      * prints attributes Index table
      * @param none
      * @return void
      *
      ***************************************************************/
     
     public void printAttributesIndexTable() {
         System.out.println("*** attributes index***"  );
         for (int i = 0; i< ATTRIBUTES_TABLE_LENGTH; i++) {
             
             System.out.println(attributesName[i]+ ":\t"
             + attributesIndex[i]);
             
         }
     }
     
     /****************************************************************
      *
      * prints constant pool table
      * @param none
      * @return void
      *
      ***************************************************************/
     
     public void printCPTable() {
         System.out.println("*** constant pool entries***"  );
         
         for (int i = 1; i < numEntries; i++) {
             System.out.println(cp_table [i].toString());
             
             if (cp_table [i].isTwoEntries()) {
                 i++;
                 
             }
         }
         
     }
     
     
     /****************************************************************
      *
      * check if this class is already created or in a table of
      * "files to be created"
      *
      * @param fileString file name
      * @return ture if not created or in the table, false otherwise
      *
      *
      ***************************************************************/
     
     public boolean isNewClass(String fileString) {
         // first check in file list
         
         boolean found = false;
         // not a file name.
         if (fileString == null)
             return false;
         
         File f;
         
         //System.out.println( "file list size"+ fileList.size());
         for (int i = 0; i< fileList.size();i++){
             f = (File) fileList.get(i);
             String filePath = ClassFileExplorer.path+fileString;
             //System.out.println( "file list in cp"+ f.getName());
             if (filePath.compareTo(f.getPath())==0) {
                 System.out.println( "class file already found " +
                 " -don't add"    + f.getPath());
                 // file found
                 found=true;
                 break;  }
             
         }
         String s;
      //System.out.println( "class list size"+ classNameTable.size());
         if (!found) {
             
             for (int i = 0; i< classNameTable.size();i++){
                 s = (String) classNameTable.get(i);
                 
                 if (fileString.compareTo(s)==0) {
                     System.out.println
                     ( "class name found in classNameTable - don't add" 
                        + s);
                     // file found
                     found=true;
                     break;  }
                 
             }
             
         }
         
         if(found)return false;
         else return true;
     }
     
     
     /****************************************************************
      *
      * clean up to extract class file name with a proper separator
      *
      * @param fileString filename
      * @return filename that has been formatted
      * @throws ClassFileException in case filename doesn't have
      *         a valid class file name
      *
      ***************************************************************/
     
     public String cleanUp(String fileString) throws ClassFileException 
     {
         
         
         // first replace '/' with File.separatorChar
         
         fileString = fileString.replace('/',File.separatorChar);
         // no need to cleanup
         if (fileString.charAt(0)!='[') {
             return fileString;
         }
         if (fileString.charAt(0)=='L' &&
         fileString.charAt(fileString.length()-1)==';') {
             return fileString.substring(1,fileString.length()-2);
         }
         
         
         for (int i = 0; i<fileString.length() ;i++) {
             
             
             if (fileString.charAt(i)=='[') {
                 // just skip
             }
             else if (fileString.charAt(i)=='B' 
             || fileString.charAt(i)=='C' ||
             fileString.charAt(i)=='D' || fileString.charAt(i)=='F' ||
             fileString.charAt(i)=='I' || fileString.charAt(i)=='J' ||
             fileString.charAt(i)=='S' || fileString.charAt(i)=='Z' )
             {
                 return null;}
             
             
             else if (fileString.charAt(i)=='L') {
                 return 
                    fileString.substring(i+1,fileString.length()-2);
             }
             
             
         }
         throw new ClassFileException("invalid class file name-"
         +fileString);
         
     }
     
     /****************************************************************
      *
      * read method descriptor and retrieve class names
      * @param fileString method descriptors
      * @param max maximum number of descriptors in this file string
      * @return String arrq array of class file names
      * @throws ClassFileException in case the number of descriptors
      *         exceeded Max
      *
      ***************************************************************/
     
     
     String[] getMethodDescriptor(String fileString, int max) throws
     ClassFileException
     
     {
         
         String [] descriptors = new String[max];
         
         int count= 0;
         
         
         int i =1;
         
         while (fileString.charAt(i)!=')') {
             String entry = null;
             
             if (fileString.charAt(i)=='[') {
                 i++;
             }
             else if (fileString.charAt(i)=='B' 
             || fileString.charAt(i)=='C' ||
             fileString.charAt(i)=='D' || fileString.charAt(i)=='F' ||
             fileString.charAt(i)=='I' || fileString.charAt(i)=='J' ||
             fileString.charAt(i)=='S' || fileString.charAt(i)=='Z' ) 
             {
                 i++;
             }
             
             
             else if (fileString.charAt(i)=='L') {
                 // then read until;
                 
                 i++;
                 String tempString = "";
                 while (fileString.charAt(i)!=';') {
                     tempString+=fileString.charAt(i++);
                 }
                 
                 tempString 
                 = tempString.replace('/',File.separatorChar);
                 //System.out.println("temp"+tempString);
                 descriptors [count ++]=tempString;
                 //System.out.println("array"+descriptors [count-1]);
                 if (count >= max)
                     throw new ClassFileException
                     ("number of parameters error");
                 i++;
             }
             
             
         }
         // it reached )
         // read return type
         i++;
         if (fileString.charAt(i)=='L') {
             // then read until;
             i++;
             String tempString = "";
             while (fileString.charAt(i)!=';') {
                 tempString+=fileString.charAt(i++);
             }
             
             tempString = tempString.replace('/',File.separatorChar);
             //  System.out.println(tempString);
             descriptors [count]=tempString;
             i++;
         }
         
         return descriptors;
         
         
     }
     
     /****************************************************************
      *
      * decode field descriptor
      * @param fileString field descriptors
      * @return class file names
      *
      ***************************************************************/
     
     public String getFieldDescriptor(String fileString)  {
         
         
         // first replace '/' with File.separatorChar
         
         //fileString = fileString.replace('/',File.separatorChar);
         
         for (int i = 0; i<fileString.length() ;i++) {
             
             
             if (fileString.charAt(i)=='[') {
                 // just skip
             }
             else if (fileString.charAt(i)=='B' 
             || fileString.charAt(i)=='C' ||
             fileString.charAt(i)=='D' || fileString.charAt(i)=='F' ||
             fileString.charAt(i)=='I' || fileString.charAt(i)=='J' ||
             fileString.charAt(i)=='S' || fileString.charAt(i)=='Z' )
             {
                 return null;}
             
             
             else if (fileString.charAt(i)=='L') {
                 String tempString 
                    = fileString.substring(i+1,fileString.length()-2);
                 tempString 
                    = tempString.replace('/',File.separatorChar);
                 return tempString;
             }
             
             
         }
         return null;
         
         
         
     }
     
     
     
     /*****************************************************************
      *
      * allocate memory for each field
      *
      * @param  startOffset  starting position of fields
      * @return offset or length in bytes
      *
      ****************************************************************/
    /*
    public int allocateMemory(int startOffset) {
     
        for (int i = 0; i<field_table.length;i++) {
            if ((field_table [i].access_flags & ACC_STATIC) != 0)
            {
                 System.out.println("static field" );
                 field_table [i].setFieldOffSet(startOffset);
                 startOffset +=field_table [i].field_length;
                 System.out.println("allocating memory for field" );
     
            }
     
     
        }
     
           return startOffset;
     
     
    }*/
     
     /*****************************************************************
      *
      * update pointers in method reference and field reference in
      * constant pool entries
      *
      * @param  startOffset  starting position of fields
      * @return offset or length in bytes
      *
      ****************************************************************/
     
     public void updatePointers() {
         
         for (int i = 1; i<cp_table.length;i++) {
             
             cp_table [i].updatePointer();
             
             if (cp_table [i].isTwoEntries()) {
                 i++;
                 
             }
             
             
         }
         
     }
     /*****************************************************************
      *
      * update start address of constant pool entries used in 
      * a load file
      *
      * @param  start_offset  starting position of fields
      * @return next address
      *
      ****************************************************************/
     
     public int updateCpOffset(int start_address) {
         
         
         
         for (int j = 1; j< cp_table.length;j++){
             if (cp_table[j].keep) {
                 System.out.println("***" );
                 
                 cp_table[j].cp_offset = start_address;
                 System.out.println( cp_table[j].toString());
                 start_address = start_address + cp_table[j].cp_size;
             }
             
             if (cp_table [j].isTwoEntries()) {
                 j++;
                 
             }
             
         }
         
         return start_address;
     }
     
     /*****************************************************************
      *
      * update start address of fields in this class
      *
      *
      * @param  start_offset  starting position of fields
      * @return next address
      *
      ****************************************************************/
     
     public int updateFieldOffset(int start_address) {
         
         
         
         for (int j = 0; j< field_table.length;j++){
             System.out.println("***" );
             System.out.println( field_table[j].toString());
             field_table[j].field_offset = start_address;
             System.out.println( "start address: " 
                + field_table[j].field_offset);
             start_address = start_address 
                + field_table[j].field_length;
         }
         
         return start_address;
     }
     
     /*****************************************************************
      *
      * update start address of methods in this class
      *
      *
      * @param  start_offset  starting position of method
      * @return next address
      *
      ****************************************************************/
     
     public int updateMethodOffset(int start_address) {
         
         
         
         for (int j = 0; j< method_table.length;j++){
             System.out.println("***" );
             System.out.println( method_table[j].toString());
             method_table[j].code_offset = start_address;
             System.out.println( "start address: " 
                + method_table[j].code_offset);
             
             // update class data structure
             
             
             // class initializer
             if (method_table[j].name.equals("<clinit>"))
                 startClinit = start_address;
             
             // class initializer
             else if (method_table[j].name.equals(CLASS_MAIN))
                 startMain = start_address;
             
             start_address = start_address 
             + method_table[j].code_length   + METHOD_HK_LENGTH;
         }
         
         return start_address;
     }
     
     
     /*****************************************************************
      *
      * print data structure area
      *
      *
      * @param  audit_file  output
      * @return void
      *
      ****************************************************************/
     
     public void printDataStructure(PrintWriter audit ) {
         audit.println();
         audit.println("class: " + getClassName());
         audit.println("<clinit> start: " + startClinit);
         audit.println("main start: " + startMain);
         audit.println("Max Stack size: " + max_stacks);
         audit.println("Max local variables size: " + max_locals);
         audit.println("Max frame size: " + max_frames);
         
     }
     
     
     /*****************************************************************
      *
      * print constant pool area
      *
      *
      * @param  audit_file  output
      * @return void
      *
      ****************************************************************/
     
     public void printConstantPool(PrintWriter audit ) {
         audit.println();
         
         for (int j = 1; j< cp_table.length;j++){
             if (cp_table[j].keep ) {
                 audit.print(cp_table[j].toString() );
                 audit.println(", pointer =" + cp_table[j].pointer );
                 
             }
             
             if (cp_table [j].isTwoEntries()) {
                 j++;
                 
             }
         }
         
     }
     /*****************************************************************
      *
      * print method area
      *
      *
      * @param  audit_file  output
      * @return void
      *
      ****************************************************************/
     
     public void printMethods(PrintWriter audit) {
         
         
         
         for (int j = 0; j< method_table.length;j++){
             audit.println("***" );
             audit.println( method_table[j].toString());
             
             byte[] code=method_table[j].code;
             char hex[];
             hex = new char[2];
             
             for (int i = 0; i<code.length ;i++) {
                 
                 hex=ByteUtility.toHex(code[i]);
                 audit.print(hex[0]+" "+hex[1]+"  ");
             }
             
             audit.println(  );
             
         }
         
         
     }
     /*****************************************************************
      *
      * print static fields
      *
      *
      * @param  audit_file  output
      * @return void
      *
      ****************************************************************/
     
     public void printFields(PrintWriter audit) {
         
         
         
         for (int j = 0; j< field_table.length;j++){
             audit.println("***" );
             audit.println( field_table[j].toString());
             
             
             audit.println(  );
             
         }
         
         
     }
     
     /*****************************************************************
      *
      * print method area
      *
      *
      * @param  audit_file  output
      * @return void
      *
      ****************************************************************/
     
     public void resolveMethods(PrintWriter audit) 
        throws ClassFileException {
         
         for (int j = 0; j< method_table.length;j++){
             audit.println("***" );
             audit.println( method_table[j].toString());
             
             
             
             byte[] code=method_table[j].code;
             Decoder d = new Decoder(audit,this);
             
             
             for (int i =0; i<code.length; )
                 i = d.decode(code, i);
             
             char hex[];
             hex = new char[2];
             
             for (int i = 0; i<code.length ;i++) {
                 
                 hex=ByteUtility.toHex(code[i]);
                 audit.print(hex[0]+" "+hex[1]+"  ");
             }
             
             audit.println(  );
             
         }
         
         
     }
     
     /*****************************************************************
      *
      * print constant pool area
      *
      *
      * @param  dos output file
      * @return void
      *
      ****************************************************************/
     
     public void writeConstantPool(DataOutputStream dos )
     throws ClassFileException{
         
         try {
             for (int j = 1; j< cp_table.length;j++){
                 if (cp_table[j].keep ) {
                     
                     switch (cp_table [j].tag) {
                         case CONSTANT_Long:
                             // write 8 bytes
                             ByteUtility.writeEightBytes
                                (cp_table [j].long_info, dos);
                             j++;
                             break;
                         case CONSTANT_Integer:
                             // write 4 bytes
                             ByteUtility.writeFourBytes
                                (cp_table [j].integer_info, dos);
                             break;
                         case CONSTANT_FieldRef:
                             // write 4 bytes
                             ByteUtility.writeFourBytes
                                (cp_table [j].pointer, dos);
                             break;
                         case CONSTANT_MethodRef:
                             // write 4 bytes
                             ByteUtility.writeFourBytes
                                (cp_table [j].pointer, dos);
                             break;
                         default:
                             throw new ClassFileException
                                ("unsupported constants");
                             
                     }
                     
                 }
             }
         }
         catch (IOException ioe) {
             
             throw new ClassFileException(
                "io error writing load file");
         }
         
     }
     /*****************************************************************
      *
      * print method area
      *
      *
      * @param  dos output five
      * @return void
      *
      ****************************************************************/
     
     public void writeMethods( DataOutputStream dos )
     throws ClassFileException{
         
         
         try {
             
             for (int j = 0; j< method_table.length;j++){
                
                 ByteUtility.writeFourBytes
                    (method_table[j].return_type, dos);
                 ByteUtility.writeFourBytes
                    (method_table[j].num_param, dos);
                 ByteUtility.writeFourBytes
                    (method_table[j].code_length, dos);
                 byte[] code=method_table[j].code;
                 
                 
                 for (int i = 0; i<code.length ;i++) {
                     ByteUtility.writeOneByte(code[i], dos);
                     
                 }
                 
                 
             }
         }
         
         catch (IOException ioe) {
             
             throw new ClassFileException
                ("io error writing load file");
         }
     }
     
     
}

