// Assignment 4 ConstantPoolEntry.java
// Created on 11/18/2001


import java.io.*;
import java.util.*;

/** An entry in Constant Pool in Java class file with various data
 * associated to the entry.
 *
 * @author Itoe Sagai
 *
 *******************************************************************/

public class ConstantPoolEntry implements 
    ConstantPoolTag, AttributesConstant {
    
    
    ClassFile class_file;
    
    int cpIndex;  // index in constant pool entry
    int tag;
    int class_index;
    int name_and_type_index;
    int name_index;
    int utf8_length;
    String utf8_string;
    byte [] utf8_info;
    int string_index;
    int integer_info;
    float float_info;
    long long_info;
    double double_info;
    int descriptor_index;
    boolean isTwo = false;
   // int offset;  // used as temporary variable
    int cp_offset; // offset from the beginning of byte code
    Field field= null;  //associated field if this is a field_ref
    Method method = null; //associated method entry  
                                       // if this is a method_ref
    
    String cpInfo;
    
    // following is for resolver
    
    boolean keep = false;  // whether to keep in a load file
                     // only constants and methods should be included
    int cp_size = 0;     // a size of this entry in the load file and 
    int pointer = 0;       // the address of a method or field
    
    /*****************************************************************
     * A constructor for a constant pool entry in Java Class file
     * which will store data in different instance variables depends
     * on a tag value.
     *
     * @param   dis Data Input Stream object represending class file.
     * @param   class_file the class file to which this constant pool 
     *          entry belongs.
     * @param   i the index in constant pool entry
     * @return  none
     * @throws  ClassFileException in case of IO Error or unsupported
     *          encoding error.
     ****************************************************************/
    
    public ConstantPoolEntry(DataInputStream dis, 
        ClassFile class_file, int i,Vector classNameTable )
    throws ClassFileException
    
    {
        this.class_file =class_file;
        this.cpIndex = i;
        
       
        try {
            tag = dis.readUnsignedByte();
            //System.out.print("tag id: "+ tag + " \t");
            
            createEntry(tag, dis);
        }
        
        catch (Exception e) {
            throw new ClassFileException(e.getMessage());
        }
        
    }
    
    
    /*****************************************************************
     * Creates one Constant Pool Entry based on JVM specification.
     *
     * @param  tag specifies a type of constant pool entry to follow
     * @param  dis Data Input Stream object representing a class file.
     * @return void
     * @throws IOException in case of IO error
     *
     ****************************************************************/
    public void createEntry(int tag, DataInputStream dis)
    throws IOException {
        //System.out.println("tag"+tag);
        
        switch (tag) {
            case CONSTANT_Utf8:
                
                //utf8_string = dis.readUTF();
                
                utf8_length = dis.readUnsignedShort();
               
                utf8_info = new byte [utf8_length];
                dis.read(utf8_info);
                String str = new String(utf8_info, 0, utf8_length, 
                    "UTF8");
                utf8_string = str;
                cpInfo = "CONSTANT_Utf8 " + utf8_string ;
                saveAttributesIndex();  // save the index to a table
                break;
                
            case CONSTANT_Integer:
                integer_info = dis.readInt();
                
                cpInfo = "CONSTANT_Integer: " + integer_info;
                keep = true;
                cp_size =4;
                break;
                
            case CONSTANT_Float:
                float_info = dis.readFloat();
                
                cpInfo = "CONSTANT_Float: " + float_info;
                
                keep = true;
                cp_size =4;
                break;
                
            case CONSTANT_Long:
                long_info = ((long) dis.readInt() << 32 ) 
                    + dis.readInt();
                
                isTwo = true;
                cpInfo = "CONSTANT_Long: " + long_info;
                keep = true;
                cp_size =8;
                break;
                
            case CONSTANT_Double:
                long_info = ((long) dis.readInt() << 32 ) 
                    + dis.readInt();
                
                isTwo = true;
                cpInfo = "CONSTANT_Double: " + long_info;
                keep = true;
                cp_size =8;
                break;
                
            case CONSTANT_Class:
                name_index = dis.readUnsignedShort();
                
                cpInfo= "CONSTANT_Class: " + name_index;
                break;
                
            case CONSTANT_String:
                System.out.println("string"+tag);
                string_index = dis.readUnsignedShort();
                
                cpInfo = "CONSTANT_String: " + string_index;
                System.out.println("string"+cpInfo);
                break;
                
            case CONSTANT_FieldRef:
                class_index = dis.readUnsignedShort();
                
                name_and_type_index = dis.readUnsignedShort();
                
                cpInfo = "CONSTANT_FieldRef: " + class_index +
                ", name & type id: " + name_and_type_index;
                
                keep = true;
                cp_size =4;
                break;
                
            case CONSTANT_MethodRef:
                class_index = dis.readUnsignedShort();
                name_and_type_index = dis.readUnsignedShort();
                
                cpInfo = "CONSTANT_MethodRef: " + class_index +
                ", name & type id: " + name_and_type_index;
                
                keep = true;
                cp_size =4;
                break;
                
            case CONSTANT_InterfaceMethodRef:
                class_index = dis.readUnsignedShort();
                
                name_and_type_index = dis.readUnsignedShort();
               
                cpInfo = "CONSTNAT_InterfaceMethodRef: " 
                + class_index +
                "name & type id: " + name_and_type_index;
                keep = true;
                cp_size =4;
                break;
                
            case CONSTANT_NameAndType:
                name_index = dis.readUnsignedShort();
                descriptor_index = dis.readUnsignedShort();
                
                cpInfo = "CONSTANT_NameAndType: " + name_index
                +"-descripter: " + descriptor_index;
                break;
                
            default:
                throw new RuntimeException("bad tag: " + tag);
        }
        
        
        
    }
    
    /*****************************************************************
     *
     * Whether or not this entry uses two tags.
     *
     * @param  none
     * @return true if uses two tags.
     *
     ****************************************************************/
    
    public boolean isTwoEntries() {
        return isTwo;
    }
    
    /*****************************************************************
     *
     * Returns a contant type (tag) of a constant pool entry
     *
     * @param  none
     * @return a constant type (tag value)
     *
     ****************************************************************/
    
    public int getConstantType() {return tag;}
    
  
    /*****************************************************************
     * Returns string representation of an entry
     *
     * @param none
     * @return Type and data for the entry
     *
     ****************************************************************/
    
    public String toString() {
        cpInfo = cpInfo +  ", i="+cpIndex + ", address= "+cp_offset 
        + ", pointer= "+pointer;
        return cpInfo;
    }
    
    /*****************************************************************
     *
     * Returns the value of name index, which is a valid index
     * to a constant pool containing a name of the class
     *
     * @param  none
     * @return name index
     *
     ****************************************************************/
    
    public int getNameIndex() { return name_index; }
    
   
    /******************************************************************
     *
     * Returns string value of utf8_info byte array
     *
     * @param  none
     * @return String value of utf8_info
     *
     *****************************************************************/
    
    public String getUtf8_info() {
        return utf8_string;
        
      
        
    }
    
    /******************************************************************
     *
     * map the index to attribute constants
     *
     * @param  none
     * @return none
     *
     *****************************************************************/
    
    public void saveAttributesIndex() {
        for (int i = 0; i< ATTRIBUTES_TABLE_LENGTH; i++) {
            if (utf8_string.equals(class_file.attributesName[i])) {
                class_file.attributesIndex[i] = cpIndex;
            }
            
        }
        
        
    }
     /****************************************************************
     *
     * update pointer if this is a method_ref or field_ref
     *
     * @param  none
     * @return String value of utf8_info
     *
     *****************************************************************/
    
    public void updatePointer() {
        if(tag == CONSTANT_FieldRef && field!= null)  
        {
            pointer = field.field_offset;
            
        }
        else if ( tag == CONSTANT_MethodRef && method!= null)
        {
            pointer = method.code_offset;
        }
        
        
    }
}

