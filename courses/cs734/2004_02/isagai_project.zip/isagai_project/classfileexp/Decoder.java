
/*
 * Decoder.java
 *
 * Created on February 4, 2004, 4:47 PM
 */

import java.io.*;

/** Decodes Java instructions
 *
 *
 * @author Itoe Sagai
 *
 *******************************************************************/
class Decoder implements ConstantPoolTag {
    
    PrintWriter audit = null;  //audit output
    ClassFile class_file = null;
    int intval = 0;
    String hexStr="";
    //  Decoder()
    //  ------------------------------------------------------------
    /**
     *   a constructor
     *
     *   @param audit         audit file
     *   @param class_file    classfile
     *   
     *
     */
    public Decoder(PrintWriter audit,ClassFile class_file) {
        this.audit = audit;
        this.class_file = class_file;
    }
    
    //  decode()
    //  ------------------------------------------------------------
    /**
     *   decode opcode and count offset
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @return offset of next instruction
     *   @throws classFileException  in case of invalid instructions
     *
     */
    public int decode(byte[] code, int  opCodeOffset )
    throws ClassFileException {
        // audit.println( );
        System.out.println( opCodeOffset);
        
        
        intval = code [opCodeOffset] & 0x000000FF;
        hexStr = Integer.toString(intval , 16 /* radix */ );
        System.out.println(hexStr  );
        
        int next = 0;
        
        switch (intval) {
            
            case 171:
                lookupTable(code,opCodeOffset );
                break;
            case 170:
                tableSwitch(code,opCodeOffset );
                break;
            case 196:
                next = wide(code,opCodeOffset );
                break;
            case 200:
                next = goto_w(code,opCodeOffset );
                break;
            case 201:
                next = goto_w(code,opCodeOffset );  // jsr_w
                break;
            case 185:
                next = invokeinterface(code,opCodeOffset );
                break;
            case 197:
                next = multianewarray(code,opCodeOffset );
                break;
            case 187:
                next = objectRef(code,opCodeOffset ); // new
                break;
            case 189:
                next = objectRef(code,opCodeOffset); // anewarray,
                break;
            case 192:
                next = objectRef(code,opCodeOffset ); // check cast
                break;
            case 193:
                next = objectRef(code,opCodeOffset ); // instance of
                break;
            case 178:
                next = fieldRef(code,opCodeOffset ); // getstatic
                break;
            case 179:
                next = fieldRef(code,opCodeOffset ); // putstatic
                break;
            case 180:
                next = fieldRef(code,opCodeOffset ); // getfield
                break;
            case 181:
                next = fieldRef(code,opCodeOffset ); // putfield
                break;
            case 182:
                next = methodRef(code,opCodeOffset ); // invokevirtual
                break;
            case 183:
                next = methodRef(code,opCodeOffset ); // invokespecial
                break;
            case 184:
                next = methodRef(code,opCodeOffset ); // invokestatic
                break;
            case 19:
                next = ldc_w(code,opCodeOffset ); // ldc_w
                break;
            case 20:
                next = ldc2_w(code,opCodeOffset ); // ldc2_w
                break;
            case 18:
                next = ldc(code,opCodeOffset ); // ldc
                break;
            default:
                next = other(code,opCodeOffset ); // ldc
                
        }
        
        System.out.println("next="+next);
        return next;
    }
    
    
    
  
    
    
    //  lookupTable()
    //  ------------------------------------------------------------
    /**
     *   lookup table instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @return void
     *   @throws classFileException  in case of invalid instructions
     *
     *
     *
     */
    private void lookupTable(byte[] code, int  opCodeOffset  )
    throws ClassFileException {
        System.out.println("==lookuptable" + opCodeOffset  );
        if(opCodeOffset%4 ==0)
            opCodeOffset+=4;
        else if(opCodeOffset%4 ==1)
            opCodeOffset+=3;
        else if(opCodeOffset%4 ==2)
            opCodeOffset+=2;
        else
            opCodeOffset+=1;
        // skip default bites
        opCodeOffset+=4;
        // read n pairs
        int npair_count 
            = ByteUtility.readBytesToInt(4, code, opCodeOffset);
        opCodeOffset+=4;
        opCodeOffset+=npair_count*8;
        
        
        throw new ClassFileException
        ("Lookup Table instrction is not supported yet");
        
    }
    
    //  tableSwitch()
    //  ------------------------------------------------------------
    /**
     *   tableSwitch instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @return void
     *   @throws classFileException  in case of invalid instructions
     *
     */
    private void tableSwitch(byte[] code, int  opCodeOffset  )
    throws ClassFileException {
        System.out.println("==tableswitch" + opCodeOffset  );
        if(opCodeOffset%4 ==0)
            opCodeOffset+=4;
        else if(opCodeOffset%4 ==1)
            opCodeOffset+=3;
        else if(opCodeOffset%4 ==2)
            opCodeOffset+=2;
        else
            opCodeOffset+=1;
        // skip default bytes
        opCodeOffset+=4;
        // read low & high
        int low = ByteUtility.readBytesToInt(4, code, opCodeOffset);
        opCodeOffset+=4;
        int high = ByteUtility.readBytesToInt(4, code, opCodeOffset);
        opCodeOffset+=4;
        //
        int jump = high - low + 1;
        opCodeOffset+=jump*4;
        
        throw new ClassFileException
        ("Lookup Table instrction is not supported yet");
    }
    
    //  wide()
    //  ------------------------------------------------------------
    /**
     *   wide instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *
     */
    private int wide(byte[] code, int  opCodeOffset  )
    
    {
        System.out.println("==wide" + opCodeOffset  );
        opCodeOffset+=1;
        int op = code [opCodeOffset] & 0x000000FF;
        if(op== 132)// iinc
            
            opCodeOffset+=5;
        else
            opCodeOffset+=3;
        
        return opCodeOffset;
    }
    
    //  goto_w()
    //  ------------------------------------------------------------
    /**
     *   goto wide instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *
     */
    private int goto_w(byte[] code, int  opCodeOffset  )
    
    {
        
        System.out.println("==goto_w ot jsr_wide" + opCodeOffset  );
        return opCodeOffset+5;
    }
    
    //  invokeinterface()
    //  ------------------------------------------------------------
    /**
     *   invokeinterface instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *
     */
    private int invokeinterface(byte[] code, int  opCodeOffset  )
    
    {
        
        System.out.println("==invokeinterface" + opCodeOffset  );
        return opCodeOffset+5;
    }
    
    //  multianewarray()
    //  ------------------------------------------------------------
    /**
     *   multianewarray instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *
     */
    private int multianewarray(byte[] code, int  opCodeOffset  )
    
    {
        System.out.println("==multianewarray" + opCodeOffset  );
        return opCodeOffset+4;
    }
    
    
    //  objectRef()
    //  ------------------------------------------------------------
    /**
     *   2 bytes index to reference object  instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *
     */
    private int objectRef(byte[] code, int  opCodeOffset  )
    
    {
        System.out.println( "==reference to a class"+ opCodeOffset  );
        return opCodeOffset+3;
    }
    
    
    
    //  fieldRef()
    //  ------------------------------------------------------------
    /**
     *   2 bytes index to reference field  instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *   @throws classFileException  in case of invalid instructions
     *
     *
     */
    private int fieldRef(byte[] code, int  opCodeOffset  )
    throws ClassFileException {
        // String hexStr = Integer.toString(intval , 16 /* radix */ );
        System.out.println( hexStr
        +"** reference to a field--"+ opCodeOffset  );
        // index number
        opCodeOffset+=1;
        int index = ByteUtility.readBytesToInt(2, code, opCodeOffset);
        
        
        //retrieve field reference in constant Pool
        if (class_file.cp_table [index].getConstantType()
            !=CONSTANT_FieldRef) {
            throw new ClassFileException("invalid field reference ");
        }
        else {
            System.out.println("field reference is OK"  );
            if(class_file.cp_table[index].class_index 
                != class_file.this_class) {
                System.out.println
                ("can't resolve field of other class ");
                
                opCodeOffset +=2;
                
            }
            else {
                // points to this constant pool
           //int cp_address = class_file.cp_table [index].cp_offset;
                int cp_address = class_file.cp_table [index].pointer;
                // now changed unsigned 2 bytes
                byte [] two = new byte[2];
                two[1]=(byte)(cp_address & 0xFF);
                two[0]=(byte)((cp_address >>>8) & 0xFF);
                code [opCodeOffset++] = two[0];
                code [opCodeOffset++] = two[1];
                
            }
            
            
        }
        
        
        return opCodeOffset;
    }
    
    
    //  methodRef()
    //  ------------------------------------------------------------
    /**
     *   2 bytes index to reference method  instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *   @throws classFileException  in case of invalid instructions
     *
     *
     */
    private int methodRef(byte[] code, int  opCodeOffset  )
    throws ClassFileException {
        System.out.println( hexStr
        +"** reference to a method"+ opCodeOffset  );
        
        
        
        // index number
        opCodeOffset+=1;
        int index = ByteUtility.readBytesToInt(2, code, opCodeOffset);
        //opCodeOffset+=2;
        
        //retrieve method reference in constant Pool
        if (class_file.cp_table [index].getConstantType()
            !=CONSTANT_MethodRef) {
            throw new ClassFileException("invalid Method reference ");
        }
        else {
            System.out.println("method reference is OK"  );
            if(class_file.cp_table[index].class_index 
                != class_file.this_class){
                System.out.println
                ("resolve method of other class ");
                
                
                opCodeOffset +=2;
            }
            else {
                
                int cp_address = class_file.cp_table [index].pointer;
                
                // now changed unsigned 2 bytes
                byte [] two = new byte[2];
                two[1]=(byte)(cp_address & 0xFF);
                two[0]=(byte)((cp_address >>>8) & 0xFF);
                code [opCodeOffset++] = two[0];
                code [opCodeOffset++] = two[1];
                // find corresponding method entry for this index
                
                
            }
            
            
        }
        
        return opCodeOffset;
        
    }
    
    //  ldc_w()
    //  ------------------------------------------------------------
    /**
     *   2 bytes index to constant pool instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *   @throws classFileException  in case of invalid instructions
     *
     *
     */
    private int ldc_w(byte[] code, int  opCodeOffset  )
    throws ClassFileException {
        System.out.println( hexStr
        +"** reference to a constant - int or float"+ opCodeOffset  );
        
        // index number
        opCodeOffset+=1;
        int index = ByteUtility.readBytesToInt(2, code, opCodeOffset);
        //opCodeOffset+=2;
        
        //retrieve field reference in constant Pool
        if (class_file.cp_table [index].getConstantType()
            !=CONSTANT_Integer
        && class_file.cp_table [index].getConstantType()
            !=CONSTANT_Float
        && class_file.cp_table [index].getConstantType()
            !=CONSTANT_String) {
            throw new ClassFileException
                ("invalid constant reference ");
        }
        else {
            System.out.println("constant reference is OK"  );
            int cp_address = class_file.cp_table [index].cp_offset;
            
            // now changed unsigned 2 bytes
            byte [] two = new byte[2];
            two[1]=(byte)(cp_address & 0xFF);
            two[0]=(byte)((cp_address >>>8) & 0xFF);
            code [opCodeOffset++] = two[0];
            code [opCodeOffset++] = two[1];
            
            return opCodeOffset;
            
            
        }
        
        
    }
    
    //  ldc2_w()
    //  ------------------------------------------------------------
    /**
     *   2 bytes index to constant pool instruction (long & double)
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *   @throws classFileException  in case of invalid instructions
     *
     *
     */
    private int ldc2_w(byte[] code, int  opCodeOffset )
    throws ClassFileException {
        
        System.out.println( hexStr
        +"** reference to a constant - long or double"+ opCodeOffset);
        
        
        // index number
        opCodeOffset+=1;
        int index = ByteUtility.readBytesToInt(2, code, opCodeOffset);
        //opCodeOffset+=2;
        
        //retrieve field reference in constant Pool
        if (class_file.cp_table [index].getConstantType()
            !=CONSTANT_Long
        && class_file.cp_table [index].getConstantType()
            !=CONSTANT_Double) {
            throw new ClassFileException
            ("invalid constant reference ");
        }
        else {
            System.out.println("constant reference is OK"  );
            
            int cp_address = class_file.cp_table [index].cp_offset;
            
            // now changed unsigned 2 bytes
            byte [] two = new byte[2];
            two[1]=(byte)(cp_address & 0xFF);
            two[0]=(byte)((cp_address >>>8) & 0xFF);
            code [opCodeOffset++] = two[0];
            code [opCodeOffset++] = two[1];
            
            
            return opCodeOffset;
        }
        
        
    }
    
    //  ldc()
    //  ------------------------------------------------------------
    /**
     *   1 byte index to constant pool instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *   @throws classFileException  in case of invalid instructions
     *
     *
     */
    private int ldc(byte[] code, int  opCodeOffset )
    throws ClassFileException {
        System.out.println( hexStr
        +"** ldc ***"+ opCodeOffset  );
        
        
        // index number
        opCodeOffset+=1;
        int index = ByteUtility.readBytesToInt(1, code, opCodeOffset);
        //opCodeOffset+=2;
        System.out.println( index );
        //retrieve field reference in constant Pool
        if (class_file.cp_table [index].getConstantType()
            !=CONSTANT_Integer
        && class_file.cp_table [index].getConstantType()
            !=CONSTANT_Float
        && class_file.cp_table [index].getConstantType()
            !=CONSTANT_String) {
            throw new ClassFileException
                ("invalid constant reference ");
        }
        else {
            System.out.println("constant reference is OK"  );
            int cp_address = class_file.cp_table [index].cp_offset;
            
            // now changed unsigned 1 byte
            byte aByte;
            aByte =(byte)(cp_address & 0xFF);
           
            code [opCodeOffset++] = aByte;
            
            
            return opCodeOffset;
            
        }
        
        
    }
    
    // other()
    //  ------------------------------------------------------------
    /**
     *   other instruction
     *
     *   @param code         byte array containing java instructions
     *   @param opCodeOffset array index to code array
     *   @param codeAddress  start address of this code
     *   @return offset of next instruction
     *
     *   @throws classFileException  in case of invalid instructions
     *
     *
     */
    private int other(byte[] code, int  opCodeOffset  )
    throws ClassFileException {
        
        // all other three bytes instructions
        if((intval>= 153 && intval<= 168)||
        intval== 17 ||
        intval== 132 ||
        intval== 198 ||
        intval== 199    )   //
        {
            System.out.println( hexStr
            +"** all other three bytes instructions"+ opCodeOffset  );
            opCodeOffset+=3;
        }
        // to bytes instructions
        else if((intval>= 21 && intval<= 25)||
        (intval>= 54 && intval<= 58)||
        intval== 169 ||
        intval== 16 ||
        intval== 188 )   //
        {
            System.out.println( hexStr
            +"** two bytes instructions"+ opCodeOffset  );
            opCodeOffset+=2;
        }
        
        
        else {
            char [] hex=ByteUtility.toHex(code [opCodeOffset] );
            System.out.print(hex[0]+" "+hex[1]+"  ");
            System.out.println
                ("** one byte instruction"+ opCodeOffset  );
            opCodeOffset+=1;
        }
        
        return opCodeOffset;
    }
}