// Assignment 4 - AttributesConstant.java
// Created on: 4/30/04

/** Defines other classfile constants
 *
 *@author Itoe Sagai
 *
 *******************************************************************/

public interface ClassFileConstant {
    static final int WORD_SIZE =  4;
    static final int BYTE_SIZE  = 1;
    static final int SHORT_SIZE = 2;
    static final int DOUBLE_SIZE = 8;    
    
    static final String CLASS_MAIN = "main";
    static final int CLASS_DATA_SIZE= 10; // 5 entries of shorts
    static final int METHOD_HK_LENGTH = 12; //method housekeeping area
}

