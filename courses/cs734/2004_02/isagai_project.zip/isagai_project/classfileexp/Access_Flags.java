// Assignment 4 - Access_Flags.java
// Created on: 11/18/2001

/** Defines access flag values
  *  
  *@author Itoe Sagai
  *     
  *******************************************************************/

  public interface Access_Flags
  {
    static final short ACC_PUBLIC    = 0x0001;
    static final short ACC_FINAL     = 0x0010;    
    static final short ACC_SUPER     = 0x0020; 
    static final short ACC_STATIC    = 0x0008;
    static final short ACC_INTERFACE = 0x0200;
    static final short ACC_ABSTRACT  = 0x0400;
  }    

