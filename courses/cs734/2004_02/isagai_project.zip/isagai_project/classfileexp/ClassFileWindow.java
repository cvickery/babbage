// CS101 - Assignment 5: ClassFileWindow.java
// date: 12/12/2001

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/********************************************************************
 *
 * Contents of a single class file in a Window for a user to explore.
 *
 * @author Itoe Sagai
 *
 */

public class ClassFileWindow extends JFrame {
    
    /*****************************************************************
     *
     * Constructor to create a window and fill with contents
     * information of a single class file.
     *
     *  @param cf a reference to a Class File object
     *  @return none
     *
     ****************************************************************/
    
    public ClassFileWindow(ClassFile cf) {
        
        // call superclass constructor
        
        super(cf.toString());
        
        // set up GUI components
        
        Container cp = getContentPane();
        JTextArea outArea = new JTextArea();
        outArea.setBorder(
        BorderFactory.createEmptyBorder(5,5,5,5));
        outArea.setEditable(false);
        JScrollPane scroller = new JScrollPane(outArea);
        cp.add(scroller);
        
        // output of class file contents
        
        outArea.setText( "Minor Version: " 
            + cf.getMinorVersion() + "\n");
        outArea.append( "Major Version: " 
            + cf.getMajorVersion() + "\n");
        outArea.append( "Access Flags: " + " (0x" +
        Integer.toHexString(cf.getAccessFlagsValue()) +") "
            + cf.getAccessFlagsInfo() + "\n");
        outArea.append( "This Class: " + cf.getThis_Class() + "\n");
        outArea.append( "Superclass: " + cf.getSuper_Class() + "\n");
        outArea.append( "Constant Pool:  ( " 
            + cf.getConstantPoolCount()
            + " entries )\n");
        
        // build constant pool entry table
        
        ConstantPoolEntry [] cpTable = cf.getConstantPoolEntries();
        for (int i = 0; i < cpTable.length ; i ++)
            outArea.append( i + ":   \t" + cpTable [i] + "\n");
        
        
        // build field table
        outArea.append( "field information: " + "\n");
        outArea.append( "-----------------------------" + "\n");
        Field [] fieldTable = cf.getFieldTable();
        for (int i = 0; i < fieldTable.length ; i ++)
            outArea.append( i + ":   \t" + (fieldTable [i]).toString() 
            + "\n");
        
        
        // build method table
        outArea.append( "method information: " + "\n");
        outArea.append( "-----------------------------" + "\n");
        Method [] methodTable = cf.getMethodTable();
        for (int i = 0; i < methodTable.length ; i ++)
            outArea.append( i + ":   \t" 
            + (methodTable [i]).toString() 
            + "\n");
        
        
        pack();
        
    }
}

