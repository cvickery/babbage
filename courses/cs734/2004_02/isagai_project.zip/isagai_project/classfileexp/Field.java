/*
 * Field.java
 *
 * Created on February 4, 2004, 4:47 PM
 */

import java.io.*;

/** A field in Java class file
 *
 *
 * @author Itoe Sagai
 *
 *******************************************************************/

class Field implements ClassFileConstant, ConstantPoolTag,Access_Flags 
{
    
    ClassFile class_file;  //a class in which this method belongs to
    //ConstantPoolEntry [] cp_table;
    int access_flags;
    int name_index;
    //    String field_name;
    int descriptor_index;
    int attributes_count;
    Attribute [] attribute_table;
    String name = "";   //name of the field
    String descriptor = ""; //descriptor
    
    //int offset = 0;
    int field_offset=0;  // from the beginning of the bytecode
    int field_length = 0;
    
    
    /** Creates a new instance of Field */
    public Field() {
    }
    /*****************************************************************
     * A constructor for a constant pool entry in Java Class file
     * which will store data in different instance variables depends
     * on a tag value.
     *
     * @param   dis Data Input Stream object represending class file.
     * @parqm   class_file  class file to which this field belongs
     * @return  none
     * @throws  ClassFileException in case of IO Error or unsupported
     *          encoding error.
     ****************************************************************/
    
    public Field( DataInputStream dis, ClassFile class_file)
    throws ClassFileException
    
    {
        try {
            this.class_file =class_file;
            access_flags = dis.readUnsignedShort();
            name_index= dis.readUnsignedShort();
            descriptor_index = dis.readUnsignedShort();
            attributes_count = dis.readUnsignedShort();
            //offset=8;
            
            // check access flags
            if ((access_flags & ACC_STATIC) != 0)
                System.out.println(name +"--this is static field" );
            else
                System.out.println
                (name +"--this is NOT static field");
            
            name=class_file.cp_table[name_index].utf8_string;
            descriptor=
                class_file.cp_table[descriptor_index].utf8_string;
            
            attribute_table = new Attribute[attributes_count];
            for (int i = 0; i < attributes_count; i++) {
                attribute_table [i] = new Attribute( dis,class_file );
                
                System.out.println( attribute_table[i].getOffSet());
                //offset += attribute_table[i].getOffSet();
            }
            
            
            // associate with CP
            for (int i = 1; i < class_file.cp_table.length; i++) {
                
                if (class_file.cp_table[i].tag==CONSTANT_FieldRef) {
                    
                    if (class_file.cp_table[i].class_index
                        ==class_file.this_class ) {
                        ConstantPoolEntry temp
                        = class_file.cp_table
                         [class_file.cp_table[i].name_and_type_index];
                        
                        if (temp.name_index ==name_index &&
                        temp.descriptor_index==descriptor_index ) {
                            class_file.cp_table[i].field = this;
                            break;
                        }
                    }
                    else {
                        System.out.println
                        (name +"--a field of other classes " 
                        + "  is not supported at this time");
                    }
                    
                }
                
                if (class_file.cp_table [i].isTwoEntries()) {
                    i++;
                    
                }
                
            }
            
            
            // compute field length
            
            String field_descriptor
            = class_file.cp_table[descriptor_index].getUtf8_info();
            
            char firstChar =field_descriptor.charAt(0);
            
            // double & long
            if (firstChar =='D' || firstChar =='J') {
                field_length = DOUBLE_SIZE;
            }
            
            // everything else gets word
            else {
                field_length = WORD_SIZE;
            }
            
            
            
            
            
        }
        
        catch (Exception e) {
            throw new ClassFileException(e.getMessage());
        }
        
    }
    
    
    /****************************************************************
     *
     * Returns string representation of a field
     *
     * @param   none
     * @return  string representation of a field
     *          
     *
     ****************************************************************/
    
    public String toString() {
        
        return "field : " + name + ", descriptor " + descriptor
        + ", start address " + field_offset +", length "+field_length;
        
    }
}
