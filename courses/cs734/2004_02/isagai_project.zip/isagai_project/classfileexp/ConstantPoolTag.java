// Assignment 4 - ConstantPoolTag.java
// Created on: 11/18/2001

/** Defines tag value used in Constant Pool Entries
  *  
  *@author Itoe Sagai
  *     
  *******************************************************************/

  public interface ConstantPoolTag
  {
    static final int CONSTANT_Utf8         = 1;
    static final int CONSTANT_Integer      = 3;
    static final int CONSTANT_Float        = 4;
    static final int CONSTANT_Long         = 5;
    static final int CONSTANT_Double       = 6;
    static final int CONSTANT_Class        = 7;
    static final int CONSTANT_String       = 8;
    static final int CONSTANT_FieldRef     = 9;
    static final int CONSTANT_MethodRef    = 10;
    static final int CONSTANT_InterfaceMethodRef = 11;
    static final int CONSTANT_NameAndType  = 12;
   
  }    

