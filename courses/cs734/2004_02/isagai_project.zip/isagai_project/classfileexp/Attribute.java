/*
 * Attribute.java
 *
 * Created on February 4, 2004, 4:47 PM
 */

import java.io.*;

/** An Attribute in Java class file
 *
 *
 * @author Itoe Sagai
 *
 *******************************************************************/

class Attribute implements AttributesConstant{
    
    ClassFile classFile;
    //MethodEntry method_entry;  // used if this is a code attributes
    int attribute_type;  //type of attributes are for
    
    int attribute_name_index;
    int attribute_length;
    
    // 0 - constant value attribute
    int constantvalue_index;
    
    // 1 - code
    
    int max_stack;
    int max_locals;
    int code_length;
    byte code[];
    int exception_table_length;
    short exception_table[][];
        /*
        {    	u2 start_pc;
                u2 end_pc;
                u2  handler_pc;
                u2  catch_type;
        }
         */
    int attributes_count;
    Attribute code_attributes [];
    //attribute_info attributes[attributes_count];
    
    
    byte [] info;
    int opCodeOffset = 0;  // offset for opcode
    int offset=0;
    
    // 2 exceptions attributes
    
    // 3 inner class attributes
    
    // 4 synthetic attributes
    
    // 5 source file attributes
    
    // 6 line number table
    
    // 7 local variable table
    
    // 8 deprecated attribute
    
    /** Creates a new instance of Attribute */
    public Attribute() {
    }
    /*****************************************************************
     * A constructor for an attribute entry in Java Class file
     *
     * @param   dis Data Input Stream object represending class file.
     * @param   cf  class file to which this attribute belongs.
     * @return  none
     * @throws  ClassFileException in case of IO Error or unsupported
     *          encoding error.
     ****************************************************************/
    
    public Attribute( DataInputStream dis, ClassFile cf)
    throws ClassFileException
    
    {
        
        classFile =cf;
        
        
        try {
            attribute_name_index = dis.readUnsignedShort();
            offset += 2;
            attribute_length = dis.readInt();
            offset += 4;
            offset += attribute_length;
            info = new byte[attribute_length];
            dis.read(info);
            
            if (attribute_name_index==   
                classFile.attributesIndex[CONSTANT_VALUE]) {
                attribute_type = CONSTANT_VALUE;
                System.out.println("CONSTANT_VALUE found"  );
            }
            else if (attribute_name_index== 
                classFile.attributesIndex[CODE]) {
                
                attribute_type = CODE;
                System.out.println("code attributes found"  );
                readCodeAttribute();
            }
            else if (attribute_name_index==  
                classFile.attributesIndex[EXCEPTIONS]) {
                attribute_type = EXCEPTIONS;
                System.out.println("exceptions attributes found"  );
            }
            else if (attribute_name_index== 
                classFile.attributesIndex[INNER_CLASSES]) {
                attribute_type = INNER_CLASSES;
                System.out.println("INNER_CLASSES attributes found" );
            }
            else if (attribute_name_index== 
                classFile.attributesIndex[SYNTHETIC]) {
                attribute_type = SYNTHETIC;
                System.out.println("synthetic attributes found"  );
            }
            else if (attribute_name_index==   
                classFile.attributesIndex[SOURCEFILE]) {
                attribute_type = SOURCEFILE;
                System.out.println("source file attributes found"  );
            }
            else if (attribute_name_index== 
                classFile.attributesIndex[LINE_NUMBER_TABLE]) {
                attribute_type = LINE_NUMBER_TABLE;
                System.out.println
                ("LINE_NUMBER_TABLE attributes found" );
            }
            else if (attribute_name_index== 
                classFile.attributesIndex[LOCAL_VARIABLE_TABLE]) {
                attribute_type = LOCAL_VARIABLE_TABLE;
                System.out.println
                ("LOCAL_VARIABLE_TABLE attributes found"  );
            }
            else if (attribute_name_index== 
                classFile.attributesIndex[DEPRECATED ]) {
                attribute_type = DEPRECATED;
                System.out.println("DEPRECATED  attributes found"  );
            }
            else {
                System.out.println("other attributes found"  );
            }
            
            
        }
        
        catch (Exception e) {
            throw new ClassFileException(e.getMessage());
        }
        
    }
    
    /*****************************************************************
     *
     * Returns an offset(length) in bytes of an attribute
     *
     * @param  none
     * @return offset or length in bytes
     *
     ****************************************************************/
    
    public int getOffSet() {return offset;}
    
    /****************************************************************
     *
     * Returns name of the class, major & minor version of the file
     *
     * @param   none
     * @return  ClassName, major version and minor version of
     *          the class file
     *
     ****************************************************************/
    
    public String toString() {
        
        return "index"+attribute_name_index;
        
    }
    
    /****************************************************************
     *
     * read in code attributes from the array of bytes
     *
     * @param   none
     * @return  void
     *
     *
     ****************************************************************/
    
    public void readCodeAttribute() {
        
        int currOffset= 0;
        max_stack = ByteUtility.readBytesToInt(2, info, currOffset);
        if (max_stack > classFile.max_stacks)
            classFile.max_stacks =max_stack;
        System.out.println("Max Stack: "+max_stack  );
        
        currOffset+=2;
        max_locals = ByteUtility.readBytesToInt(2, info, currOffset);
        if (max_locals > classFile.max_locals)
            classFile.max_locals =max_locals;
        System.out.println("Max locals: "+max_locals  );
        
        currOffset+=2;
        code_length = ByteUtility.readBytesToInt(4, info, currOffset);
        System.out.println("code length"+code_length  );
        
        currOffset+=4;
        code = new byte [code_length];
        System.out.println("code length" );
        
        
        char hex[];
        hex = new char[2];
        opCodeOffset = 0;
        
        for (int i = 0; i<code_length ;i++) {
            code [i] = info [currOffset++];
            
            hex=ByteUtility.toHex(code[i]);
            System.out.print(hex[0]+" "+hex[1]+"  ");
        }
        
        System.out.println(  );
        //while( opCodeOffset<code_length)
        //   decode();  // decode opcode
        
        
        // exception tables
        exception_table_length = 
            ByteUtility.readBytesToInt(2, info, currOffset);
        System.out.println("\nexception table length" 
        +exception_table_length );
        currOffset+=2;
        exception_table = new short[exception_table_length] [4];
        
        for (int i = 0; i< exception_table_length;i++) {
            // start_PC
            exception_table[i][0]= 
                (short) ByteUtility.readBytesToInt
                    (2, info, currOffset);
            currOffset+=2;
            
            // and_PC
            exception_table[i][1]= 
                (short) ByteUtility.readBytesToInt
                    (2, info, currOffset);
            currOffset+=2;
            
            // handler_PC
            exception_table[i][2]= 
                (short) ByteUtility.readBytesToInt
                    (2, info, currOffset);
            currOffset+=2;
            
            // catch_type
            exception_table[i][3]=  
                (short) ByteUtility.readBytesToInt
                    (2, info, currOffset);
            currOffset+=2;
        }
        
        // attributes count
        
        attributes_count = 
            ByteUtility.readBytesToInt(2, info, currOffset);
        System.out.println
            ("attributes count in code attributes"+attributes_count );
        
        currOffset+=2;
        System.out.println("offset"+ currOffset );
       /* code_attributes = new Attribute[attributes_count];
        for (int i = 0; i < attributes_count; i++) {
                code_attributes [i] = new Attribute( dis, classFile);
                //offset += attributeTable[i].getOffSet();
            }*/
        
        
    }
   
    
    
}
