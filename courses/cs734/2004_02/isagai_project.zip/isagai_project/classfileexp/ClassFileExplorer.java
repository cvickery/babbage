// CS731  ClassFileExplorer.java
// date - 3/8/2004

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;


/**
 *  Utility to read a class file (bytecode), and replace references to
 *  constant pool entries with the actual offset.
 *
 *
 * @author Itoe Sagai
 *
 */

public class ClassFileExplorer extends JFrame 
    implements ClassFileConstant{
    
    public static String path = "";
    
    // gui components
    private Container cp = getContentPane();
    private JPanel jp;
    private JFileChooser fileChooser = new JFileChooser(".");
    
    // switch to indicate if a file is added by user from GUI
    private boolean isNew = false;
    
    static  Vector classList;  // list of ClassFiles
    private Vector classNameTable;  // list of filenames
    
    
    static private int max_method_stacks=1;
    static PrintWriter audit_file = null;
    
    /****************************************************************
     *
     * Constructor to initialize the main window and display a list
     * of files, and also to initialize ClassFileWindow for each
     * file in the list.
     *
     * @param list a vector of class file names
     * @return none
     *
     ***************************************************************/
    
    public ClassFileExplorer(Vector v) {
        // call JFrame constructor
        
        super("Class File Explorer");
        
        classList = v;
        
        // set up menu bar
        JMenuBar bar = new JMenuBar();
        setJMenuBar(bar);
        
        // create File menu
        
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic('F');
        
        // create File-new item
        JMenuItem newItem = new JMenuItem("New");
        newItem.setMnemonic('N');
        newItem.addActionListener(
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                openNewFile();
            }
        });
        
        fileMenu.add(newItem);
        
        // create File-exit item
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.setMnemonic('X');
        exitItem.addActionListener(
        new ActionListener() {
            public void actionPerformed(ActionEvent ae)
            { System.exit(0); }
        });
        fileMenu.add(exitItem);
        
        // Create Help menue
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic('H');
        
        // create Help-about item
        
        JMenuItem aboutItem = new JMenuItem("About...");
        aboutItem.setMnemonic('A');
        aboutItem.addActionListener(
        new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(ClassFileExplorer.this,
                "Class File Explorer v.1.0 \nBy Itoe Sagai",
                "About", JOptionPane.PLAIN_MESSAGE);
            }
        });
        
        helpMenu.add(aboutItem);
        
        bar.add(fileMenu);
        bar.add(helpMenu);
        
        // set up JPanel with scroll and 1 column table
        // and add to content pane
        
        jp = new JPanel();
        jp.setLayout(new  GridLayout(0,1 ));
        jp.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JScrollPane scroller = new JScrollPane(jp);
        cp.add(scroller);
        
        
        // create check boxes and class file window
        // for all files in the vector
        
        Iterator it = classList.iterator();
        while (it.hasNext()) {
            ClassFile cf = (ClassFile) it.next();
            
            addClassFileWindow(cf, isNew);
        }
        
        // display on the screen
        
        pack();
        show();
        
    }
    
    
    /****************************************************************
     *
     * Displays a "open file" dialog box to allow a user to add
     * a new class file to explore; adds a selected file in
     * the main window and displays a ClassFileWindow.
     *
     * @param  none
     * @return none
     *
     ***************************************************************/
    
    private void openNewFile() {
        fileChooser.setFileSelectionMode(
        JFileChooser.FILES_ONLY);
        int result = fileChooser.showOpenDialog( this );
        
        // user didn't select a file
        if ( result != JFileChooser.APPROVE_OPTION )
            return;
        
        // user selected a file
        try {
            
            ClassFile cf = new ClassFile
            ( fileChooser.getSelectedFile().getCanonicalPath(),
            classNameTable, classList);
            
            isNew = true;
            addClassFileWindow(cf, isNew);
            
            validate();
            
        }
        
        catch (ClassFileException cfe) {
            JOptionPane.showMessageDialog(ClassFileExplorer.this,
            cfe.toString(), "Invalid File Selected",
            JOptionPane.ERROR_MESSAGE);
            
        }
        
        catch (IOException ioe) {
            JOptionPane.showMessageDialog(ClassFileExplorer.this,
            ioe.toString(), "I/O Error", JOptionPane.ERROR_MESSAGE);
        }
        
        
        
        
    }
    
    /****************************************************************
     *
     * For a valid java class file, initialize ClassFileWindow and
     * checkbox.
     *
     * @param cf    Class File
     * @param isNew True if a new file is selected from GUI
     * @return void
     *
     ***************************************************************/
    
    private void addClassFileWindow(ClassFile cf, boolean isNew) {
        // set up classfilewindow and checkbox associated with
        //System.err.println("cf2xxxx" + cf.toString());
        final ClassFileWindow cfw = new ClassFileWindow(cf);
        
        final JCheckBox jcb = new JCheckBox(cf.toString());
        jp.add(jcb);
        cfw.setLocation(50,10);
        
        // listener for JCheckBox
        
        jcb.addItemListener( new ItemListener() {
            public void itemStateChanged(ItemEvent ie) {
                if (ie.getStateChange() == ItemEvent.SELECTED )
                    cfw.show();
                else
                    cfw.hide();
            }
        });
        
        // listener for ClassFileWindow
        
        cfw.addWindowListener( new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                jcb.setSelected(false);
            }
        });
        
        
        // if this is a new file added from GUI, add to vector
        // and display classfilewindow
        
        if (isNew) {
            classList.addElement(cf);
            jcb.setSelected(true);
            cfw.show();
        }
    }
    
    
    // main
    /****************************************************************
     *
     * Add a list of file names entered by user to a vector and
     * creates a window to display the list; exits when a window
     * is closed.
     *
     * @param args Command line argments
     * @return void
     *
     ***************************************************************/
    
    
    public static void main(String [] args) {
        
        
        // takes three arguments
        //
        // class file name
        // default path
        // mode - inspection or build - build will create new file
        
        if (args.length<3) {
            System.out.println
            ("usage: Explorer \"class-file.class\" " +
            "\"default-path\" i|b "
            +"[max_method_stacks]" );
            
            
            
            System.out.println
            ("  i - inspect class file, b - build classx file ");
            System.exit(0);
        }
        else {
            //check second arg
            path = args[1]+"\\";
            File pathDir = new File(args[1]);
            
            
            // Test 1: if the file can be read
            if (! pathDir.isDirectory()) {
                System.out.println
                ("Second argument should be a directory name" );
                System.exit(0);
            }
            else if (!args[2].equalsIgnoreCase("i") &&
            !args[2].equalsIgnoreCase("b")) {
                
                System.out.println
                ("Third argument should be i or b" );
                System.exit(0);
                
                
            }
            else if (args[2].equalsIgnoreCase("b")) {
                if ( args.length!=4) {
                    System.out.println
                    ("Enter maximum number of method stack" );
                    System.exit(0);
                }
                else {
                    
                    try{
                        max_method_stacks =Integer.parseInt(args[3]);
                    }
                    catch(NumberFormatException nfe){
                        System.out.println(nfe );
                        System.exit(0);}
                }
                
                
            }
            
            
            
            
        }
        
        String mode = args[2];
        
        //  vector to store class file data
        Vector fileList = new Vector();
        
        // create vector to store file names entered by user
        Vector classNameTable = new Vector();
        
        
        
        classNameTable.addElement(args[0]);
        File f=        null;
        String c = null;
        File newfile = null;
        int counter = 0;
        
        
        // process only one fileis
        // preprocess class file
        
        // while (!classNameTable.isEmpty()) {
        
        c= (String) classNameTable.get(0);
        
        String cPath = path + (String) classNameTable.get(0);
        newfile = new File(cPath);
        System.out.println( "new class file -" + newfile.getName());
        
        
        // check if we already created ClassFile object
        
        boolean found = false;
        for (int i = 0; i< fileList.size();i++){
            f = (File) fileList.get(i);
            System.out.println( "class file -" + f.getName());
            
            if (cPath.compareTo(f.getPath())==0) {
                System.out.println( "alredy created, skip -" 
                    + f.getPath()+"," +cPath);
                found=true;
                classNameTable.removeElementAt(0);
                System.out.println( "removing " + c);
                break;  }
            
        }
        
        // if not, create and remove from classNameTable
        if( ! found) {
            try {
                // add to vector
                System.out.println( "main add to file list" + c);
                ClassFile cf;
                cf =new ClassFile(cPath, classNameTable,fileList);
                //cf.resolve();
                fileList.addElement(cf);
                classNameTable.remove(c);
                System.out.println( "removing " + c);
                System.out.println( "class name table"
                    +classNameTable.toString());
                
            }
            
            catch (ClassFileException cfe) {
                System.err.println(cfe.toString());
                classNameTable.removeElementAt(0);
                System.out.println( "removing " + c);
            }
            // }
           
        }
        
        // do remaining only if in build mode-----------------------
        
        if (mode.equalsIgnoreCase("b")){
            
            int numClasses = fileList.size();
            int adjustment = 0;
            adjustment= fileList.size()*CLASS_DATA_SIZE;
            // print method area
            System.out.println("constant pools" );
            for (int i = 0; i< numClasses;i++){
                System.out.println("***" );
                ClassFile cf = (ClassFile) fileList.get(i);
                adjustment = cf.updateCpOffset(adjustment );
                
                cf.max_frames= max_method_stacks;
            }
            
            
            System.out.println("method area" );
            for (int i = 0; i< numClasses;i++){
                ClassFile cf = (ClassFile) fileList.get(i);
                
                System.out.println("***" );
                adjustment = cf.updateMethodOffset(adjustment );
                
            }
            
            System.out.println("the static fields ");
            System.out.println( adjustment);
            // make sure that field starts at multiple of four
            if (adjustment % 4 != 0)
                adjustment = adjustment + (4-(adjustment % 4));
            System.out.println("after adjustment ");
            System.out.println( adjustment);
            
            
            System.out.println("static field area" );
            for (int i = 0; i< numClasses;i++){
                ClassFile cf = (ClassFile) fileList.get(i);
                adjustment = cf.updateFieldOffset(adjustment );
                
            }
            System.out.println("end of file " +adjustment);
            
            
            // now we know the position of everything
            // update pointers in constant pool entries
            
            System.out.println("constant pools" );
            for (int i = 0; i< numClasses;i++){
                System.out.println("***" );
                ClassFile cf = (ClassFile) fileList.get(i);
                cf.updatePointers( );
                
            }
            
            
            
            
            
            File audit = new File(path+args[0]+"audit");
            
            
            if (audit.canRead())
                audit.delete();
            
            
            try{
                
                audit_file = new PrintWriter(new BufferedWriter(
                (new FileWriter(audit, true))));
                
                // print load file format
                for (int i = 0; i< numClasses;i++){
                    audit_file.println
                        ("\n*** data structure area  ***" );
                    ClassFile cf = (ClassFile) fileList.get(i);
                    cf.printDataStructure(audit_file);
                }
                
                for (int i = 0; i< numClasses;i++){
                    audit_file.println("\n*** constant pool area " );
                    ClassFile cf = (ClassFile) fileList.get(i);
                    cf.printConstantPool(audit_file);
                    
                }
                for (int i = 0; i< numClasses;i++){
                    audit_file.println("\n*** method area " );
                    ClassFile cf = (ClassFile) fileList.get(i);
                    cf.printMethods(audit_file);
                    
                }
                
                for (int i = 0; i< numClasses;i++){
                    audit_file.println("\n*** static fields " );
                    ClassFile cf = (ClassFile) fileList.get(i);
                    cf.printFields(audit_file);
                    
                }
                
                // resolve method
                for (int i = 0; i< numClasses;i++){
                    
                 //System.out.println("resolving :" + out.getName());
                    
                    ClassFile cf = (ClassFile) fileList.get(i);
                    cf.resolveMethods(audit_file);
                    
                    //  dos.close();
                    
                }
                audit_file.close();
                
                // write to a file
                // write data structure
                File out = new File(path+args[0]+"x");
                if (out.canRead())
                    out.delete();
                
                DataOutputStream dos
                = new DataOutputStream
                (new FileOutputStream( out, true ));
                
                byte []b = new byte[2];
                // write number of classes
                //writeTwoBytes(numClasses, dos);
                
                // class data
                for (int i = 0; i< numClasses;i++){
                    
                    ClassFile cf = (ClassFile) fileList.get(i);
                    
                    ByteUtility.writeTwoBytes(cf.startClinit, dos);
                    ByteUtility.writeTwoBytes(cf.startMain, dos);
                    ByteUtility.writeTwoBytes(cf.max_stacks, dos);
                    ByteUtility.writeTwoBytes(cf.max_locals, dos);
                    ByteUtility.writeTwoBytes(cf.max_frames, dos);
                    
                    
                }
                
                // write constant pool area.
                for (int i = 0; i< numClasses;i++){
                    System.out.println("\n*** constant pool area " );
                    ClassFile cf = (ClassFile) fileList.get(i);
                    cf.writeConstantPool(dos);
                    
                }
                for (int i = 0; i< numClasses;i++){
                    System.out.println("\n*** method area " );
                    ClassFile cf = (ClassFile) fileList.get(i);
                    cf.writeMethods(dos);
                    
                }
                System.out.println( "closing");
                
                
            }
            
            catch(ClassFileException cfe) {
                System.out.println(cfe );
                
            }
            catch(IOException ioe) {
                System.out.println(ioe );
                
            }
            
        }
        else  {
            System.out.println("inspect-" + args[0]);
        }
      /*  catch(IOException ioe) {
            System.out.println(ioe );
       
        }*/
        ClassFileExplorer window = new ClassFileExplorer(fileList);
        
        // Exit program when the window is closed.
        
        window.addWindowListener( new WindowAdapter() {
            public void windowClosing(WindowEvent we)
            { System.exit(0); }
        });
    }
    
}

