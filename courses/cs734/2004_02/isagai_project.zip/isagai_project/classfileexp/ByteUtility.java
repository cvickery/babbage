/*
 * ByteUtility.java
 *
 *
 */

import java.io.*;

/** collection of tools useful in byte operations
 *
 *
 * @author Itoe Sagai
 *
 *******************************************************************/

class ByteUtility {
    
    private static String hexTab = "0123456789ABCDEF";
    
    //  toHex()
    //  ------------------------------------------------------------
    /**
     *   Convert an unsigned integer into a String of hexadecimal
     *   digits, with leading zeros.
     *
     *   @param  val     The (long) integer to be converted.
     *   @return  2 characters in hex code
     *
     */
    public static char[] toHex( byte val ) {
        char[] returnVal = new char[ 2 ];
        for (int i = 1; i >= 0; i--) {
            returnVal[i] = hexTab.charAt( (int)(val & 0x0F) );
            val >>= 4;
            //System.out.print("inside-"+returnVal[i]);
        }
        
        return returnVal;
    }
    
    /****************************************************************
     *
     * Write a least significant byte from integer to a file
     *
     *
     * @param value    integer value
     * @param dos      data output stream
     * @return void
     *
     ***************************************************************/
    
    public static void writeOneByte(int value,  DataOutputStream dos)
    throws IOException{
        
        byte one = 0;
        
        one=(byte)(value & 0xFF);
        
        dos.write(one);
        
        
        
    }
    
    
    /****************************************************************
     *
     * Write two least significant bytes from integer to a file
     *
     *
     * @param value    integer value
     * @param dos      data output stream
     * @return void
     *
     ***************************************************************/
    
    public static void writeTwoBytes(int value,  DataOutputStream dos)
    throws IOException{
        
        byte [] two = new byte[2];
        
        two[1]=(byte)(value & 0xFF);
        two[0]=(byte)((value >>>8) & 0xFF);
        dos.write(two[0]  );
        dos.write(two[1]  );
        
        
    }
    
    
    /****************************************************************
     *
     * Write four  bytes of integer to a file
     *
     *
     * @param value    integer value
     * @param dos      data output stream
     * @return void
     *
     ***************************************************************/
    
    public static void writeFourBytes(int value,  DataOutputStream dos)
    throws IOException{
        
        byte [] four = new byte[4];
        
        
        for (int i = 0; i<4; i++) {
            four[i]=(byte)((value >>>(8*i)) & 0xFF);
        }
        for (int i = 3; i>=0; i--) {
            dos.write(four[i]  );
        }
        
    }
    
    
    /****************************************************************
     *
     * Write eight  bytes of long to a file
     *
     *
     * @param value    long integer value
     * @param dos      data output stream
     * @return void
     *
     ***************************************************************/
    
    public static void writeEightBytes
        (long value, DataOutputStream dos) throws IOException
    {
        
        byte [] eight = new byte[8];
        
        
        for (int i = 0; i<8; i++) {
            eight[i]=(byte)((value >>>(8*i)) & 0xFF);
        }
        for (int i = 7; i>=0; i--) {
            dos.write(eight[i]  );
        }
        
    }
    
    //  ------------------------------------------------------------
    /**
     *   Convert bytes to integer
     *
     *   @param  length     length of a number
     *   @param  data       byte array
     *   @param  offset     starting position
     *
     *   @return integer value
     */
    
    public static int readBytesToInt
        (int length, byte[] data, int offset)
    
    {
        int result = 0;
        for (int i = 0; i<length - 1; i++) {
            result += (data[offset++] & 0x000000FF);
            result <<= 8;
        }
        
        System.out.println(data[offset] );
        result += data[offset++]& 0x000000FF;
        return result;
        
    }
    
}
