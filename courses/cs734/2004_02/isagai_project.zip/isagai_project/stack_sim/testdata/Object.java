package java.lang;

/**
*
* test branch instruction
*/

public class Object { 


static int k; 


public static void main()
{     
	int a = 1;
	k = func(a);
	
	
}   

public static int func(int a)
{    
	return a + 1;
	
	
}   
}

   


C:\javaRT\java\lang>javap -v Object
Compiled from "Object.java"
public class java.lang.Object
  SourceFile: "Object.java"
  minor version: 0
  major version: 0
  Constant pool:
const #1 = Method       #3.#15; //  java/lang/Object.func:(I)I
const #2 = Field        #3.#16; //  java/lang/Object.k:I
const #3 = class        #17;    //  Object
const #4 = Asciz        k;
const #5 = Asciz        I;
const #6 = Asciz        <init>;
const #7 = Asciz        ()V;
const #8 = Asciz        Code;
const #9 = Asciz        LineNumberTable;
const #10 = Asciz       main;
const #11 = Asciz       func;
const #12 = Asciz       (I)I;
const #13 = Asciz       SourceFile;
const #14 = Asciz       Object.java;
const #15 = NameAndType #11:#12;//  func:(I)I
const #16 = NameAndType #4:#5;//  k:I
const #17 = Asciz       java/lang/Object;

{
static int k;

public java.lang.Object();
  Code:
   Stack=0, Locals=1, Args_size=1
   0:   return
  LineNumberTable:
   line 8: 0

public static void main();
  Code:
   Stack=1, Locals=1, Args_size=0
   0:   iconst_1
   1:   istore_0
   2:   iload_0
   3:   invokestatic    #1; //Method func:(I)I
   6:   putstatic       #2; //Field k:I
   9:   return
  LineNumberTable:
   line 16: 0
   line 17: 2
   line 20: 9

public static int func(int);
  Code:
   Stack=2, Locals=1, Args_size=1
   0:   iload_0
   1:   iconst_1
   2:   iadd
   3:   ireturn
  LineNumberTable:
   line 24: 0

}


C:\javaRT\java\lang>