/*
 * Stack.java
 *
 * Created on May 18, 2004, 6:25 PM
 */

/**
 *  This class simulates stack frame operation
 *
 * @author  isagai
 */
public class Stack {
    
    static final int   START_CLINIT = 0;
    static final int   START_MAIN = 1;
    static final int   MAX_STACK_SIZE = 2;
    static final int   MAX_LOCAL_SIZE = 3;
    static final int   MAX_METHOD_STACKS = 4;
    
    static final int   RETURN_TYPE = 0;
    static final int   NUM_PARAMETERS = 1;
    static final int   CODE_LENGTH = 2;
    
    static final int   SIZE_FRAME_DATA= 3;
    static final int   RETURN_TYPE_OFFSET = 0;
    static final int   RETURN_ADDRESS_OFFSET = 1;
    static final int   LINK_OFFSET = 2;
    
    
    
    
    //
    // data structure in classfiles
    //
    
    static short [] Class_Data = new short [5];
    
    //
    // data structure in method
    //
    
    static int [] Method_Data = new int [3];
    
    static byte b = (byte) 0xb1;
    
    
    
    //  using these for  testing
    static byte[] ram0  = {
        0x00, 0x00, 0x00, 0x1F, 0x00, 0x02, 0x00, 0x01, 0x00, 0x0A, 0x00, 0x00, 0x00, (byte)0x35, 0x00, 0x00,
        0x00, 0x48, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, (byte)0xB1, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0A, 0x04, 0x3B, 0x1A, (byte)0xB8, 0x00,
        0x35, (byte)0xB3, 0x00, 0x48, (byte)0xB1, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00,
        0x04, 0x1A, 0x04, 0x60,(byte) 0xAC, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        
        
    };
    
    
    //  frame data area
    static int[] frame_data = new int [SIZE_FRAME_DATA];
    
    
    // constant values for classfile
    
    static int frame_size;         // for a class
    static int Data_1Z=0;
    
    
    
    //  addresses  in word for RAM1 -- stack
    static int base_pointer =0;
    //points to the beginning of current stack
    static int TopPtr = -1;
    // TopPtr of stack
    static int end_of_ram1;       // to check  over flow
    
    static int Data_1R;  //  for reading RAM 1
    static int Data_1W;  //  for writing RAM 1
    static int [] ram1 = new int [256];  // stack
    
    //  addresses  in bytes for RAM0
    
    
    static int  return_address=0;  // points to the top of stack
    static int  program_counter=1;  // points to the top of stack
    static int  temp_byte_address;  // temporary register
    
    
    //    unsigned 8 i;
    
    static byte[] Bytes = new byte[8];   // read from ram0
    static int Pc_byte_0 = 0;
    
    
    /** Creates a new instance of Stack */
    public Stack() {
    }
    
    
    
    // stack operations---------------------------------------------
    
    
    /** pushing an item to the top */
    public static void Push(int datain) {
        ram1[++TopPtr]= datain; 
        
        System.out.println("pushing " + datain );
        
    }
    
    
    /** pop an item from the top */
    public static int Pop() {
        int val = ram1[TopPtr];
        ram1[TopPtr--]= 0; // clear memory
         System.out.println("popping " + val );
        return val;
        
    }
    
    
    /** Creates a new instance of Stack */
    public static void printStack() {
        
        System.out.println("base pointer:" +base_pointer);
        for(int i =0; i<=TopPtr; i++) {
            System.out.println("i " + i + ":" + ram1[i]);
        }
    }
    
    /** prints class data */
    public static void printClassData() {
        
        System.out.println("class data:");
        
        System.out.print("clinit start address " );
        System.out.println
        (Integer.toString( Class_Data[START_CLINIT], 16));
        
        System.out.print("main start address " );
        System.out.println
        (Integer.toString( Class_Data[START_MAIN], 16));
        
        System.out.print("operand stack size " );
        System.out.println
        (Integer.toString( Class_Data[MAX_STACK_SIZE], 16));
        
        System.out.print("local variable size " );
        System.out.println
        (Integer.toString( Class_Data[MAX_LOCAL_SIZE], 16));
        
        System.out.print("Max frame size " );
        System.out.println
        (Integer.toString( Class_Data[MAX_METHOD_STACKS], 16));
        
    }
    
    
    
    /** prints method data */
    public static void printMethodData() {
        
        System.out.println("method data:");
        
        System.out.print("return type " );
        System.out.println
        (Integer.toString( Method_Data[RETURN_TYPE], 16));
        
        System.out.print("no. parameters " );
        System.out.println
        (Integer.toString( Method_Data[NUM_PARAMETERS], 16));
        
        System.out.print("code length " );
        System.out.println
        (Integer.toString( Method_Data[CODE_LENGTH], 16));
        
        
    }
    
    // PushFrame()
/* ------------------------------------------------------------------
 *
 *  creates a new frame
 *
 *
 */
    public static void PushFrame(int [] Method_Data, int currentPC) {
        
        
        System.out.println("pushing frame " );
        
        if ((TopPtr + frame_size) > end_of_ram1) {
            
            // error condition
        }
        
        
        //temp_byte_address = program_counter;
        // program_counter = new_address;
        
        TopPtr = TopPtr + Class_Data[MAX_LOCAL_SIZE]
        - Method_Data[NUM_PARAMETERS];
        
        SetFrameData(Method_Data[RETURN_TYPE],currentPC,base_pointer);
        
        base_pointer
        = TopPtr - SIZE_FRAME_DATA -
        Class_Data[MAX_LOCAL_SIZE] + 1;
        
        
        
        
    }
    
    
    // PopFrame()
/* -------------------------------------------------------------------
 *
 *  pops the top frame
 *
 *
 */
    
    public static void PopFrame() {
        System.out.println("popping frame " );
        // pop everything in operand stack
        int temp_address;
        temp_address= base_pointer + SIZE_FRAME_DATA
        + Class_Data[MAX_LOCAL_SIZE ] -1;
        
        
        while(TopPtr >= base_pointer) {
            Data_1R=  Pop();
            if (TopPtr==temp_address-1)
                frame_data[LINK_OFFSET] = Data_1R ;
            else if (TopPtr==temp_address -2)
                frame_data[RETURN_ADDRESS_OFFSET] = Data_1R ;
            else if (TopPtr==temp_address -3)
                frame_data[RETURN_TYPE_OFFSET] = Data_1R ;
            
        }
        
        base_pointer = frame_data[LINK_OFFSET];
        Pc_byte_0 = frame_data[RETURN_ADDRESS_OFFSET];
        System.out.println("pc =  " + Pc_byte_0);
        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        byte b;
           
        
        
        int counter = 0;
        int numBytes;
        
        
        Pc_byte_0 = 0;
        
        
        
        numBytes = 2;
        
        while(counter<5) {
            ReadNBytes(numBytes, Bytes);
            Class_Data[ counter ] = GetShort(Bytes);
            counter++;
        }
        printClassData();
        InitializeFrame();
        
        // process static initializer
        Pc_byte_0 =  Class_Data[START_CLINIT];
        
        
        if (Pc_byte_0  != 0x00) {
            
            //      ReadMethodData();
            //     ProcessInstructions();
            
        }
        
        // process static initializer
        Pc_byte_0 =  Class_Data[START_MAIN ];
        
        
        if (Pc_byte_0  != 0x00) {
            
            ReadMethodData();
            printMethodData();
            SetFrameData(0,0,0);
            System.out.println("about to process main" );
            printStack();
            ProcessInstructions();
            
        }
        
        
    }
    
    
    
    
    // ReadNBytes()
/* -------------------------------------------------------------------
 *
 *  read n bytes from ram0
 *
 *
 */
    
    public static void ReadNBytes(int N, byte [] Bytes ) {
        
        int i =0;
        while ( i < N) {
            
            Bytes[i] =  ram0 [Pc_byte_0];
            i++;
            Pc_byte_0++;
        }
        
        
    }
    
    // for assemblying bytes
    
    
    public static byte GetByte(byte [] Bytes)
    { return Bytes[0];}
    
    public static short GetShort(byte [] Bytes) {
        short result = 0;
        
        result += (Bytes[0] & 0x000000FF);
        result <<= 8;
        
        
        
        result += Bytes[1]& 0x000000FF;
        return result;
    }
    
    public static int GetWord(byte [] Bytes) {
        int result = 0;
        for (int i = 0; i<3; i++) {
            result += (Bytes[i] & 0x000000FF);
            result <<= 8;
        }
        result += Bytes[3]& 0x000000FF;
        return result;
    }
    
    
    
    // InitializeFrame()
/* -------------------------------------------------------------------
 * a one
 *  set up initial frame
 *
 *
 */
    
    public static void InitializeFrame() {
        
        frame_size = Class_Data[ MAX_STACK_SIZE ] +
        Class_Data[ MAX_LOCAL_SIZE ] + SIZE_FRAME_DATA;
        
        TopPtr = TopPtr + Class_Data[ MAX_LOCAL_SIZE ];
        
        
    }
    
    
    
    // ReadMethodData()
/* --------------------------------------------------------------------
 *
 *  read method housekeeping information
 *
 *
 */
    
    
    public static void ReadMethodData() {
        
        int numBytes;
        int i;
        i = 0;
        while ( i < 3) {
            
            numBytes = 4;
            
            ReadNBytes( numBytes,Bytes);
            Method_Data[ i ] = GetWord(Bytes);
            i++;
            
        }
        
    }
    
    
    // SetFrameData()
/* -------------------------------------------------------------------
 *
 *  set up frame data
 *
 *
 */
    
    public static  void SetFrameData(int rt, int ra, int bp ) {
        
        int k;
        
        Data_1W = rt;
        Push( Data_1W );
        Data_1W = ra;  // returnaddress
        Push( Data_1W );
        Data_1W = bp;  // returnaddress
        Push( Data_1W );
        
        
    }
    
    
    // ProcessInstructions()
/* -------------------------------------------------------------------
 *
 *  process instructions
 *
 *
 */
    
    
    public static void ProcessInstructions() {
        
        int numBytes;
        boolean more =true;
        
        
        do{
            
            // read instruction
            numBytes = 1;
            ReadNBytes(numBytes, Bytes );
            
            //  decode instruction
            more = Decode(Bytes[0], more);
            
            
        }while(more);
        
    }
    
    
    
    // Decode()
/* -------------------------------------------------------------------
 *
 *  decode instructions
 *
 *
 */
    
    
    public static boolean Decode(byte instruction, boolean more) {
        int numBytes=0;
        // instr;
        // unsigned 8 ch;
        //instr = instruction;
        
        
        switch(instruction) {
            
            case (0x11):  // sipush
                numBytes = 2;
                break;
            case ((byte) 0xb3):  // put static
                numBytes = 2;
                break;
                
            case ((byte)0xb2):  // get static
                numBytes = 2;
                break;
                
            case (0x60):  // iadd
                numBytes = 0;
                break;
                
            case (0x64):  // isub..
                numBytes = 0;
                break;
                
            case (0x12):  // ldc
                numBytes = 1;
                break;
                
            case (0x1a):  // iload0
                numBytes = 0;
                break;
                
            case (0x1b):  // iload1
                numBytes = 0;
                break;
                
            case (0x3b):  // istore0
                numBytes = 0;
                break;
                
            case (0x3c):  // istore0
                numBytes = 0;
                break;
                
            case (0x10):  // bipush
                numBytes = 1;
                break;
                
            case ((byte)0xa4):  // if_icmple
                numBytes = 2;
                break;
                
            case ((byte)0xa7):  // goto
                numBytes = 2;
                break;
                
            case (0x04):  // iconst_1
                numBytes = 0;
                break;
                
            case ((byte)0xb8):  // invoke static
                numBytes = 2;
                break;
                
            case ((byte)0xac):  // ireturned
                numBytes = 0;
                break;
                
            case ((byte)0xb1):  // return
                numBytes = 0;
                break;
                
        }
        
        //PrintByte(instr);
        // PrintInstr(instr);
        char ch []= ByteUtility.toHex( instruction );
        System.out.println("instruction " + ch[0] + ch[1]);
        
        if( numBytes!= 0)
            ReadNBytes( numBytes, Bytes);
        
        
        switch(instruction) {
            
            case (0x11):  // sipush
                //Sipush(numBytes, Bytes);
                break;
            case ((byte)0xb3):  // put static
                //PutStatic(numBytes, Bytes);
                break;
                
            case ((byte)0xb2):  // get static
                // GetStatic(numBytes, Bytes);
                break;
                
            case (0x60):  // iadd
                IAdd()  ;
                break;
                
            case (0x64):  // isub
                //ISub();
                break;
                
            case (0x12):  // ldc
                //Ldc(Bytes);
                break;
                
            case (0x1a):  // iload0
                Iload_0();
                break;
                
            case (0x1b):  // iload1
                //Iload_1();
                break;
                
            case (0x3b):  // istore0
                Istore_0();
                break;
                
            case (0x3c):  // istore1
                // Istore_1();
                break;
                
            case (0x10):  // bipush
                Bipush(Bytes);
                break;
                
            case ((byte) 0xa4):  // if_icmple
                // If_icmple(Bytes, Pc_byte_0 );
                break;
                
            case ((byte)0xa7):  // goto
                //  Goto(Bytes, Pc_byte_0 );
                break;
                
            case (0x04):  // iconst_1
                Iconst_1();
                break;
                
            case ((byte)0xb8):  // invoke static
                InvokeStatic();
                break;
                
            case ((byte)0xac):  // ireturn
                Ireturn();
                break;
                
            case ((byte)0xb1):  // return
                
                more = false;
                break;
                
        }
        
        printStack();
        return more;
        
    }
    
    
    
    // PutStatic()
/* --------------------------------------------------------------------
 *
 *  put a value in a static field
 *
 *
 */
    
    
    public static void  InvokeStatic() {
        
        int nextMethod = GetShort(Bytes) ;
        int currentPC = Pc_byte_0;
        Pc_byte_0  = nextMethod;
        ReadMethodData() ;
        printMethodData();
        
        PushFrame(Method_Data, currentPC);
        
        
        
    }
    // Bipush()
/* -------------------------------------------------------------------
 *
 *  push a byte
 *
 *
 */
    
    
    
    public static void Bipush(byte [] Bytes) {
        int buff = GetByte(Bytes);
        
        Push(buff);
        
    }
    
    // Bipush()
/* -------------------------------------------------------------------
 *
 *  push a byte
 *
 *
 */
    
    
    
    public static void Ireturn() {
        int buff = Pop(); //save the return value;
        
        PopFrame();
        Push(buff);
    }
    
    
    
    // Iconst_1()
/* --------------------------------------------------------------------
 *
 *  push 1
 *
 *
 */
    
    
    
    public static void Iconst_1() {
        
        
        Push(1);
        
        
        
    }
    
    
    
    // Istore_0()
/* -------------------------------------------------------------------
 *
 *  store int into local variable
 *
 *
 */
    
    
    public static void Istore_0() {
        
        int local_index;
        local_index  = base_pointer;
        
        Data_1W = Pop();
        ram1[local_index]= Data_1W;
        
        
    }
    
    // Iload_0()
/* -------------------------------------------------------------------
 *
 *  load int from local variable
 *
 *
 */
    
    
    public static void Iload_0() {
        
        int local_index;
        local_index  = base_pointer;
        
        Data_1W = ram1[local_index];
        Push(Data_1W);
        
        
    }
    
    
    
    // IAdd()
/* -------------------------------------------------------------------
 *
 *
 *  adds 2 ints
 *
 */
    
    
    public static void IAdd( ) {
        
        
        int buff0 = Pop();
        int buff1 = Pop();
        int buff2 = buff1 + buff0;
        Push(buff2);
        
    }
    
}

