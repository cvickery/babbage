		ARC, A subset of the Sparc Assembly Language

This directory contains the directory ARCJavaTools.

The directories contain an ARC simulator written in Java.

The  simulator has a Graphical User Interface, making it easy to use and understand.

It should be used if:

a) you have access to Java version 1.1 or higher SDK or JRE, and
b) you will be running it on the machine where Java resides or you have
a high-bandwidth connection between your X-server and the machine running
Java.

The Java 1.1 JRE Java Runtime Environment and the Java 1.1 SDK developers
kit is available without charge from Sun for Solaris and Windows machines
at www.sunsoft.com.  For Macintosh users, the Java 1.1 runtime is
known as MRJ, and is available at www.apple.com.  You must also download
and install the MRJ SDK, including JBindery, which must be used to run
the ARCJavaTools.

See the README files in the ARCJavaTools directory for more details.


For information about the ARC architecture, see 

Please send bug reports to pocabugs@cs.rutgers.edu. Place "ARC Tools Bug"
in the message header.

