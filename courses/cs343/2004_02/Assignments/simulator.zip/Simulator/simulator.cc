//  parser.cc
/*
 *    Read command lines and parse them -- C/C++ version.
 *
 *    This is the main routine for the ARC simulator assigned for
 *    CS-343, Spring 2004.
 *
 *    C. Vickery
 *    March 2004
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ARGS  256

//  Command Processing Functions
//  ==================================================================

//  Function prototype
typedef void implement_t( int argc, char *args[] );

//  Declare all procesing functions
extern implement_t 
           doPC, doQuit, doLoad, doMemory, doRegister, doStep, doRun;

//  Processing function implementations
//  ==================================================================


//  doQuit()
//  ------------------------------------------------------------------
/*
 *    Exit the program.
 */
  void doQuit( int n, char *args[] )
  { 
    exit( 0 ); 

  }

//  doLoad()
//  ------------------------------------------------------------------
/*
 *    Load files into the simulator's memory.
 *    Each line of each file should contain two hexadeciaml numbers
 *    separated by one or more spaces or tabs.  The first is a memory
 *    byte address, and the second is the value to be stored at that
 *    address.  Invalid lines are interpreted as having an address
 *    and/or value of zero.
 *
 *    *** Implementation Incomplete ***
 */
  void doLoad( int n, char *args[] )
  {
    //  Open each file named in the command, and load it into memory
    for (int i = 0; i < n; i++)
    {
      FILE *f = fopen( args[i], "r" );
      if ( f == 0 )
      {
        //  Error opening file, try any others given on command line
        perror( args[i] );
        continue;
      }
      //  Load the file into memory
      char in_buf[ 256 ];
      char *nxt;
      while ( true )
      {
        fgets( in_buf, sizeof( in_buf ) - 1, f );
        if ( feof( f ) )
        {
          break;
        }
        unsigned long address = strtoul( in_buf, &nxt, 16 );
        unsigned long value   = strtoul( nxt, 0, 16 );
        // *** Replace following line with call to memory_write() *** //
        printf ( "Storing %08lX into location %08lX\n", value, address );
      }
      printf( "Loaded: %s\n", args[i] );
    }
  }

//  doPC()
//  ------------------------------------------------------------------
/*
 *    Load a value into the Program Counter
 */
  void
  doPC( int nargs, char *args[] )
  {
    if ( nargs != 1 )
    {
      fprintf( stderr, 
          "You must enter exactly one value to load into the PC.\n" );
      return;
    }
    fprintf( stderr, "doPC() not implemented yet\n" );
  }

//  doRegister()
//  ------------------------------------------------------------------
/*
 *    Display a register or a range of registers.
 */
  void
  doRegister( int nargs, char *args[] )
  {
    fprintf( stderr, "doRegister() not implemented yet\n" );
  }

//  Other unimplemented functions
//  ------------------------------------------------------------------
  void
  doMemory( int nargs, char *args[] )
  {
    fprintf( stderr, "doMemory() not implemented yet\n" );
  }
  void
  doStep( int nargs, char *args[] )
  {
    fprintf( stderr, "doStep() not implemented yet\n" );
  }
  void
  doRun( int nargs, char *args[] )
  {
    fprintf( stderr, "doRun() not implemented yet\n" );
  }
//  Dispatch Table
//  ------------------------------------------------------------------
/*
 *    The dispatch table is used to associate command names with
 *    functions that implement those commands.
 */

struct  dispatch_entry
{
  const char  *name;
  implement_t *implement;
};

dispatch_entry  dispatch_table[] =
{
  //  Full names
  { "go",       doRun       },
  { "load",     doLoad      },
  { "memory",   doMemory    },
  { "pc",       doPC        },
  { "quit",     doQuit      },
  { "register", doRegister  },
  { "run",      doRun       },
  { "step",     doStep      },

  //  Aliases
  { "g",        doRun       },
  { "l",        doLoad      },
  { "m",        doMemory    },
  { "p",        doPC        },
  { "q",        doQuit      },
  { "r",        doRegister  },
  { "ru",       doRun       },
  { "s",        doStep      },
};
const int dispatch_length = 
                  sizeof( dispatch_table ) / sizeof( dispatch_entry );


//  main()
//  ------------------------------------------------------------------
/*
 *    Read command lines from stdin, parse them into whitespace
 *    separated tokens, and call a function associated with the
 *    command name.
 */
  int
  main( int argc, char *argv[] )
  {
    char  cmd_buf[512];
    char  *cmd_name;
    char  *args[MAX_ARGS];
    bool  found;
    
    while ( true )
    {
      //  Prompt for, and read command line.
      fprintf( stdout, "Command: " );
      fgets( cmd_buf, sizeof( cmd_buf ) - 1, stdin );
      if (feof( stdin ) )
      {
        exit( 0 );
      }

      //  Parse command line into tokens.  First one is the command
      //  name.
      cmd_name = strtok( cmd_buf, " \t\n\r" );
      if ( cmd_name == 0 )
        continue; //  Ignore blank lines
      int nargs = 0;
      while ( true )
      {
        args[nargs] = strtok( 0, " \t\n\r" );
        if ( args[nargs] != 0 )
          nargs++;
        else
          break;
      }
      //  Look up the command in the dispatch table
      found = false;
      for (int i = 0; i < dispatch_length; i++ )
      {
        if ( 0 == strcasecmp( dispatch_table[i].name, cmd_name ) )
        {
          dispatch_table[i].implement( nargs, args );
          found = true;
          break;
        }
      }
      if ( !found )
      {
        fprintf( stderr, "Unrecognized command: %s\n", cmd_name );
      }
    }
  }
