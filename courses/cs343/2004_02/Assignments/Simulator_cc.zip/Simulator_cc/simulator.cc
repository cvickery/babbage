//  $Id: simulator.cc,v 1.3 2004/03/25 04:15:22 vickery Exp $
/*
 *    Read command lines and parse them -- C/C++ version.
 *
 *    This is the main routine for the ARC simulator assigned for
 *    CS-343, Spring 2004.
 *
 *    C. Vickery
 *    March 2004
 *
 *    $Log: simulator.cc,v $
 *    Revision 1.3  2004/03/25 04:15:22  vickery
 *    Added memory.cc and simulator.h to the project.
 *    Implemented the memory operations, completed the load command,
 *    and implemented the memory command.
 *    Added copyright notices to all files.
 *
 *    Revision 1.2  2004/03/24 04:02:22  vickery
 *    Added version control macros.
 *
 *
 *  Copyright (c) 2004, Queens College of the City University
 *  of New York.  All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or
 *  without modification, are permitted provided that the
 *  following conditions are met:
 *
 *      * Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the
 *        following disclaimer.
 * 
 *      * Redistributions in binary form must reproduce the
 *        above copyright notice, this list of conditions and
 *        the following disclaimer in the documentation and/or
 *        other materials provided with the distribution.  
 * 
 *      * Neither the name of Queens College of CUNY
 *        nor the names of its contributors may be used to
 *        endorse or promote products derived from this
 *        software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *  CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "simulator.h"

#define MAX_ARGS  256
static uint32_t mem_size = 1024 * 1024;

//  Command Processing Functions
//  ==================================================================

//  Function prototype
typedef void implement_t( int argc, char *args[] );

//  Declare all procesing functions
extern implement_t 
           doPC, doQuit, doLoad, doMemory, doRegister, doStep, doRun;

//  Processing function implementations
//  ==================================================================


//  doQuit()
//  ------------------------------------------------------------------
/*
 *    Exit the program.
 */
  void doQuit( int n, char *args[] )
  { 
    exit( 0 ); 

  }

//  doLoad()
//  ------------------------------------------------------------------
/*
 *    Load files into the simulator's memory.
 *    Each line of each file should contain two hexadeciaml numbers
 *    separated by one or more spaces or tabs.  The first is a memory
 *    byte address, and the second is the value to be stored at that
 *    address.  Invalid lines are interpreted as having an address
 *    and/or value of zero.
 *
 */
  void doLoad( int n, char *args[] )
  {
    //  Open each file named in the command, and load it into memory
    for (int i = 0; i < n; i++)
    {
      FILE *f = fopen( args[i], "r" );
      if ( f == 0 )
      {
        //  Error opening file, try any others given on command line
        perror( args[i] );
        continue;
      }
      //  Load the file into memory
      uint32_t  num_words   = 0;
      uint32_t  min_address = mem_size - 1;
      uint32_t  max_address = 0;
      char in_buf[ 256 ];
      char *nxt;
      while ( true )
      {
        fgets( in_buf, sizeof( in_buf ) - 1, f );
        if ( feof( f ) )
        {
          break;
        }
        uint32_t address = strtoul( in_buf, &nxt, 16 );
        uint32_t value   = strtoul( nxt, 0, 16 );
        memory_write( address,  value );
        if ( address > max_address ) max_address = address;
        if ( (address > 0) && address < min_address ) 
          min_address = address;
        num_words++;
      }
      printf( "Loaded %d words from %s into %08X - %08X\n", 
                       num_words, args[i], min_address, max_address );
    }
  }

//  doPC()
//  ------------------------------------------------------------------
/*
 *    Load a value into the Program Counter
 */
  void
  doPC( int nargs, char *args[] )
  {
    if ( nargs != 1 )
    {
      fprintf( stderr, 
          "You must enter exactly one value to load into the PC.\n" );
      return;
    }
    fprintf( stderr, "doPC() not implemented yet\n" );
  }

//  doRegister()
//  ------------------------------------------------------------------
/*
 *    Display a register or a range of registers.
 */
  void
  doRegister( int nargs, char *args[] )
  {
    fprintf( stderr, "doRegister() not implemented yet\n" );
  }

//  Other unimplemented functions
//  ------------------------------------------------------------------
  void
  doMemory( int nargs, char *args[] )
  {
    uint32_t first_addr = 0;
    uint32_t last_addr  = 0;
    switch ( nargs )
    {
      case 1:
        first_addr  = strtoul( args[0], 0, 16 );
        last_addr   = first_addr;
        break;

      case 2:
        first_addr  = strtoul( args[0], 0, 16 );
        last_addr   = strtoul( args[1], 0, 16 );
        break;

      default:
        fprintf( stderr,
                      "Usage: memory start_address [end_address]\n" );
        return;
    }
    
    //  Display the memory words, 4 per line
    for (uint32_t this_addr = first_addr & 0xFFFFFFF0; 
                  this_addr <= last_addr;
                  this_addr += 4 )
    {
      if ( 0 == (this_addr & 0x0F) )
      {
        printf( "%08X: ", this_addr );
      }
      if ( this_addr < first_addr )
      {
        printf( "         " );
      }
      else
      {
        printf( " %08X", memory_read( this_addr ) );
      }
      if ( 0x0C == (this_addr & 0x0F) )
      {
        printf( "\n" );
      }
    }
    printf( "\n" );
  }
  void
  doStep( int nargs, char *args[] )
  {
    fprintf( stderr, "doStep() not implemented yet\n" );
  }
  void
  doRun( int nargs, char *args[] )
  {
    fprintf( stderr, "doRun() not implemented yet\n" );
  }
//  Dispatch Table
//  ------------------------------------------------------------------
/*
 *    The dispatch table is used to associate command names with
 *    functions that implement those commands.
 */

struct  dispatch_entry
{
  const char  *name;
  implement_t *implement;
};

dispatch_entry  dispatch_table[] =
{
  //  Full names
  { "go",       doRun       },
  { "load",     doLoad      },
  { "memory",   doMemory    },
  { "pc",       doPC        },
  { "quit",     doQuit      },
  { "register", doRegister  },
  { "run",      doRun       },
  { "step",     doStep      },

  //  Aliases
  { "g",        doRun       },
  { "l",        doLoad      },
  { "m",        doMemory    },
  { "p",        doPC        },
  { "q",        doQuit      },
  { "r",        doRegister  },
  { "ru",       doRun       },
  { "s",        doStep      },
};
const int dispatch_length = 
                  sizeof( dispatch_table ) / sizeof( dispatch_entry );


//  main()
//  ------------------------------------------------------------------
/*
 *    Read command lines from stdin, parse them into whitespace
 *    separated tokens, and call a function associated with the
 *    command name.
 */
  int
  main( int argc, char *argv[] )
  {
    char  cmd_buf[512];
    char  *cmd_name;
    char  *args[MAX_ARGS];
    bool  found;
 
    //  Initialize memory
    memory_init( mem_size );

    while ( true )
    {
      //  Prompt for, and read command line.
      fprintf( stdout, "Command: " );
      fgets( cmd_buf, sizeof( cmd_buf ) - 1, stdin );
      if (feof( stdin ) )
      {
        exit( 0 );
      }

      //  Parse command line into tokens.  First one is the command
      //  name.
      cmd_name = strtok( cmd_buf, " \t\n\r" );
      if ( cmd_name == 0 )
        continue; //  Ignore blank lines
      int nargs = 0;
      while ( true )
      {
        args[nargs] = strtok( 0, " \t\n\r" );
        if ( args[nargs] != 0 )
          nargs++;
        else
          break;
      }
      //  Look up the command in the dispatch table
      found = false;
      for (int i = 0; i < dispatch_length; i++ )
      {
        if ( 0 == strcasecmp( dispatch_table[i].name, cmd_name ) )
        {
          dispatch_table[i].implement( nargs, args );
          found = true;
          break;
        }
      }
      if ( !found )
      {
        fprintf( stderr, "Unrecognized command: %s\n", cmd_name );
      }
    }
  }
