package ArcSim;

import ArcSim.Vickery.*;

public class Alu {

  // ALU operations (fig 6-4)
  public static final int op_andcc = 0;
  public static final int op_orcc = 1;
  public static final int op_norcc = 2;
  public static final int op_addcc = 3;
  public static final int op_srl = 4;
  public static final int op_and = 5;
  public static final int op_or = 6;
  public static final int op_nor = 7;
  public static final int op_add = 8;
  public static final int op_lshift2 = 9;
  public static final int op_lshift10 = 10;
  public static final int op_simm13 = 11;
  public static final int op_sext13 = 12;
  public static final int op_inc = 13;
  public static final int op_incpc = 14;
  public static final int op_rshift5 = 15;

  // condition codes set by *cc family of instructions
  public static int Z,V,C,N;


  //============================================================================
  // instructions
  public static int do_and(int A, int B) {
    Print.debug( "Alu.do_and("+A+","+B+")" );
    return A & B;
  }

  public static int do_andcc(int A, int B) {
    Print.debug( "Alu.do_andcc("+A+","+B+")" );
    int C;
    C = A & B;
    calcCC(A,B,C);
    return A & B;
  }

  public static int do_or(int A, int B) {
    Print.debug( "Alu.do_or("+A+","+B+")" );
    return A | B;
  }

  public static int do_orcc(int A, int B) {
    Print.debug( "Alu.do_orcc("+A+","+B+")" );
    int C;
    C = A | B;
    calcCC(A,B,C);
    return A | B;
  }

  public static int do_nor(int A, int B) {
    Print.debug( "Alu.do_nor("+A+","+B+")" );
   return -1 - (A|B);
  }

  public static int do_norcc(int A, int B) {
    Print.debug( "Alu.do_norcc("+A+","+B+")" );
    int C;
    C = -1 - (A|B);
    calcCC(A,B,C);
    return C;
  }

  public static int do_add(int A, int B) {
    Print.debug( "Alu.do_add("+A+","+B+")" );
    return A + B;
  }

  public static int do_addcc(int A, int B) {
    Print.debug( "Alu.do_addcc("+A+","+B+")" );
    int C;
    C = A + B;
    calcCC(A,B,C);
    return A + B;
  }

  public static int do_srl(int A, int B) {
    Print.debug( "Alu.do_srl("+A+","+B+")" );
    return A>>B;
  }

  public static int do_lshift2(int A) {
    Print.debug( "Alu.do_lshift2("+A+")" );
    return A<<2;
  }

  public static int do_lshift10(int A) {
    Print.debug( "Alu.do_lshift10("+A+")" );
    return A<<10;
  }

  public static int do_rshift5(int A) {
    Print.debug( "Alu.do_rshift5("+A+")" );
    return A>>5;
  }

  public static int do_simm13(int A) {
    Print.debug( "Alu.do_simm13("+A+")" );
    return A & 0x1FFF;
  }

  public static int do_sext13(int A) {
    Print.debug( "Alu.do_sext13("+A+")" );
    return (A<<19 >> 19);
  }

  public static int do_inc(int A) {
    Print.debug( "Alu.do_inc("+A+")" );
    return A+1;
  }

  public static int do_incpc(int A) {
    Print.debug( "Alu.do_incpc("+A+")" );
    return A+4;
  }

  // calculate condition codes
  public static void calcCC(int A,int B,int C) {
    Z = (C==0)?1:0;
    N = (C<0)?1:0;
    V = (  A>0 && B>0 && C<0  ||  A<0 && B<0 && C>0  )?1:0;
    C = 2; // &&& 2do
  }

}
