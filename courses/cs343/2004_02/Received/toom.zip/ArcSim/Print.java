package ArcSim;

public class Print {

  public static void normal( String msg ) {
    System.out.println( msg );
  }

  public static void debug( String msg ) {
    System.out.println( "### " + msg );
  }

  public static void error( String msg ) {
    System.out.println( "!!! " + msg );
  }


}