package ArcSim;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class MemoryOnt
{
  // constants
  public static final int nop = 0;
  public static final int read = 1;
  public static final int write = 2;

  // data members
  public static long[] storage;
  public static int size;

  // methods
  public static void write(long addr, long val) {
  }

  public static long read(long addr) {
    return 0;
  }

  public void init(int size_p) {
    size = size_p;
    storage = new long[size_p];
  }

}
