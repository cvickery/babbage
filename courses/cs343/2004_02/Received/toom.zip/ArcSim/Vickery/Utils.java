package ArcSim.Vickery;

//  Class Utils
//  ------------------------------------------------------------------
/**
 *    Some utility functions for the simulator.
 */
  public class Utils
  {
    private static String hexTable = "0123456789ABCDEF";
    private static String binTable = "01";

    //  hexize()
    //  --------------------------------------------------------------
    /**
     *    Convert an int to a String of hex digits.
     *
     *    @param  val Value to convert.
     *    @param  len Length of result.  Will be zero padded.
     */
      public static String hexize( long val, int len )
      {
        StringBuffer sb = new StringBuffer( "" );
        for (int i = 0; i < len; i++ )
        {
          sb.append( hexTable.charAt( (int)(val & 0x0F )));
          val >>= 4;
        }
        return sb.reverse().toString();
      }

      public static String binize( long val, int len )
      {
        StringBuffer sb = new StringBuffer( "" );
        for (int i = 0; i < len; i++ )
        {
          sb.append( binTable.charAt( (int)(val & 0x01 )));
          val >>= 1;
        }
        return sb.reverse().toString();
      }

      public static String hexize( int val, int len )
      {
        return hexize( (long)val , len );
      }

      /*
      public static int hexString2int( String hexStr ) {

      }
      */

/*
     public static int findBase( String str ) {
       int posUnderscore = str.indexOf("_");
       if ( posUnderscore == -1 )
         return 10; // no underscore
       if posUnderscore
     }
*/
}
