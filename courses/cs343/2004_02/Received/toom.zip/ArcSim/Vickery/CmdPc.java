package ArcSim.Vickery;

import ArcSim.*;
import java.util.Vector;

public class CmdPc implements Command
{
  public void doit(Vector args)
  {
    // verify num of args is correct
    int nargs = args.size();
    if ( (nargs > 1) )
    {
      System.err.println( "Usage: pc [new value]");
      return;
    }

    try {
      switch (nargs) {
        case 0:
          System.out.println("PC=" + Reg.get(Reg.PC));
          break;
        case 1:
          //System.out.println("PC was    " + Reg.get(Reg.PC));
          Reg.set(Reg.PC, Integer.parseInt( (String) args.get(0)));
          //System.out.println("PC became " + Reg.get(Reg.PC));
      }
    }
    catch( Exception e ) {
      System.out.println("oops: "+e);
    }

  }
}
