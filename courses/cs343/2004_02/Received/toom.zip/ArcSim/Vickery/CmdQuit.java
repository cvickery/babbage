package ArcSim.Vickery;

import java.util.*;

//  Class QuitCommand
//  -------------------------------------------------------------------
/**
 *    Handle the simulator's quit command by exiting the program.
 *
 *    @param  args  Ignored
 */
public class CmdQuit implements Command
{
  public void doit( Vector args )
  {
    System.out.println("Bye bye.");
    System.exit( 0 );
  }
}
