package ArcSim.Vickery;

//  Class DispatchEntry
//  ------------------------------------------------------------------
/**
 *    Each entry in the dispatch table gives the name of the command
 *    and a reference to the singleton class that processes it.
 */
  public class DispatchEntry
  {
    //  Public members
    public  String  name;
    public  Command command;

  //  Constructor
  //  ----------------------------------------------------------------
    public DispatchEntry( String n, Command c )
    {
      name    = n;
      command = c;
    }
  }
