package ArcSim.Vickery;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

//  Class Simulator
//  -------------------------------------------------------------------
/**
 *    Executes user commands interactively.
 */
public class Simulator
{
  //  Create command processors
  static Command load     = new CmdLoad();
  static Command quit     = new CmdQuit();

  static Command memory   = new CmdMemory();
  static Command pc       = new CmdPc();
  static Command register = new CmdRegister();

  static Command run      = new CmdUnimplemented();
  static Command step     = new CmdStep();

  static Command debug    = new CmdDebug();

  //  Dispatch Table for invoking possible commands.
  static DispatchEntry dispatchTable[] =
  {
    new DispatchEntry( "quit",      quit      ),
    new DispatchEntry( "q",         quit      ),
    new DispatchEntry( "load",      load      ),
    new DispatchEntry( "l",         load      ),
    new DispatchEntry( "memory",    memory    ),
    new DispatchEntry( "mem",       memory    ),
    new DispatchEntry( "m",         memory    ),
    new DispatchEntry( "register",  register  ),
    new DispatchEntry( "r",         register  ),
    new DispatchEntry( "go",        run       ),
    new DispatchEntry( "g",         run       ),
    new DispatchEntry( "step",      step      ),
    new DispatchEntry( "s",         step      ),
    new DispatchEntry( "debug",     debug     ),
    new DispatchEntry( "d",         debug     ),
    new DispatchEntry( "pc",        pc        ),
  };

  //  main()
  //  ----------------------------------------------------------------
  /*
   *    Reads command lines and executes them.
   *
   *    @param  args  Not used.
   */
  public static void main(String[] argv) throws MemoryAccessException
  {
    //  Create memory array.
    Memory.init( 100000 );
    //  Read command lines from stdin and execute them
    BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
    String inBuf = null;

    while ( true )
    {
      try
      {
        //  Prompt for and read a command line
        System.out.print( "Command: " );
        inBuf = br.readLine();
      }
      catch (IOException e)
      {
        System.err.println(e);
        continue;
      }

      //  Tokenize the command line
      StringTokenizer st = new StringTokenizer( inBuf, " \t\r\n" );
      String cmd_name = st.hasMoreTokens() ? st.nextToken() : null;
      if ( cmd_name == null )
      {
        System.err.println("ignoring blank line");
        continue;   //  Ignore blank lines.
      }
      Vector  args = new Vector();
      while ( st.hasMoreTokens() )
      {
        args.addElement( st.nextElement() );
      }

      System.err.println( "Simulator received: " + cmd_name + " " + args );

      //  Look up the command name in the dispatch table and invoke the
      //  command's doit() method to process the command.
      boolean found = false;
      for (int i = 0; i < dispatchTable.length; i++ )
      {
        if ( dispatchTable[i].name.equalsIgnoreCase( cmd_name ) )
        {
          dispatchTable[i].command.doit( args );
          found = true;
          break;
        }
      }
      if ( ! found )
      {
        System.err.println( "Unrecognized command: " + cmd_name );
      }
    }
  }
}
