package ArcSim.Vickery;

import ArcSim.*;
import java.util.Vector;

//  Class MemoryCommand
//  ------------------------------------------------------------------
/**
 *  Process commands of the form, "memory start [end]"
 */
  public class CmdStep implements Command
  {
    public void doit(Vector args)
    {
      try {
        Processor.do_major();
      }
      catch (MemoryAccessException mae) {
        System.err.println(mae);
      }
    }
  }

      /*
      int nargs = args.size();
      if ( (nargs < 1) || (nargs > 2) )
      {
        System.err.println( "Usage: memory start [end]");
        return;
      }
      long first_addr, last_addr;
      try
      {
        first_addr  = Long.parseLong( (String)args.elementAt(0), 16 );
        last_addr   = (nargs == 1) ? first_addr :
                      Long.parseLong( (String)args.elementAt(1), 16 );
      }
      catch (NumberFormatException e)
      {
        System.err.println(e);
        return;
      }
      //  Print four words per line.
      long start_addr = first_addr & 0x0FFFFFFF0L;
      try
      {
        for (long addr = start_addr; addr <= last_addr; addr += 4 )
        {
          if ( (addr%16) == 0 )
          {
            System.out.print( Utils.hexize(addr, 8) + ": " );
          }
          if ( addr < first_addr )
          {
            System.out.print( "         " );
          }
          else
          {
            System.out.print( " " +
                Utils.hexize( Memory.read( (int) addr ), 8) );
          }
          if ( (addr & 0x0CL) == 0x0Cl )
          {
            System.out.println();
          }
        }
        System.out.println();
      }
      catch (MemoryAccessException e1)
      {
        System.err.println(e1);
        return;
      }
      */

