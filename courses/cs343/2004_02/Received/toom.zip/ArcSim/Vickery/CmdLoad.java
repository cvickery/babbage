package ArcSim.Vickery;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

//  Class LoadCommand
//  -------------------------------------------------------------------
/**
 *    Loads files into the simulator's memory.
 */
public class CmdLoad implements Command
{
  //  doit()
  //  ----------------------------------------------------------------
  /**
   *    For each file name in the argument list, open the file and
   *    process each line.  Each line consists of a hexadecimal
   *    address, whitespace, and a hexadecimal value to be loaded into
   *    simulated memory at the specified byte address.
   *
   *    @param args List of files to be loaded.
   */
  public void doit(Vector args)
  {
    FileReader fr = null;

    //  Iterate over file names passed as arguments
    Iterator iter = args.iterator();
    while ( iter.hasNext() )
    {
      String fileName = (String) iter.next();
      try
      {
        //  Open the file and process each line
        BufferedReader br = new BufferedReader(
                                         new FileReader( fileName ) );
        String inBuf = br.readLine();
        int num_words = 0;
        long max_address = 0x000000000;
        long min_address = 0x0FFFFFFFFL;
        while ( inBuf != null )
        {
          long address, value;
          StringTokenizer st = new StringTokenizer( inBuf );
          try
          {
            int numTokens = st.countTokens();
            switch ( numTokens )
            {
              case 1:
                inBuf = br.readLine();
                continue; //  Ignore lines with just one token;
              case 2:
                break;    //  Normal case
              default:
                System.err.println( "Invalid bin file at line " +
                                   (num_words + 1) + "\n  " + inBuf );
            }
            address  = Long.parseLong( st.nextToken(), 16 );
            value    = Long.parseLong( st.nextToken(), 16 );
            Memory.write( (int)(0x0FFFFFFFF & address),
                                  (int) (0x0FFFFFFFF & value) );
            num_words++;
            if ( address > max_address ) max_address = address;
            if ( address < min_address ) min_address = address;
          }
          catch ( Exception e )
          {
            System.err.println( e );
            e.printStackTrace();
            address = 0;
            value = 0;
          }
          inBuf = br.readLine();
        }

        String min_a = Utils.hexize( min_address, 8 );
        String max_a = Utils.hexize( max_address, 8 );
        System.out.println( "Loaded " + num_words + " words from " +
              fileName + " into locations " + min_a + " - " + max_a );
      }
      catch ( IOException ioe )
      {
        System.err.println( ioe.getMessage() );
      }
    }
  }
}
