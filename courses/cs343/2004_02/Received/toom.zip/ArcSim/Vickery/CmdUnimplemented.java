package ArcSim.Vickery;

import java.util.Vector;

//  Class UnimplementedCommand
//  -------------------------------------------------------------------
/**
 *    Placeholder for commands that haven't been written yet.
 */
  public class CmdUnimplemented implements Command
  {
    public void doit(Vector args)
    {
      System.err.println( "Not implemented yet!" );
    }
  }
