package ArcSim.Vickery;

import ArcSim.*;
import java.util.*;

//  Class MemoryCommand
//  ------------------------------------------------------------------
/**
 *  Process commands of the form, "memory start [end]"
 */
  public class CmdDebug implements Command
  {
    public void doit(Vector args)
    {
      String instr = (String)args.get(0);
      int A = Integer.parseInt( (String)args.get(1) );
      int B = Integer.parseInt( (String)args.get(2) );
      System.out.println("input A= " + Utils.hexize(A,8) + " = " + Utils.binize(A,32) + " = " + A);
      System.out.println("input B= " + Utils.hexize(B,8) + " = " + Utils.binize(B,32) + " = " + B);

      int result=-1;
      System.out.println("executing: "+args);
      if     ( instr.compareToIgnoreCase("and")==0 )
        result = Alu.do_and(A,B);
      else if( instr.compareToIgnoreCase("andcc")==0 )
        result = Alu.do_andcc(A,B);

      else if( instr.compareToIgnoreCase("or")==0 )
        result = Alu.do_or(A,B);
      else if( instr.compareToIgnoreCase("orcc")==0 )
        result = Alu.do_orcc(A,B);

      else if( instr.compareToIgnoreCase("nor")==0 )
        result = Alu.do_nor(A,B);
      else if( instr.compareToIgnoreCase("norcc")==0 )
        result = Alu.do_norcc(A,B);

      else if( instr.compareToIgnoreCase("add")==0 )
        result = Alu.do_add(A,B);
      else if( instr.compareToIgnoreCase("addcc")==0 )
        result = Alu.do_addcc(A,B);

      else if( instr.compareToIgnoreCase("srl")==0 )
        result = Alu.do_srl(A,B);
      else if( instr.compareToIgnoreCase("lshift2")==0 )
        result = Alu.do_lshift2(A);
      else if( instr.compareToIgnoreCase("lshift10")==0 )
        result = Alu.do_lshift10(A);
      else if( instr.compareToIgnoreCase("rshift5")==0 )
        result = Alu.do_rshift5(A);

      else if( instr.compareToIgnoreCase("simm13")==0 )
        result = Alu.do_simm13(A);
      else if( instr.compareToIgnoreCase("sext13")==0 )
        result = Alu.do_sext13(A);

      else if( instr.compareToIgnoreCase("inc")==0 )
        result = Alu.do_inc(A);
      else if( instr.compareToIgnoreCase("incpc")==0 )
        result = Alu.do_incpc(A);

      else
        System.err.println("unknown ARC instruction");

      System.out.println("output = " + Utils.hexize(result,8) + " = " + Utils.binize(result,32) + " = " + result);

      // also condition codes
      System.out.print("condition codes: ");
      if ( Alu.Z==1 ) System.out.print("Z ");
      if ( Alu.N==1 ) System.out.print("N ");
      if ( Alu.V==1 ) System.out.print("V ");
      if ( Alu.C==1 ) System.out.print("C ");
      System.out.println();
    }
  }
