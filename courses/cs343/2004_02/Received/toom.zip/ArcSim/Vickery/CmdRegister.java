package ArcSim.Vickery;

import ArcSim.*;
import java.util.Vector;

public class CmdRegister implements Command
{
  public void doit(Vector args)
  {
    int nargs = args.size();
    if ( nargs<1 || nargs>2 )
    {
      System.err.println( "Usage: register reg_id [new_value]");
      return;
    }

    int arg1=0,arg2=0;
    arg1 = Integer.parseInt( (String)args.get(0) );
    if ( args.size()>1 )
      arg2 = Integer.parseInt( (String)args.get(1) );

    // verify valid register specified
    if ( arg1<0 || arg1>37 ) {
      System.err.println("invalid register specified. must be from 0 to 37.");
      return;
    }

    try {
      switch ( nargs ) {
        case 1:
          System.out.println("Reg["+arg1+"]=" + Utils.hexize( Reg.get(arg1) , 8 ) );
          break;
        case 2:
          //System.out.println("Reg["+arg1+"] was " + Reg.get(arg1) );
          Reg.set(arg1,arg2);
          //System.out.println("Reg["+arg1+"] became " + Reg.get(arg1) );
          break;
        default:
          System.err.println("Internal error occurred in CmdRegister");
      }
    }
    catch( Exception e ) {
      System.out.println("oops: "+e);
    }
  }
}
