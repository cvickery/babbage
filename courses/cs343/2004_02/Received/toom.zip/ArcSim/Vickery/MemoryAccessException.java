package ArcSim.Vickery;

//  Class MemoryAccessException
//  ------------------------------------------------------------------
/**
 *
 */
public class MemoryAccessException extends Exception
{
  //  Inherited constructors
  //  ----------------------------------------------------------------
  /**
   *  No-arg constructor.  Private so that there must be a message
   *  or throwable object associated with the exception.
   */
  private MemoryAccessException()
  {
    super();
  }
  /**
   * Message arg version.
   * @param message Explains what went wrong.
   */
  public MemoryAccessException(String message)
  {
    super(message);
  }
  /**
   * Throwable arg version.
   * @param cause   Underlying cause. (Not expected.)
   */
  public MemoryAccessException(Throwable cause)
  {
    super(cause);
  }
  /**
   * Message and throwable args version.
   * @param message Explanation.
   * @param cause   Underlying cause.
   */
  public MemoryAccessException(String message, Throwable cause)
  {
    super(message, cause);
  }
}
