package ArcSim.Vickery;

import java.util.Vector;

//  Class Command
//  -------------------------------------------------------------------
/**
 *    Declares doit(), the method each command must implement.
 */
  public interface Command
  {
    public void doit( Vector args );
  }
