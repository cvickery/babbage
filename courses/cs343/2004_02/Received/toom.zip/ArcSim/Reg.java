package ArcSim;

public class Reg
{
  // register file
  private static int[] reg = new int[38];

  // well-known register ids
  public static final int R0 = 0;
  public static final int PC = 32;
  public static final int T0 = 33;
  public static final int T1 = 34;
  public static final int T2 = 35;
  public static final int T3 = 36;
  public static final int IR = 37;

  // methods to read and write registers
  public static int get( int rid ) throws Exception {
    if ( rid<R0 || rid >IR )
      throw new Exception("Reg: invalid register id specified: "+rid);
    if (rid==0)
      return 0;
    return reg[rid];
  }

  public static void set( int rid , int val ) throws Exception {
    if ( rid<R0 || rid >IR )
      throw new Exception("Reg: invalid register id specified: "+rid);
    Print.normal("Reg "+rid+" was "+get(rid)+" becomes "+val);
    if (rid!=0)
      reg[rid]=val;
  }

}
