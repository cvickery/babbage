package ArcSim;

import ArcSim.Vickery.*;

public class Processor
{

  // instructions
  public static final int instr_nop     = 0x00; // 00 000 000
  public static final int instr_sethi   = 0x20; // 00 100 xxx
  public static final int instr_branch  = 0x10; // 00 010 xxx
  public static final int instr_call    = 0x40; // 01 xxx xxx
  public static final int instr_addcc   = 0x90; // 10 010 000
  public static final int instr_andcc   = 0x91; // 10 010 001
  public static final int instr_orcc    = 0x92; // 10 010 010
  public static final int instr_orncc   = 0x96; // 10 010 110
  public static final int instr_srl     = 0xA6; // 10 100 110
  public static final int instr_jmpl    = 0xB8; // 10 111 000
  public static final int instr_ld      = 0xC0; // 11 000 000
  public static final int instr_st      = 0xC4; // 11 000 100

  // DECODE outputs
  // page 192, fig 6-2 shows instruction formats
  public static int op, rd, op3, op2, rs1, rs2, simm13, i_bit, op_code, imm22,
      disp22, disp30, cond;

  // statistics
  public static int statMinorCycles = 0;
  public static int statMajorCycles = 0;


  //============================================================================
  public static boolean do_major() throws MemoryAccessException
  {
    Print.debug( "do_major()" );

    try {
      fetch();   // use PC to read instruction from memory
      decode();  // pick bits from 32-bit instruction to determine various operands
      if ( execute() )
        update_pc();
    }
    catch (Exception e) {
      Print.error("Error in do_major(): " + e);
      return false;
    }

    // --- update execution stats
    statMajorCycles++;

    return true;
  }

  //============================================================================
  // Game plan:
  // 1. perform ALU operation
  // 2. perform memory read/write/noop
  public static void do_minor(int A_source, int B_source, int C_dest, int alu_func, int mem_op)
      throws ArcSim.Vickery.MemoryAccessException,Exception
  {

    Print.debug( "do_minor( " + A_source +","+ B_source +","+ C_dest +","+ alu_func +","+ mem_op + " )" );

    //  Validate Arguments
    if ( (A_source < 0) || (A_source > 37))
      throw new IllegalArgumentException("Invalid A Register (" + A_source + ")");
    if ( (B_source < 0) || (B_source > 37))
      throw new IllegalArgumentException("Invalid B Register (" + B_source + ")");
    if ( (C_dest < 0) || (C_dest > 37))
      throw new IllegalArgumentException("Invalid C Register (" + C_dest + ")");
    if ( (alu_func < 0) || (alu_func > 15))
      throw new IllegalArgumentException("Invalid ALU Function (" + alu_func + ")");
    if ( (mem_op < 0) || (mem_op > 3))
      throw new IllegalArgumentException("Invalid Memory Operation (" + mem_op + ")");

    // data
    int alu_result = 0;
    int mem_result = 0;

    // --- perform ALU part
    int A = Reg.get(A_source);
    int B = Reg.get(B_source);
    switch (alu_func) {
      case Alu.op_andcc   :    alu_result = Alu.do_andcc   (A,B);    break;
      case Alu.op_orcc    :    alu_result = Alu.do_orcc    (A,B);    break;
      case Alu.op_norcc   :    alu_result = Alu.do_norcc   (A,B);    break;
      case Alu.op_addcc   :    alu_result = Alu.do_addcc   (A,B);    break;
      case Alu.op_srl     :    alu_result = Alu.do_srl     (A,B);    break;
      case Alu.op_and     :    alu_result = Alu.do_and     (A,B);    break;
      case Alu.op_or      :    alu_result = Alu.do_or      (A,B);    break;
      case Alu.op_nor     :    alu_result = Alu.do_nor     (A,B);    break;
      case Alu.op_add     :    alu_result = Alu.do_add     (A,B);    break;
      case Alu.op_lshift2 :    alu_result = Alu.do_lshift2 (A  );    break;
      case Alu.op_lshift10:    alu_result = Alu.do_lshift10(A  );    break;
      case Alu.op_simm13  :    alu_result = Alu.do_simm13  (A  );    break;
      case Alu.op_sext13  :    alu_result = Alu.do_sext13  (A  );    break;
      case Alu.op_inc     :    alu_result = Alu.do_inc     (A  );    break;
      case Alu.op_incpc   :    alu_result = Alu.do_incpc   (A  );    break;
      case Alu.op_rshift5 :    alu_result = Alu.do_rshift5 (A  );    break;
      default:
        Print.error("Error in Alu.do_minor(): unknown alu_op");
    }

    // --- perform memory part
    switch (mem_op) {
      case Memory.read:
        //Print.debug("# A_source = " + A_source);
        //Print.debug("# Reg.get(A_source) = " + Reg.get(A_source));
        //Print.debug("# Memory.read( Reg.get(A_source) ) = " + Memory.read( Reg.get(A_source) ));

        mem_result = Memory.read( Reg.get(A_source) );
        break;
      case Memory.write:
        Memory.write( Reg.get(A_source), Reg.get(B_source) );
        break;
      case Memory.nop:
        break;
      default:
        Print.error("Error in Alu.do_minor(): unknown mem_op");
    }

    Print.debug("# do_minor(): mem_result="+mem_result+" alu_result="+alu_result);

    if (mem_op == Memory.read)
      Reg.set(C_dest, mem_result);
    else
      Reg.set(C_dest, alu_result);

    // --- update execution stats
    statMinorCycles++;
  }

  //============================================================================
  public static void fetch() throws MemoryAccessException,Exception {
    Print.debug( "fetch()" );
    do_minor(Reg.PC, 0, Reg.IR, Alu.op_and, Memory.read);
  }

  //============================================================================
  public static void decode() throws Exception {
    System.out.println( "### decode()" );
    // page 192, fig 6-2 shows instruction formats
    //op, rd, op3, op2, rs1, rs2, simm13, i_bit, op_code, imm22, disp22, disp30, cond;
    op     = (Reg.get(Reg.IR) >> 30) & 0x03; //31-30, 2 bits
    op2    = (Reg.get(Reg.IR) >> 22) & 0x07; //24-22, 3 bits
    op3    = (Reg.get(Reg.IR) >> 19) & 0x3F; //24-19, 6 bits
    op_code= (op << 6) | op3;

    rd     = (Reg.get(Reg.IR) >> 25) & 0x1F; //29-25, 5 bits
    rs1    = (Reg.get(Reg.IR) >> 14) & 0x1F; //18-14, 5 bits
    rs2    = (Reg.get(Reg.IR)      ) & 0x1F; //4-0  , 5 bits
    simm13 = (Reg.get(Reg.IR)      ) & 0x1FFF; //12-0 , 13 bits
    i_bit  = (Reg.get(Reg.IR) >> 13) & 0x01; //13
    imm22  = (Reg.get(Reg.IR)      ) & 0x3FFFFF; //21-0, 22 bits
    disp22 = imm22;
    disp30 = (Reg.get(Reg.IR)      ) & 0x3FFFFFFF; //29-0, 30 bits
    cond   = (Reg.get(Reg.IR) >> 25) & 0x0F; //28-25, 4 bits

    // DEBUG
    Print.debug("everything: " + Utils.hexize(Reg.get(Reg.IR),8) );
    Print.debug("op: " + Utils.binize(op,2) );
    Print.debug("op2: " + Utils.binize(op2,3) );
    Print.debug("op3: " + Utils.binize(op3,6) );
    Print.debug("op_code: " + Utils.binize(op_code,8) );
    Print.debug("rd: " + Utils.binize(rd,5) );
    Print.debug("rs1: " + Utils.binize(rs1,5) );
    Print.debug("rs2: " + Utils.binize(rs2,5) );
    Print.debug("simm13: " + Utils.binize(simm13,13) );
    Print.debug("i_bit: " + Utils.binize(i_bit,1) );
    Print.debug("imm22: " + Utils.binize(imm22,22) );
    Print.debug("disp30: " + Utils.binize(disp30,30) );
    Print.debug("cond: " + Utils.binize(cond,4) );
  }

  //============================================================================
  public static boolean execute() throws /*UnimplementedOpCode*/Exception {
    // return true if PC should be word-incremented. false if instruction itself set PC.
    Print.debug("execute()" );

    //if ( Options.doTraceInstructions() ) {
    //  System.out.println( Disassemble.dasm());
    //}

    switch ( op_code )
    {

      // public static final int instr_addcc   = 0x90; // 10 010 000
      case instr_addcc:
        if ( i_bit == 0 ) {
          do_minor( rs1, rs2, rd, Alu.op_addcc, Memory.nop );
          return true;
        }
        else {
          do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13, Memory.nop );
          do_minor( rs1, Reg.T0, rd, Alu.op_addcc, Memory.nop );
          return true;
        }

      // public static final int instr_andcc   = 0x91; // 10 010 001
      case instr_andcc:
        if ( i_bit == 0 ) {
          do_minor( rs1, rs2, rd, Alu.op_andcc, Memory.nop );
          return true;
        }
        else {
          do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13, Memory.nop );
          do_minor( rs1,    Reg.T0, rd,     Alu.op_andcc,  Memory.nop );
          return true;
        }

      // public static final int instr_orcc    = 0x92; // 10 010 010
      case instr_orcc:
        if ( i_bit == 0 ) {
          do_minor( rs1, rs2, rd, Alu.op_orcc, Memory.nop );
          return true;
        }
        else {
          do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13, Memory.nop );
          do_minor( rs1,    Reg.T0, rd,     Alu.op_orcc,   Memory.nop );
          return true;
        }

      // public static final int instr_orncc   = 0x96; // 10 010 110
      case instr_orncc:
        if ( i_bit == 0 ) {
          do_minor( rs1, rs2, rd, Alu.op_norcc, Memory.nop );
          return true;
        }
        else {
          do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13, Memory.nop );
          do_minor( rs1,    Reg.T0, rd,     Alu.op_norcc,  Memory.nop );
          return true;
        }

      // public static final int instr_srl     = 0xA6; // 10 100 110
      case instr_srl:
        if ( i_bit == 0 ) {
          do_minor( rs1, rs2, rd, Alu.op_srl, Memory.nop );
          return true;
        }
        else {
          do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13, Memory.nop );
          do_minor( rs1,    Reg.T0, rd,     Alu.op_srl,    Memory.nop );
          return true;
        }

      // public static final int instr_sethi   = 0x20; // 00 100 xxx
      case instr_sethi:
        do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13,   Memory.nop );  // get immediate to temp
        do_minor( Reg.T0, Reg.R0, rd    , Alu.op_lshift10, Memory.nop );  // shift from temp to rd
        return true;

      // public static final int instr_branch  = 0x10; // 00 010 xxx


      // public static final int instr_call    = 0x40; // 01 xxx xxx
      // public static final int instr_jmpl    = 0xB8; // 10 111 000

      // public static final int instr_ld      = 0xC0; // 11 000 000
      case instr_ld:
        if ( i_bit == 0 ) {
          do_minor( rs1,    rs2,    Reg.T0, Alu.op_add,     Memory.nop  ); // add 2 regs
          do_minor( Reg.T0, Reg.R0, Reg.T0, Alu.op_lshift2, Memory.nop  ); // cnv byte addr to word addr
          do_minor( Reg.T0, Reg.R0, rd,     Alu.op_add,     Memory.read ); // read
          return true;
        }
        else {
          do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13,  Memory.nop  ); // get immediate
          do_minor( rs1,    Reg.T0, Reg.T0, Alu.op_add,     Memory.nop  ); // reg+immed
          do_minor( Reg.T0, Reg.R0, Reg.T0, Alu.op_lshift2, Memory.nop  ); // cnv byte addr to word addr
          do_minor( Reg.T0, Reg.R0, rd,     Alu.op_add,     Memory.read ); // read
          return true;
        }

      // public static final int instr_st      = 0xC4; // 11 000 100
      case instr_st:
        if ( i_bit == 0 ) {
          do_minor( rs1,    rs2,    Reg.T0, Alu.op_add,     Memory.nop  ); // add 2 regs
          do_minor( Reg.T0, Reg.R0, Reg.T0, Alu.op_lshift2, Memory.nop  ); // cnv byte addr to word addr
          do_minor( Reg.T0, Reg.R0, rd,     Alu.op_add,     Memory.write ); // read
          return true;
        }
        else {
          do_minor( Reg.IR, Reg.R0, Reg.T0, Alu.op_sext13,  Memory.nop  ); // get immediate
          do_minor( rs1,    Reg.T0, Reg.T0, Alu.op_add,     Memory.nop  ); // reg+immed
          do_minor( Reg.T0, Reg.R0, Reg.T0, Alu.op_lshift2, Memory.nop  ); // cnv byte addr to word addr
          do_minor( Reg.T0, Reg.R0, rd,     Alu.op_add,     Memory.write ); // read
          return true;
        }

      // public static final int instr_nop     = 0x00; // 00 000 000
      case instr_nop:
        return true;

      default:
      {
        throw new /*UnimplementedOpCode*/Exception( "unknown op_code " + op_code );
      }
    }

  }

  //============================================================================
  public static void update_pc() throws Exception {
    Print.debug("update_pc()" );
    do_minor( Reg.PC, Reg.R0, Reg.PC, Alu.op_incpc, Memory.nop );
  }

}
