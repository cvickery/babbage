#ifndef MEMORY_INCLUDE
#define MEMORY_INCLUDE


typedef struct
{
  void * * page;                      
  unsigned int page_size;             
  unsigned int log_of_page_size;      
  unsigned int bit_mask;              
} memory_unit;

memory_unit * create_new_memory_unit(unsigned int page_size);				
unsigned int read(memory_unit * memory, unsigned int address);				
void write(memory_unit * memory, unsigned int address, unsigned int value); 
void destroy_memory_unit(memory_unit * memory);								

#endif

