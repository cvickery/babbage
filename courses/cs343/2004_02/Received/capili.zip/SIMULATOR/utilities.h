#ifndef UTILITIES_INCLUDE
#define UTILITIES_INCLUDE

void assert_malloc(const void * pointer_to_test, const char * error_msg); 
unsigned long int hex_to_binary(const char * string_to_convert);          
signed int log_base_2(unsigned long int number);                          
signed int sign_extend(signed int number, unsigned int bits);             

#endif

