#include <stdio.h>
#include <stdlib.h>
#include "utilities.h"

void assert_malloc(const void * pointer_to_test, const char * error_msg)
{
  if (pointer_to_test == NULL)
  {
    fprintf(stder, error_msg);
    exit(1);
  }

  return;
}

unsigned long int hex_to_binary(const char * string_to_convert)
{
  unsigned long int accumulator = 0; 
  int i = 0; 
  char next_char;

  while((next_char = string_to_convert[i]) != 0x00) 
  {
    accumulator <<= 4; 

    
    if (next_char >= '0' && next_char <= '9')
      accumulator += (next_char - '0');
    else if (next_char >= 'A' && next_char <= 'F')
      accumulator += ((next_char - 'A') + 10);
    else if (next_char >= 'a' && next_char <= 'f')
      accumulator += ((next_char - 'a') + 10);
    else
      break;

    i++;
  }

  return accumulator;
}

signed int log_base_2(unsigned long int number)
{
  int answer = -1;
  while(number != 0)
  {
    answer++;
    number >>= 1;
  }

  return answer;
}

signed int sign_extend(signed int number, unsigned int bits)
{
  int sign_bit_mask = 0x1 << (bits - 1);

  if (number & sign_bit_mask)
  { 
    int data_mask = -sign_bit_mask;
    number |= data_mask;
  }
  else
  { 
    int data_mask = sign_bit_mask - 1;
    number &= data_mask;
  }

  return number;
}

