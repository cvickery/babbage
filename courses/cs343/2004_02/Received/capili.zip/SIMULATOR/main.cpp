#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "cpu.h"
#include "utilities.h"

#define SIZE_OF_COMMAND_BUFFER 256

int main(int argc, char * argv[])
{
  char command_buffer[SIZE_OF_COMMAND_BUFFER]; 
  char * next_token = NULL; 
  int quit = 0; 

  arc_cpu * cpu = create_cpu();
  assert_malloc(cpu, "Unable to create cpu in main().\n");

  printf("Welcome to ARC simulator.\n");

  while(!quit)
  {
    printf("\n[Q]uit. Exits the simulator.\n[L]oad <file_name>. Loads a file.\n[P]C <address>. Set the program counter to <address>.\n[M]emory <start> [<end>]. Inspect contents of memory.\n[S]tep. Execute next instruction.\n[Re]gisters <start> [<end>]. Inspect contents of registers.\n");

    fgets(command_buffer, SIZE_OF_COMMAND_BUFFER, stdin); 

    
    unsigned int i;
    for (i = 0; command_buffer[i] != 0x00; i++)
    {
      command_buffer[i] = tolower(command_buffer[i]);
      if (command_buffer[i] == 0x0A || command_buffer[i] == 0x0D) 
      {
        command_buffer[i] = ' ';
        command_buffer[i + 1] = 0x00;
        break;
      }
    }

    
    next_token = strtok(command_buffer, " "); 
    if (!strcmp(command_buffer, "quit") || !strcmp(command_buffer, "q")) 
      quit = 1;
    else if (!strcmp(command_buffer, "load") || !strcmp(command_buffer, "l")) 
    {
      next_token = strtok(NULL, " "); 

      if (next_token == NULL)
        printf("Usage: Load <file_name>\n");
      else
      { 
        FILE * input = fopen(next_token, "rb");
        if (input == NULL) 
          printf("Error: Unable to open file %s for load command.\n", next_token);
        else
        {
          int next_char = 0;
          char load_buffer[9]; 
          load_buffer[8] = 0x00; 
          unsigned int address; 
          unsigned int value; 
          while (next_char != EOF) 
          {
            printf(".");
            for (i = 0; i < 8; i++) 
            {
              load_buffer[i] = fgetc(input);
            }
            address = hex_to_binary(load_buffer);
            next_char = fgetc(input);

            if (next_char != '\t') 
            {
              if (fgetc(input) != EOF) 
                printf("Parse error in file. Aborting.\n");
              break;
            }

            for (i = 0; i < 8; i++) 
            {
              load_buffer[i] = fgetc(input);
            }
            value = hex_to_binary(load_buffer);

            write(cpu->main_memory, address, value); 

            next_char = fgetc(input);
            if (next_char != 0x0A)
            {
              printf("Parse error in file. Aborting.\n");
              break;
            }
          }
          printf("Load successful.\n");
        }
      }
    }
    else if (!strcmp(command_buffer, "pc") || !strcmp(command_buffer, "p")) 
    {
      next_token = strtok(NULL, " "); 
      if (next_token == NULL)
      {
        printf("Usage: PC <address>\n");
        continue;
      }

      unsigned int new_address = hex_to_binary(next_token);

      cpu->registers[CPU_PROGRAM_COUNTER] = new_address;
    }
    else if (!strcmp(command_buffer, "memory") || !strcmp(command_buffer, "m")) 
    {
      next_token = strtok(NULL, " "); 
      if (next_token == NULL)
      {
        printf("Usage: memory <start> [<end>]\n");
        continue;
      }

      unsigned int start_address = hex_to_binary(next_token);

      next_token = strtok(NULL, " "); 
      if (next_token == NULL) 
        printf("%08X: %08X\n", start_address, read(cpu->main_memory, start_address));
      else
      {
        unsigned int end_address = hex_to_binary(next_token);
        unsigned int j;
        for (i = start_address; i <= end_address; i += 16)
        {
          printf("%08X:", i);
          for (j = i; j < (i + 16) && j <= end_address; j += 4)
            printf(" %08X", read(cpu->main_memory, j));
          printf("\n");
        }
      }
    }
    else if (!strcmp(command_buffer, "step") || !strcmp(command_buffer, "s")) 
      cpu_step(cpu);
    else if (!strcmp(command_buffer, "register") || !strcmp(command_buffer, "re")) 
    {
      next_token = strtok(NULL, " "); 
      if (next_token == NULL)
      {
        printf("Usage: register <start> [<end>]\n");
        continue;
      }

      unsigned int start_register = strtol(next_token, NULL, 16);
      if (start_register >= CPU_REGISTER_COUNT)
        start_register = CPU_REGISTER_COUNT - 1;

      next_token = strtok(NULL, " "); 

      if (next_token == NULL) 
        printf("%08X: %08X\n", start_register, cpu->registers[start_register]);
      else
      {
        unsigned int end_register = strtol(next_token, NULL, 16);
        if (end_register >= CPU_REGISTER_COUNT)
          end_register = CPU_REGISTER_COUNT - 1;
        int j;
        for (i = start_register; i <= end_register; i += 4)
        {
          printf("%08X:", i);
          for (j = i; j < (i + 4) && j <= end_register; j++)
            printf(" %08X", cpu->registers[j]);
          printf("\n");
        }
      }
    }
    else
      printf("Invalid command. Please try it again.\n");
  }

  cpu_destroy(cpu);

  return 0;
}

