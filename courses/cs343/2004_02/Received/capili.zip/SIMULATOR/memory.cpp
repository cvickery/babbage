#include <stdlib.h>
#include <stdio.h>
#include "memory.h"
#include "utilities.h"

unsigned int read_big_endian(const void * source) 
{
  const unsigned char * data = (const unsigned char *) source;

  return (data[0] << 24) | (data[1] << 16) | (data[2] << 8) | data[3];
}

void write_big_endian(void * destination, unsigned int value) 
{
  unsigned char * data = (unsigned char *) destination;

  data[0] = (value & 0xFF000000) >> 24;
  data[1] = (value & 0x00FF0000) >> 16;
  data[2] = (value & 0x0000FF00) >> 8;
  data[3] = value & 0x000000FF;

  return;
}


void assert_memory_allocation(memory_unit * memory, unsigned int start, unsigned int end) 
{

  unsigned int start_page = start >> memory->log_of_page_size;
  unsigned int end_page = (end - 1) >> memory->log_of_page_size;
  
  unsigned int i;
  void * * page = memory->page;
  for (i = start_page; i <= end_page; i++)
  {
    if (page[i] == NULL)
    {
      page[i] = (void *) malloc (memory->page_size);
      assert_malloc(page[i], "Unable to allocate new memory in assert_memory_allocation().\nYou're out of RAM. Install more.\n");
    }
  }

  return;
}

memory_unit * create_new_memory_unit(unsigned int new_page_size)
{
  
  void * * page;
  unsigned int page_size;
  unsigned int log_of_page_size;
  unsigned int bit_mask;

  memory_unit * new_memory = (memory_unit *) malloc (sizeof(memory_unit));
  if (new_memory == NULL) 
    return new_memory;

  if((log_of_page_size = log_base_2(new_page_size)) < 0)
  { 
    fprintf(stderr, "Page size must be non-negative.\nPage size set to default of 64kB.\n");
    log_of_page_size = 16; 
  }
  page_size = 0x1 << log_of_page_size; 

  bit_mask = page_size - 1; 

  page = (void * *) malloc (sizeof (void *) * (0x1 << (32 - log_of_page_size))); 
  if (page == NULL)
  {
    free(new_memory);
    return NULL;
  }

  
  new_memory->page = page;
  new_memory->page_size = page_size;
  new_memory->log_of_page_size = log_of_page_size;
  new_memory->bit_mask = bit_mask;

  return new_memory;
}

unsigned int read(memory_unit * memory, unsigned int address)
{
  unsigned int i;
  unsigned int accumulator = 0;

  assert_memory_allocation(memory, address, address + 4); 

  for (i = address; i != address + 4; i++) 
  {
    accumulator <<= 8; 
    accumulator |= ((unsigned char * *)memory->page)[i >> memory->log_of_page_size][i & memory->bit_mask]; 
  }

  return accumulator;
}

void write(memory_unit * memory, unsigned int address, unsigned int value)
{
  unsigned int i;

  assert_memory_allocation(memory, address, address + 4); 

  for (i = address + 3; i != address - 1; i--) 
  {
    ((unsigned char * *)memory->page)[i >> memory->log_of_page_size][i & memory->bit_mask] = value & 0xFF; /* Write the current byte. */
    value >>= 8;
  }

  return;
}

void destroy_memory_unit(memory_unit * memory)
{
  unsigned int i;
  unsigned int page_count;

  if (memory == NULL) 
    return;

  page_count = 0x1 << (32 - memory->log_of_page_size);
  for (i = 0; i < page_count; i++)
    if (memory->page[i] != NULL)
      free(memory->page[i]);
  free(memory->page);
  free(memory); 

  return;
}

