#ifndef CPU_INCLUDE
#define CPU_INCLUDE

#include "memory.h"

#define CPU_REGISTER_COUNT 39

#define CPU_ZERO_REGISTER 0            
#define CPU_STACK_REGISTER 14          
#define CPU_RETURN_REGISTER 15         
#define CPU_PROGRAM_COUNTER 32         
#define CPU_INSTRUCTION_REGISTER 37    
#define CPU_PROCESS_STATUS_REGISTER 38 


#define CPU_OVERFLOW_FLAG_SET 0x00000001
#define CPU_OVERFLOW_FLAG_CLEAR 0xFFFFFFFE
#define CPU_ZERO_FLAG_SET 0x00000002
#define CPU_ZERO_FLAG_CLEAR 0xFFFFFFFD
#define CPU_NEGATIVE_FLAG_SET 0x00000004
#define CPU_NEGATIVE_FLAG_CLEAR 0xFFFFFFFB
#define CPU_CARRY_FLAG_SET 0x00000008
#define CPU_CARRY_FLAG_CLEAR 0xFFFFFFF7

typedef struct
{
  memory_unit * main_memory;							
  unsigned int registers[CPU_REGISTER_COUNT];			
} arc_cpu;


arc_cpu * create_cpu();									
void cpu_step(arc_cpu * cpu);							
void cpu_destroy(arc_cpu * cpu_to_destroy);				

#endif

