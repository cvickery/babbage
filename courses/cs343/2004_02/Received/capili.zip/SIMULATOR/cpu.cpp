#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "cpu.h"
#include "utilities.h"

void cpu_fetch(arc_cpu * cpu)
{
  cpu->registers[CPU_INSTRUCTION_REGISTER] = read(cpu->main_memory, cpu->registers[CPU_PROGRAM_COUNTER]); /* Fetch the instruction. */
  cpu->registers[CPU_PROGRAM_COUNTER] += 4; 

  return;
}

void cpu_execute_branch_or_sethi(arc_cpu * cpu)
{
  unsigned int ir = cpu->registers[CPU_INSTRUCTION_REGISTER];

  unsigned int op2 = (ir >> 22) & 0x7;
  signed int value = sign_extend(ir & 0x003FFFFF, 22);
  if (op2 == 2)
  { 
    unsigned int condition = (ir >> 25) & 0x10;

    if (condition == 0x00) 
    {
    }
    else if (condition == 0x01) 
    {
      if (cpu->registers[CPU_PROCESS_STATUS_REGISTER] & CPU_ZERO_FLAG_SET)
        cpu->registers[CPU_PROGRAM_COUNTER] += ((value - 1) << 2); 
    }
    else if (condition == 0x02) 
    {
      if ((cpu->registers[CPU_PROCESS_STATUS_REGISTER] & CPU_NEGATIVE_FLAG_SET) || (cpu->registers[CPU_PROCESS_STATUS_REGISTER] & CPU_ZERO_FLAG_SET))
        cpu->registers[CPU_PROGRAM_COUNTER] += ((value - 1) << 2); 
    }
    else
    {
      fprintf(stderr, "Unimplemented branch condition.\n");
      exit(1);
    }
  }
  else if (op2 == 4)
  { 

    fprintf(stderr, "Set hi not implemented yet.\n");
  }
  else
  {
    fprintf(stderr, "Invalid instruction encoutered:\nAddress = %p\nInstruction = %p\n", (void *) (cpu->registers[CPU_PROGRAM_COUNTER] - 4), (void *) ir);
    exit(1);
  }

  return;
}

void cpu_execute_call(arc_cpu * cpu)
{
  int ir = cpu->registers[CPU_INSTRUCTION_REGISTER];
  signed int displacement = (ir & 0x4FFFFFFF) << 2; 

  cpu->registers[CPU_PROGRAM_COUNTER] -= 4; 
  cpu->registers[CPU_RETURN_REGISTER] = cpu->registers[CPU_PROGRAM_COUNTER]; 
  cpu->registers[CPU_PROGRAM_COUNTER] += displacement; 

  return;
}

signed int cpu_execute_arithmetic_noop(arc_cpu * cpu, signed int rs1, signed int rs2)
{
  printf("Noop encountered in cpu_execute_arithmetic.\n");

  return 0;
}

signed int cpu_execute_arithmetic_add(arc_cpu * cpu, signed int rs1, signed int rs2)
{
  return rs1 + rs2;
}

signed int cpu_execute_arithmetic_or(arc_cpu * cpu, signed int rs1, signed int rs2)
{
  return rs1 | rs2;
}

signed int cpu_execute_arithmetic_sub(arc_cpu * cpu, signed int rs1, signed int rs2)
{
  return rs1 - rs2;
}

signed int cpu_execute_arithmetic_xorcc(arc_cpu * cpu, signed int rs1, signed int rs2)
{
  int answer = rs1 ^ rs2;

  
  int psr = cpu->registers[CPU_PROCESS_STATUS_REGISTER];

  if (answer < 0)
    psr |= CPU_NEGATIVE_FLAG_SET;
  else
    psr &= CPU_NEGATIVE_FLAG_CLEAR;
  if (answer == 0)
    psr |= CPU_ZERO_FLAG_SET;
  else
    psr &= CPU_ZERO_FLAG_CLEAR;
  psr &= CPU_CARRY_FLAG_CLEAR;
  psr &= CPU_OVERFLOW_FLAG_CLEAR;

  cpu->registers[CPU_PROCESS_STATUS_REGISTER] = psr; 

  return answer;
}

signed int cpu_execute_arithmetic_subcc(arc_cpu * cpu, signed int rs1, signed int rs2)
{
  int answer = rs1 - rs2;

  
  int psr = cpu->registers[CPU_PROCESS_STATUS_REGISTER];

  if (answer < 0)
    psr |= CPU_NEGATIVE_FLAG_SET;
  else
    psr &= CPU_NEGATIVE_FLAG_CLEAR;
  if (answer == 0)
    psr |= CPU_ZERO_FLAG_SET;
  else
    psr &= CPU_ZERO_FLAG_CLEAR;
  if (((rs1 ^ rs2) & 0x80000000) && ((rs1 ^ answer) & 0x80000000))
    psr |= CPU_OVERFLOW_FLAG_SET;
  else
    psr &= CPU_OVERFLOW_FLAG_CLEAR;
  if ((unsigned int) rs1 < (unsigned int) rs2)
    psr |= CPU_CARRY_FLAG_SET;
  else
    psr &= CPU_CARRY_FLAG_CLEAR;

  cpu->registers[CPU_PROCESS_STATUS_REGISTER] = psr; 

  return answer;
}

signed int cpu_execute_arithmetic_sll(arc_cpu * cpu, signed int rs1, signed int rs2)
{
  return rs1 << rs2;
}

signed int (*cpu_execute_arithmetic_subfunction[0x40])(arc_cpu * cpu, signed int rs1, signed int rs2) =
{
  /* 0x00 */
  cpu_execute_arithmetic_add, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_or, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_sub, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  /* 0x10 */
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_xorcc,
  cpu_execute_arithmetic_subcc, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  /* 0x20 */
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_sll,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  /* 0x30 */
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
  cpu_execute_arithmetic_noop, cpu_execute_arithmetic_noop,
};

void cpu_execute_arithmetic(arc_cpu * cpu)
{
  int ir = cpu->registers[CPU_INSTRUCTION_REGISTER];
  int immediate = ir & 0x00002000;
  unsigned int rd = (ir >> 25) & 0x1F;
  signed int rs1 = cpu->registers[(ir >> 14) & 0x1F];
  signed int rs2;
  if (immediate != 0)
    rs2 = sign_extend(ir & 0x1FFF, 13); 
  else
    rs2 = cpu->registers[ir & 0x1F];

  unsigned int opcode3 = (ir >> 19) & 0x3F;

  
  cpu->registers[rd] = cpu_execute_arithmetic_subfunction[opcode3](cpu, rs1, rs2);

  return;
}

signed int cpu_execute_memory_noop(arc_cpu * cpu, signed int rs1, signed int rs2, signed int rd)
{
  printf("Noop encountered in cpu_execute_memory.\n");

  return 0;
}

signed int cpu_execute_memory_load(arc_cpu * cpu, signed int rs1, signed int rs2, signed int rd)
{
  return read(cpu->main_memory, rs1 + rs2);
}

signed int cpu_execute_memory_store(arc_cpu * cpu, signed int rs1, signed int rs2, signed int rd)
{
  printf("%d + %d = %d\n", rs1, rs2, rs1 + rs2);
  write(cpu->main_memory, rs1 + rs2, cpu->registers[rd]);

  return cpu->registers[rd]; 
}

signed int (*cpu_execute_memory_subfunction[0x40])(arc_cpu * cpu, signed int rs1, signed int rs2, signed int rd) =
{
  /* 0x00 */
  cpu_execute_memory_load, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_store, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  /* 0x10 */
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  /* 0x20 */
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  /* 0x30 */
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
  cpu_execute_memory_noop, cpu_execute_memory_noop,
};

void cpu_execute_memory(arc_cpu * cpu)
{
  int ir = cpu->registers[CPU_INSTRUCTION_REGISTER];
  int immediate = ir & 0x00002000;
  unsigned int rd = (ir >> 25) & 0x1F;
  signed int rs1 = cpu->registers[(ir >> 14) & 0x1F];
  signed int rs2;
  if (immediate)
    rs2 = sign_extend(ir & 0x1FFF, 13); 
  else
    rs2 = cpu->registers[ir & 0x1F];

  unsigned int opcode3 = (ir >> 19) & 0x3F;

  
  cpu->registers[rd] = cpu_execute_memory_subfunction[opcode3](cpu, rs1, rs2, rd);

  return;
}

void cpu_execute(arc_cpu * cpu)
{
  int opcode = cpu->registers[CPU_INSTRUCTION_REGISTER] >> 30; 

  if (opcode == 0x0)
    cpu_execute_branch_or_sethi(cpu);
  else if (opcode == 0x1)
    cpu_execute_call(cpu);
  else if (opcode == 0x2)
    cpu_execute_arithmetic(cpu);
  else if (opcode == 0x3)
    cpu_execute_memory(cpu);

  cpu->registers[CPU_ZERO_REGISTER] = 0; 

  return;
}

arc_cpu * create_cpu()
{
  arc_cpu * new_cpu = (arc_cpu *) malloc (sizeof(arc_cpu));
  if (new_cpu == NULL)
    return NULL; 

  new_cpu->main_memory = create_new_memory_unit(0x10000);
  if (new_cpu->main_memory == NULL)
  { 
    free(new_cpu);
    return NULL;
  }

  memset(new_cpu->registers, 0x00, sizeof(new_cpu->registers)); 
  new_cpu->registers[CPU_STACK_REGISTER] = 0x80000000;          
  new_cpu->registers[CPU_PROGRAM_COUNTER] = 0x00000800;         

  return new_cpu;
}

void cpu_step(arc_cpu * cpu)
{
  cpu_fetch(cpu);   
  cpu_execute(cpu); 

  return;
}

void cpu_destroy(arc_cpu * cpu_to_destroy)
{
  if (cpu_to_destroy == NULL)
    return; 

  destroy_memory_unit(cpu_to_destroy->main_memory);
  free(cpu_to_destroy);

  return;
}

