/*  $Id: LoadCommand.java,v 1.2 2004/03/26 02:43:20 vickery Exp $
 * Created on Mar 20, 2004
 *
 *  Copyright (c) 2004, Queens College of the City University
 *  of New York.  All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or
 *  without modification, are permitted provided that the
 *  following conditions are met:
 *
 *      * Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the
 *        following disclaimer.
 * 
 *      * Redistributions in binary form must reproduce the
 *        above copyright notice, this list of conditions and
 *        the following disclaimer in the documentation and/or
 *        other materials provided with the distribution.  
 * 
 *      * Neither the name of Queens College of CUNY
 *        nor the names of its contributors may be used to
 *        endorse or promote products derived from this
 *        software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *  CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 *    $Log: LoadCommand.java,v $
 *    Revision 1.2  2004/03/26 02:43:20  vickery
 *    Implemented class Memory and the memory command.
 *    Completed implementation of the Load command.
 *
 *    Revision 1.1  2004/03/21 03:50:05  vickery
 *    Initial version of student simulator project for CS-343.
 *
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

//  Class LoadCommand
//  -------------------------------------------------------------------
/**
 *    Loads files into the simulator's memory.
 */
public class LoadCommand implements Command
{
  //  doit()
  //  ----------------------------------------------------------------
  /**
   *    For each file name in the argument list, open the file and
   *    process each line.  Each line consists of a hexadecimal
   *    address, whitespace, and a hexadecimal value to be loaded into
   *    simulated memory at the specified byte address.
   * 
   *    @param args List of files to be loaded.
   */
  public void doit(Vector args)
  {
    FileReader fr = null;

    //  Iterate over file names passed as arguments
    Iterator iter = args.iterator();
    while ( iter.hasNext() )
    {
      String fileName = (String) iter.next();
      try
      {
        //  Open the file and process each line
        BufferedReader br = new BufferedReader(
                                         new FileReader( fileName ) );
        String inBuf = br.readLine();
        int num_words = 0;
        long max_address = 0x000000000;
        long min_address = 0x0FFFFFFFFL;
        while ( inBuf != null )
        {
          long address, value;
          StringTokenizer st = new StringTokenizer( inBuf );
          try
          {
            int numTokens = st.countTokens();
            switch ( numTokens )
            {
              case 1:
                inBuf = br.readLine();
                continue; //  Ignore lines with just one token;
              case 2:
                break;    //  Normal case
              default:
                System.err.println( "Invalid bin file at line " +
                                   (num_words + 1) + "\n  " + inBuf );
            }
            address  = Long.parseLong( st.nextToken(), 16 );
            value    = Long.parseLong( st.nextToken(), 16 );
            Memory.memory_write( (int)(0x0FFFFFFFF & address),
                                  (int) (0x0FFFFFFFF & value) );
            num_words++;
            if ( address > max_address ) max_address = address;
            if ( address < min_address ) min_address = address;
          }
          catch ( Exception e )
          {
            System.err.println( e );
            e.printStackTrace();
            address = 0;
            value = 0;
          }
          inBuf = br.readLine();
        }
        
        String min_a = Utils.hexize( min_address, 8 );
        String max_a = Utils.hexize( max_address, 8 );
        System.out.println( "Loaded " + num_words + " words from " +
              fileName + " into locations " + min_a + " - " + max_a );
		
		//Load the first memory location of the instruction into pc
		long temp  = Long.parseLong( (String)min_a, 16 );
      }
      catch ( IOException ioe )
      {
        System.err.println( ioe.getMessage() );
      }
    }
  }
}
