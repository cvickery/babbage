//  Class UnimplementedOpCodeException
//  ------------------------------------------------------------------
/**
 *
 */
public class UnimplementedOpCodeException extends Exception
{
  //  Inherited constructors
  //  ----------------------------------------------------------------
  /**
   *  No-arg constructor.  Private so that there must be a message
   *  or throwable object associated with the exception.
   */
  private UnimplementedOpCodeException()
  {
    super();
  }
  /**
   * Message arg version.
   * @param message Explains what went wrong.
   */
  public UnimplementedOpCodeException(String message)
  {
    super(message);
  }
  /**
   * Throwable arg version.
   * @param cause   Underlying cause. (Not expected.)
   */
  public UnimplementedOpCodeException(Throwable cause)
  {
    super(cause);
  }
  /**
   * Message and throwable args version.
   * @param message Explanation.
   * @param cause   Underlying cause.
   */
  public UnimplementedOpCodeException(String message, Throwable cause)
  {
    super(message, cause);
  }
}
