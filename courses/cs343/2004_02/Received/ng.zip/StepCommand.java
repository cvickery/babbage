import java.util.Vector;

//  Class StepCommand
//  ------------------------------------------------------------------
/**
 *  Process commands of the form, "Step"
 */
  public class StepCommand implements Command
  {

	public void doit(Vector args)
    {
		try{
			int temp = PcCommand.old;
			Register.register_write(32, PcCommand.old);
			Processor.do_major();
			System.out.println("Register 37 change to: "+
				Utils.hexize( Memory.memory_read( temp ), 8));
//The format of the code depend on op*******************************
			if(Processor.op == 2){
				if(Processor.i_bit == 0){
					if(Processor.op3 == 16){
						System.out.println("addcc %r"+Processor.rs1+
						", %r"+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 17){
						System.out.println("andcc %r"+Processor.rs1+
						", %r"+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 18){
						System.out.println("orcc %r"+Processor.rs1+
						", %r"+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 22){
						System.out.println("orncc %r"+Processor.rs1+
						", %r"+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 38){
						System.out.println("srl %r"+Processor.rs1+
						", %r"+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 56){
						System.out.println("jump %r"+Processor.rs1+
						", %r"+Processor.rs2+", %r"+Processor.rd);
					}
				}
				else{
					if(Processor.op3 == 16){
						System.out.println("addcc %r"+Processor.rs1+
						", "+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 17){
						System.out.println("andcc %r"+Processor.rs1+
						", "+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 18){
						System.out.println("orcc %r"+Processor.rs1+
						", "+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 22){
						System.out.println("orncc %r"+Processor.rs1+
						", "+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 38){
						System.out.println("srl %r"+Processor.rs1+
						", "+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 56){
						System.out.println("jump %r"+Processor.rs1+
						", "+Processor.rs2+", %r"+Processor.rd);
					}
				}
			}
			if(Processor.op == 3){
				if(Processor.i_bit == 0){
					if(Processor.op3 == 0){
						System.out.println("ld "
						+Processor.rs2+", %r"+Processor.rd);
					}
					if(Processor.op3 == 4){
						System.out.println("st "
						+Processor.rs2+", %r"+Processor.rd);
					}
				}
				else{
					if(Processor.op3 == 0){
						System.out.println("ld "
						+Processor.simm13+", %r"+Processor.rd);
					}
					if(Processor.op3 == 4){
						System.out.println("st "
						+Processor.simm13+", %r"+Processor.rd);
					}
				}
			}
			if(Processor.op == 0){
				if(Processor.op2 == 2){
					System.out.println("branch ");				
				}
				if(Processor.op2 == 4){
					System.out.println("sethi "
					+Processor.imm22+", %r"+Processor.rd);						
				}
			}
//**********************************************************************
			System.out.println("C="+ALU.c+" "+"V="+ALU.v+" "+
				"N="+ALU.n+" "+"Z="+ALU.z);
			System.out.println("Register "+Processor.rd+" change to: "
				+Register.register[Processor.rd]);
			System.out.println("Register 32 change from "+
				temp+" to "+PcCommand.old);
			System.out.println();

		}
		catch (MemoryAccessException e1){
			System.err.println(e1);
			return;
		}

    }

  }