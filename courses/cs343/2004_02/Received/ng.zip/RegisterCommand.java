import java.util.Vector;

//  ClassRegisterCommand
//  ------------------------------------------------------------------
/**
 *  Process commands of the form, "register start [end]"
 */
  public class RegisterCommand implements Command
  {
    public void doit(Vector args)
    {
      int nargs = args.size();
      if ( (nargs < 1) || (nargs > 2) )
      {
        System.err.println( "Usage: register start [end]");
        return;
      }
      int first_reg, last_reg;
      try
      {
        first_reg  = Integer.parseInt( (String)args.elementAt(0), 10 );
        last_reg   = (nargs == 1) ? first_reg :
                     Integer.parseInt( (String)args.elementAt(1), 10 );
      }
      catch (NumberFormatException e)
      {
        System.err.println(e);
        return;
      }
      //  Print one register per line.
      long start_reg = first_reg;
      try
      {
        for (long reg = start_reg; reg <= last_reg; reg ++ )
        {

            System.out.print( "r["+reg+"]" + ": " );
      
          if ( reg < first_reg )
          {
            System.out.print( "         " );
          }
          else
          {
            System.out.println( " " +
                Utils.hexize( Register.register_read( (int) reg ), 8) );
          }

        }
        System.out.println();
      }
      catch (MemoryAccessException e1)
      {
        System.err.println(e1);
        return;
      }
    }
  }
