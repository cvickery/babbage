public class Processor{
  //  do_minor()
  //  ----------------------------------------------------------------
  /**
   *    Implements one clock cycle.
   * 
   *    @param    A_Reg   Register to place on the A-Bus
   *    @param    B_Reg   Register to place on the B-Bus
   *    @param    C_Reg   Register to receive result from the C-Bus
   *    @param    alu_func  4-bit ALU function code from Fig. 6-4
   *    @param    mem_op    2-bit Memory operation (nop, rd, wr)
   */
   public static int numMinor = 0;
   public static int numMajor = 0;
   private static int PC = 32;
   private static int R0 = 0;
   private static int IR = 37;
   private static int temp0 = 33;
   private static int temp1 = 34;
   private static int temp2 = 35;
    private static void do_minor( int A_Reg, int B_Reg,
                            int C_Reg, int alu_func, int mem_op)
                                       throws IllegalArgumentException
    {
      //  Validate Arguments
      if ( (A_Reg < 0) || (A_Reg > 37) )
        throw new IllegalArgumentException( 
                                "Invalid A Register (" + A_Reg + ")"); 
      if ( (B_Reg < 0) || (B_Reg > 37) )
        throw new IllegalArgumentException( 
                                "Invalid B Register (" + B_Reg + ")"); 
      if ( (C_Reg < 0) || (C_Reg > 37) )
        throw new IllegalArgumentException( 
                                "Invalid C Register (" + C_Reg + ")"); 
      if ( (alu_func < 0) || (alu_func > 15) )
        throw new IllegalArgumentException( 
                           "Invalid ALU Function (" + alu_func + ")"); 
      if ( (mem_op < 0) || (mem_op > 3) )
        throw new IllegalArgumentException( 
                         "Invalid Memory Operation (" + mem_op + ")"); 

      //  Compute the ALU result
      int alu_result = 0;
      switch ( alu_func )
      {
        case ALU.ANDCC:
          alu_result = 
                   ALU.do_andcc( Register.register[A_Reg], Register.register[B_Reg] );
          break;
		case ALU.ORCC:
		  alu_result = 
				   ALU.do_orcc(Register.register[A_Reg], Register.register[B_Reg]);
		  break;
		case ALU.NORCC:
		  alu_result =
				   ALU.do_norcc(Register.register[A_Reg], Register.register[B_Reg]);
		  break;
		case ALU.ADDCC:
		  alu_result =
			       ALU.do_addcc(Register.register[A_Reg], Register.register[B_Reg]);
		  break;
		case ALU.SRL:
		  alu_result = 
				   ALU.do_srl(Register.register[A_Reg], Register.register[B_Reg]);
		  break;
		case ALU.AND:
		  alu_result = 
				   ALU.do_and(Register.register[A_Reg], Register.register[B_Reg]);
		  break;
		case ALU.OR:
		  alu_result = 
				   ALU.do_or(Register.register[A_Reg], Register.register[B_Reg]);
		case ALU.NOR:
		  alu_result = 
				   ALU.do_nor(Register.register[A_Reg], Register.register[B_Reg]);
		  break;
		case ALU.ADD:
		  alu_result = 
				   ALU.do_add(Register.register[A_Reg], Register.register[B_Reg]);
			break;
		case ALU.LSHIFT2:
		  alu_result = 
				   ALU.do_lshift2(Register.register[A_Reg]);
		  break;
		case ALU.LSHIFT10:
		  alu_result = 
				   ALU.do_lshift10(Register.register[A_Reg]);
		  break;
		case ALU.SIMM13:
		  alu_result = 
				   ALU.do_simm13(Register.register[A_Reg]);
		  break;
		case ALU.SEXT13:
		  alu_result = 
				   ALU.do_sext13(Register.register[A_Reg]);
		  break;
		case ALU.INC:
		  alu_result = 
				   ALU.do_inc(Register.register[A_Reg]);
		  break;
		case ALU.INCPC:
		  PcCommand.old += 4;
		  break;
		case ALU.RSHIFT5:
		  alu_result = 
				   ALU.do_rshift5(Register.register[A_Reg]);
		  break;
	  }
	  switch(mem_op){
		 case Memory.read:
			 try{
			   Register.register[C_Reg] = Memory.memory_read(
								Register.register[A_Reg]);
		     }
			 catch (MemoryAccessException e1){
               System.err.println(e1);
			 }
		  	 break;
		 case Memory.write:
			 try{
			   Memory.memory_write(Register.register[A_Reg], 
				  Register.register[B_Reg]);
		     }
	         catch (MemoryAccessException e1){
               System.err.println(e1);
			 }
			 break;
		 case Memory.nop:
			 Register.register[C_Reg] = alu_result;
		     break;
	  }
	  //  Update the count of minor cycles and return.
      numMinor++;
      return;
    }

  //  do_major()
  //  ----------------------------------------------------------------
  /**
   *    Fetches and executes a single ISA level instruction.
   * 
   *    @return   True if an instruction was executed successfully,
   *              and returns false if the op code was invalid, nop,
   *              or halt. 
   */
    public static boolean do_major()
    {
     try
    {
        fetch();
        decode();
        if ( execute() )
        {
          update_pc();
        }

        //  Update the count of major cycles and return.      
        numMajor++;
        return true;
      }
      catch (UnimplementedOpCodeException e)
      {
      System.out.println( "UnimplementedOpCodeException: " + 
                                                      e.getMessage());
       return false;
      }
    }

    private static void fetch()
    {
     try{
	     do_minor( PC, R0, IR, ALU.AND, Memory.read );   

      }
      catch (IllegalArgumentException e)
      {
        System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	  }
	}
    //  Decoded instruction fields
    public static short op       = 0;
    public static short op2      = 0;
    public static short op3      = 0;
    public static short rs1      = 0;
    public static short rs2      = 0;
    public static short rd       = 0;
    public static short i_bit    = 0;
    public static short simm13   = 0;
    public static short imm22    = 0;
    public static short disp22   = 0;
    public static short disp30   = 0;
    public static short cond     = 0;
    public static short op_code  = 0;

    private static void decode(){
      op      = (short)((Register.register[IR] >> 30) & 0x003);
      op2     = (short)((Register.register[IR] >> 22) & 0x007);
      op3     = (short)((Register.register[IR] >> 19) & 0x03F);
	  rs1     = (short)((Register.register[IR] >> 14) & 0x01F);
	  rs2     = (short)((Register.register[IR]) & 0x01F);
	  rd      = (short)((Register.register[IR] >> 25) & 0x01F);
	  i_bit   = (short)((Register.register[IR] >> 13) & 0x001);
	  simm13  = (short)((Register.register[IR]) & 0xFFF);
	  imm22   = (short)((Register.register[IR]) & 0x1FFFFF);
	  disp22  = (short)((Register.register[IR]) & 0x1FFFFF);
	  disp30  = (short)((Register.register[IR]) & 0x1FFFFFFF);
	  cond    = (short)((Register.register[IR] >> 25) & 0x00F);
	  op_code = (short)((op << 6) | op3);
	}

  //  update_pc()
  //  ----------------------------------------------------------------
  //
  //    Adds 4 to the Program Counter.
  //
    private static void update_pc()
    {
     try{
        do_minor( PC, R0, PC, ALU.INCPC, Memory.nop );
      }
      catch (IllegalArgumentException e)
      {
        System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	  }
    }

    public static final short nop     = 0x00; // 00 000 000
    public static final short sethi   = 0x20; // 00 100 xxx
    public static final short branch  = 0x10; // 00 010 xxx
    public static final short call    = 0x40; // 01 xxx xxx
    public static final short addcc   = 0x90; // 10 010 000
    public static final short andcc   = 0x91; // 10 010 001
    public static final short orcc    = 0x92; // 10 010 010
    public static final short orncc   = 0x96; // 10 010 110
    public static final short srl     = 0xA6; // 10 100 110
    public static final short jmpl    = 0xB8; // 10 111 000
    public static final short ld      = 0xC0; // 11 000 000
    public static final short st      = 0xC4; // 11 000 100

  //  execute()
  //  ----------------------------------------------------------------
  //
  //    Executes a decoded instruction.
  // 
  //    @return   True if PC is to be incremented, or false if not.
  //    @throws   UnimplementedOpCodeException if op code is not
  //              implemented.
  //
    private static boolean execute()
                                   throws UnimplementedOpCodeException
    {
//      if ( Options.doTraceInstructions() )
//      {
//        System.out.println( Disassemble.dasm());
//      }
      switch ( op_code )
      {
        case  addcc:
        {     
		  try{
           if ( i_bit == 0 )
           {
            do_minor( rs1, rs2, rd, ALU.ADDCC, Memory.nop );
            return true;
           }
           else
           {
            do_minor( IR, R0, temp0, ALU.SEXT13, Memory.nop );
            do_minor( rs1, temp0, rd, ALU.ADDCC, Memory.nop );
            return true;
           }
		  }
		  catch (IllegalArgumentException e){
            System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	      }
		  }//end addcc
//          case nop:
		  case sethi:
			try{
				do_minor( IR, R0, temp0, ALU.LSHIFT10, Memory.nop );
				do_minor( temp0, rd, rd, ALU.ADD, Memory.nop );
				return true;
			}
		    catch (IllegalArgumentException e){
            System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	        }
//		  case branch:
//		  case call:
		  case andcc:
		    try{
              if ( i_bit == 0 ){
				do_minor( rs1, rs2, rd, ALU.ANDCC, Memory.nop );
              return true;
              }
              else{
				do_minor( IR, R0, temp0, ALU.SEXT13, Memory.nop );
				do_minor( rs1, temp0, rd, ALU.ANDCC, Memory.nop );
               return true;
               }
		    }
		    catch (IllegalArgumentException e){
              System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	        }  
		  case orcc:
		    try{
              if ( i_bit == 0 ){
				do_minor( rs1, rs2, rd, ALU.ORCC, Memory.nop );
              return true;
              }
              else{
				do_minor( IR, R0, temp0, ALU.SEXT13, Memory.nop );
				do_minor( rs1, temp0, rd, ALU.ORCC, Memory.nop );
               return true;
               }
		    }
		    catch (IllegalArgumentException e){
              System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	        }  
		  case orncc:
		    try{
              if ( i_bit == 0 ){
				do_minor( rs1, rs2, rd, ALU.NORCC, Memory.nop );
              return true;
              }
              else{
				do_minor( IR, R0, temp0, ALU.SEXT13, Memory.nop );
				do_minor( rs1, temp0, rd, ALU.NORCC, Memory.nop );
               return true;
               }
		    }
		    catch (IllegalArgumentException e){
              System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	        }  
		  case srl:
		    try{
              if ( i_bit == 0 ){
				do_minor( rs1, rs2, rd, ALU.SRL, Memory.nop );
              return true;
              }
              else{
				do_minor( IR, R0, temp0, ALU.SEXT13, Memory.nop );
				do_minor( rs1, temp0, rd, ALU.SRL, Memory.nop );
               return true;
               }
		    }
		    catch (IllegalArgumentException e){
              System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	        }  
//		  case jmpl:
		  case ld:
			try{
			  if(i_bit == 1){
				do_minor( IR, R0, temp0, ALU.SEXT13, Memory.nop );
				do_minor( rs1, temp0, temp1, ALU.ADD, Memory.nop );
				//??need to store the value to the EA address??
				do_minor( temp1, temp1, rd, ALU.AND, Memory.write );
				do_minor( temp1, R0, rd, ALU.AND, Memory.read );
				return true;
			  }
			  else{
				do_minor( rs1, rs2, temp1, ALU.ADD, Memory.nop );
				do_minor( temp1, R0, rd, ALU.AND, Memory.read );
				return true;
			  }
			}
		    catch (IllegalArgumentException e){
            System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	      }
		  case st:
			try{
			  //st[10], %r1
			  if(i_bit == 1){
				  //cal the EA address
				do_minor( IR, R0, temp0, ALU.SEXT13, Memory.nop );
				//rs1+sext13
				do_minor( rs1, temp0, temp1, ALU.ADD, Memory.nop );
				//put temp1 to EA address
				do_minor( temp1, temp1, rd, ALU.AND, Memory.write );
				return true;
			  }
			  else{
				//st[%r1], %r2
				do_minor( rs1, rs2, temp1, ALU.ADD, Memory.nop );
				//st rs1 value to EA address
				do_minor( temp1, rs1, rd, ALU.AND, Memory.write );
				return true;
			  }
			}
		    catch (IllegalArgumentException e){
            System.out.println( "IllegalArgumentException: " + 
                                                      e.getMessage());
	      }
        default:
        {
          throw new UnimplementedOpCodeException( "ERROR");
        }
      }
    }

}