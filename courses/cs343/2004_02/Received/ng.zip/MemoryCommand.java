/*  $Id: MemoryCommand.java,v 1.1 2004/03/26 02:43:20 vickery Exp $
 * Created on Mar 25, 2004
 *
 *  Copyright (c) 2004, Queens College of the City University
 *  of New York.  All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or
 *  without modification, are permitted provided that the
 *  following conditions are met:
 *
 *      * Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the
 *        following disclaimer.
 * 
 *      * Redistributions in binary form must reproduce the
 *        above copyright notice, this list of conditions and
 *        the following disclaimer in the documentation and/or
 *        other materials provided with the distribution.  
 * 
 *      * Neither the name of Queens College of CUNY
 *        nor the names of its contributors may be used to
 *        endorse or promote products derived from this
 *        software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *  CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 *    $Log: MemoryCommand.java,v $
 *    Revision 1.1  2004/03/26 02:43:20  vickery
 *    Implemented class Memory and the memory command.
 *    Completed implementation of the Load command.
 *
 */
import java.util.Vector;

//  Class MemoryCommand
//  ------------------------------------------------------------------
/**
 *  Process commands of the form, "memory start [end]"
 */
  public class MemoryCommand implements Command
  {
    public void doit(Vector args)
    {
      int nargs = args.size();
      if ( (nargs < 1) || (nargs > 2) )
      {
        System.err.println( "Usage: memory start [end]");
        return;
      }
      long first_addr, last_addr;
      try
      {
        first_addr  = Long.parseLong( (String)args.elementAt(0), 16 );
        last_addr   = (nargs == 1) ? first_addr :
                      Long.parseLong( (String)args.elementAt(1), 16 );
      }
      catch (NumberFormatException e)
      {
        System.err.println(e);
        return;
      }
      //  Print four words per line.
      long start_addr = first_addr & 0x0FFFFFFF0L;
      try
      {
        for (long addr = start_addr; addr <= last_addr; addr += 4 )
        {
          if ( (addr%16) == 0 )
          {
            System.out.print( Utils.hexize(addr, 8) + ": " );
          }
          if ( addr < first_addr )
          {
            System.out.print( "         " );
          }
          else
          {
            System.out.print( " " +
                Utils.hexize( Memory.memory_read( (int) addr ), 8) );
          }
          if ( (addr & 0x0CL) == 0x0Cl )
          {
            System.out.println();
          }
        }
        System.out.println();
      }
      catch (MemoryAccessException e1)
      {
        System.err.println(e1);
        return;
      }
    }
  }
