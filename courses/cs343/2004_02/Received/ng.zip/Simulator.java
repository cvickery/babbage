/*  $Id: Simulator.java,v 1.2 2004/03/26 02:43:20 vickery Exp $
 * Created on Mar 20, 2004
 *
 *  Copyright (c) 2004, Queens College of the City University
 *  of New York.  All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or
 *  without modification, are permitted provided that the
 *  following conditions are met:
 *
 *      * Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the
 *        following disclaimer.
 * 
 *      * Redistributions in binary form must reproduce the
 *        above copyright notice, this list of conditions and
 *        the following disclaimer in the documentation and/or
 *        other materials provided with the distribution.  
 * 
 *      * Neither the name of Queens College of CUNY
 *        nor the names of its contributors may be used to
 *        endorse or promote products derived from this
 *        software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *  CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 *  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
 *  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 *    $Log: Simulator.java,v $
 *    Revision 1.2  2004/03/26 02:43:20  vickery
 *    Implemented class Memory and the memory command.
 *    Completed implementation of the Load command.
 *
 *    Revision 1.1  2004/03/21 03:50:05  vickery
 *    Initial version of student simulator project for CS-343.
 *
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;

//  Class Simulator
//  -------------------------------------------------------------------
/**
 *    Executes user commands interactively.
 */
public class Simulator
{
  //  Create command processors
  static Command load     = new LoadCommand();
  static Command memory   = new MemoryCommand();
  static Command pc       = new PcCommand();
  static Command quit     = new QuitCommand();
  static Command register = new RegisterCommand();
  static Command run      = new RunCommand();
  static Command step     = new StepCommand();

  //  Dispatch Table for invoking possible commands.
  static DispatchEntry dispatchTable[] =
  {
    new DispatchEntry( "quit",      quit      ),
    new DispatchEntry( "q",         quit      ),
    new DispatchEntry( "load",      load      ),
    new DispatchEntry( "l",         load      ),
    new DispatchEntry( "memory",    memory    ),
    new DispatchEntry( "m",         memory    ),
    new DispatchEntry( "register",  register  ),
    new DispatchEntry( "re",        register  ),
    new DispatchEntry( "run",       run       ),
    new DispatchEntry( "r",         run       ),
    new DispatchEntry( "step",      step      ),
    new DispatchEntry( "s",         step      ),
    new DispatchEntry( "pc",        pc        ),
    new DispatchEntry( "p",         pc        ),
  };

  //  main()
  //  ----------------------------------------------------------------
  /*
   *    Reads command lines and executes them.
   * 
   *    @param  args  Not used.
   */
  public static void main(String[] argv) throws MemoryAccessException
  {
    //  Create memory array.
    Memory.memory_init( 100000 );
	// create register array.
	Register.register_init();
    //  Read command lines from stdin and execute them
    BufferedReader br = new BufferedReader(
                                 new InputStreamReader( System.in ) );
    String inBuf = null;

    while ( true )
    {
      try
      {
        //  Prompt for and read a command line
        System.out.print( "Command: " );
        inBuf = br.readLine();
      }
      catch (IOException e)
      {
        System.err.println(e);
        System.exit( 1 );
      }
      
      //  Tokenize the command line
      StringTokenizer st = new StringTokenizer( inBuf, " \t\r\n" );
      String cmd_name = st.hasMoreTokens() ? st.nextToken() : null;
      if ( cmd_name == null )
      {
        continue;   //  Ignore blank lines.
      }
      Vector  args = new Vector();
      while ( st.hasMoreTokens() )
      {
        args.addElement( st.nextElement() );
      }
      
      //  Look up the command name in the dispatch table and invoke the
      //  command's doit() method to process the command.
      boolean found = false;
      for (int i = 0; i < dispatchTable.length; i++ )
      {
        if ( dispatchTable[i].name.equalsIgnoreCase( cmd_name ) )
        {
          dispatchTable[i].command.doit( args );
          found = true;
        }
      }
      if ( ! found )
      {
        System.err.println( "Unrecognized command: " + cmd_name );
      }
    }
  }
}
