//  Class Register
//  ------------------------------------------------------------------
/**
 *    Provides the simulated memory for the ARC simulator.
 */
  public class Register
  {
    public static int[] register = null;

    //  Constructor
    //  --------------------------------------------------------------
    /**
     *    This class can't be instantiated.  Use memory_init()
     *    instead.
     */    
      private Register() {} //Private no-arg constructor.
      
    //  memory_init()
    //  --------------------------------------------------------------
    /**
     *    Instantiate the memory array.
     */
      public static void register_init()
      {
        register = new int[ 38 ];
		register [0] = 0;
        return;
      }
      
    //  register_read()
    //  --------------------------------------------------------------
    /**
     *    Read from the memory array.
     */
      public static int register_read( int register_num )
                                          throws MemoryAccessException
      {
        if ( register == null )
        {
          throw new RuntimeException( 
         "Attempt to read from register before calling register_init()" );
        }

		return register[register_num];
      }
      
    //  register_write()
    //  --------------------------------------------------------------
    /**
     *    write to the register array.
     */
      public static void register_write( int register_num, int data )
                                          throws MemoryAccessException
      {
        if ( register == null )
        {
          throw new RuntimeException( 
          "Attempt to write to register before calling register_init()" );
        }

        if ( register_num == 0 )
        {
			register[ register_num ] = 0x00000000;
        }
        if ( register_num > register.length - 1 )
        {
          throw new MemoryAccessException(
                  "Attempt to write above top of simulated register." );
        }
        register[ register_num ] = data;
        return;
      }
      
  }