import java.util.Vector;

//  Class Pc
//  ------------------------------------------------------------------
/**
 *  Process commands of the form, "pc(byte_address)"
 */
  public class PcCommand implements Command
  {
	public static int old;
	public void doit(Vector args)
    {
	  int nargs = args.size();
      if ( nargs != 1 )
      {
        System.err.println( "Usage: Pc byte address");
        return;
      }
	  long byte_addr;
      try
      {
        byte_addr  = Long.parseLong( (String)args.elementAt(0), 16 );
      }
      catch (NumberFormatException e)
      {
        System.err.println(e);
        return;
      }
	  try{
		  Register.register_write(32, Memory.memory_read((int)byte_addr));
		  System.out.println("old value: "+old +" "+" new value: "+byte_addr);
	  }
      catch (MemoryAccessException e1)
      {
        System.err.println(e1);
        return;
      }
	  old = (int)byte_addr;
	}

  }