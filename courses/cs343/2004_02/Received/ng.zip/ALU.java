public class ALU{
	public static boolean c;
	public static boolean v;
	public static boolean n;
	public static boolean z;
	public static final int ANDCC = 0;
	public static final int ORCC =1;
	public static final int NORCC = 2;
	public static final int ADDCC = 3;
	public static final int SRL = 4;
	public static final int AND = 5;
	public static final int OR = 6;
	public static final int NOR = 7;
	public static final int ADD = 8;
	public static final int LSHIFT2 = 9;
	public static final int LSHIFT10 = 10;
	public static final int SIMM13 = 11;
	public static final int SEXT13 = 12;
	public static final int INC = 13;
	public static final int INCPC = 14;
	public static final int RSHIFT5 = 15;
	public static int do_andcc(int A_Bus, int B_Bus){
		c = false;
		v = false;
		n = (A_Bus & B_Bus)<0 ;
		z = (0 == (A_Bus & B_Bus));
		return A_Bus & B_Bus;
	}
	public static int do_orcc(int A_Bus, int B_Bus){
		c = false;
		v = false;
		n = (A_Bus | B_Bus)<0 ;
		z = (0 == (A_Bus | B_Bus));
		return A_Bus | B_Bus;
	}
	public static int do_norcc(int A_Bus, int B_Bus){
		return A_Bus | B_Bus;
	}
	public static int do_addcc(int A_Bus, int B_Bus){
		c = ((A_Bus<0) && (B_Bus<0)) || 
			((A_Bus<0) && (B_Bus>0)) && ((A_Bus + B_Bus)>0) ||
			((A_Bus>0) && (B_Bus<0)) && ((A_Bus + B_Bus)>0);
		v = ((A_Bus>0) && (B_Bus>0) && ((A_Bus + B_Bus)<0)) ||
			((A_Bus<0) && (B_Bus<0) && ((A_Bus + B_Bus)>0));
		n = (A_Bus + B_Bus)<0 ;
		z = (0 == (A_Bus + B_Bus));
		return A_Bus + B_Bus;
	}
	public static int do_srl(int A_Bus, int B_Bus){
		return A_Bus >> B_Bus;
	}
	public static int do_and(int A_Bus, int B_Bus){
		return A_Bus & B_Bus;
	}
	public static int do_or(int A_Bus, int B_Bus){
		return A_Bus | B_Bus;
	}
	public static int do_nor(int A_Bus, int B_Bus){
		return A_Bus | B_Bus;
	}
	public static int do_add(int A_Bus, int B_Bus){
		return A_Bus + B_Bus;
	}
	public static int do_lshift2(int A_Bus){
		return A_Bus << 2;
	}
	public static int do_lshift10(int A_Bus){
		return A_Bus << 10;
	}
	public static int do_simm13(int A_Bus){
		return A_Bus & 0x1FFF;
	}
	public static int do_sext13(int A_Bus){
		if((A_Bus << 19) < 0){
			return (A_Bus | 0xFFFFE000);
		}
		else{
			return A_Bus & 0x1FFF;
		}
	}
	public static int do_inc(int A_Bus){
		return A_Bus + 1;
	}
	public static int do_incpc(int A_Bus){
		return A_Bus + 4;
	}
	public static int do_rshift5(int A_Bus){
		if(A_Bus >= 0)
			return (A_Bus>>5) + 0x00000000;
		else return (A_Bus>>5) + 0xF8000000;
	}

}