//  GUI.java
//

import java.io.*;
import java.awt.*;
import java.awt.event.*;

//  class GUI
//  -----------------------------------------------------------------
/**
  *   This is class constructs the User Interface for the program,
  *   but it is not the user interface itself.  Instead it creates
  *   a Frame (actually, a WF_Frame) for the user interface.
  *
  */
public class GUI extends  WindowAdapter
                          implements ActionListener {

static WF_Frame wff;
static Puzzle   p;

  //  main()
  //  ---------------------------------------------------------------
  /**
    *   This is the entry point for running the GUI version of the
    *   WordFind application.
    *
    */
  public static void main( String[] args ) {

    //  Create a Frame for each Puzzle named on the command line
    for ( int i = 0; i < args.length; i++ ) {
      try {
        p = new Puzzle( args[i] );
        wff = new WF_Frame("WordFind Puzzle: " + args[i], p);
        wff.setLocation(60 + 30 * i, 60 + 30 * i);
        }
      catch (Exception e ) {
        System.err.println( e.getMessage() );
        }

      }


    //  Put up a Frame with a Quit button.
    if ( wff != null ) {

      GUI g = new GUI();
      Frame exit = new Frame( "WordFind" );
      exit.addWindowListener( g );

      Button quitButton = new Button( "Quit" );
      exit.add( quitButton, BorderLayout.SOUTH);
      quitButton.addActionListener( g );

      Button dumpButton = new Button( "Dump" );
//      exit.add( dumpButton, BorderLayout.NORTH);
      dumpButton.addActionListener( g );

      exit.pack();
      exit.show();

      }

    else

      System.exit( 0 );

    }


  //  windowClosing()
  //  ---------------------------------------------------------------
  /**
    *   Terminate the app if the user clicks the Frame's close
    *   button.
    */
  public void windowClosing( WindowEvent e ) {

    System.exit( 0 );

    }
    

  //  actionPerformed()
  //  ---------------------------------------------------------------
  /**
    *   Handle the Quit and Dump buttons.
    *
    */
  public void actionPerformed(ActionEvent e) {

    if ( e.getActionCommand().equals( "Dump" ) )
      wff.eh();
    else
      System.exit(0);

    }

  }
