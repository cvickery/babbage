//  $Id$
//
//    Graphical UI for WordFind Project 2
//    CS-101, Spring 1998
//    @author C. Vickery
//

import java.awt.*;
import java.awt.event.*;
import java.util.*;

//  class WF_Frame
//  -----------------------------------------------------------------
/**
  *   This class provides a window for the user interface for one
  *   Puzzle.
  *
  */
class WF_Frame  extends Frame
                implements ItemListener {

private Puzzle    p;
private List      l;
private P_Canvas  pc;
private Hashtable ht = new Hashtable();   // Highlighted?
private Boolean   T = new Boolean( true ),
                  F = new Boolean( false );

  //  Constructor
  //  ---------------------------------------------------------------
  /**
    *   The applet or application that constructs this Frame must
    *   supply a String to be used in the title bar, and a reference
    *   to the Puzzle to be used in the Frame.
    *
    */
  public WF_Frame( String title, Puzzle p ) {

    super( title );
    addNotify();  // Create peer, establishing insets.

  Vector      v = p.getWordList();
  Enumeration e = v.elements();
  String      aWord;

    //  Make this window disappear if user closes it.
    addWindowListener( new WL( this ) );
    this.p = p;

    //  Create a Canvas to hold the Puzzle
    pc = new P_Canvas( p.getPuzzle() );
    add( pc, BorderLayout.NORTH );

    //  Create a List box to hold the word list, and populate it.
    l = new List( Math.min( v.size(), 6 ), true);
    while ( e.hasMoreElements() ) {
      aWord = (String) e.nextElement();
      l.addItem( aWord );
      ht.put( aWord, F );
      }
    add( l, BorderLayout.CENTER );
    l.addItemListener( this );

    //  Do layout, and display the results.
    pack();
    show();

    }


  //  itemStateChanged()
  //  -----------------------------------------------------------------
  /**
    *   If a word in the List is selected or unselected, tell the
    *   Canvas to highlight or unhighlight it.  There were problems
    *   when the user clicked too fast -- the highlight/unhighlight
    *   calls got out of sync with the state of the item on the list,
    *   so I added a Hashtable to keep track of whether a word is
    *   currently hightlighted or not, and only highlight it if it
    *   is presently unhighlighted, and vice-versa.
    *
    */
  public void itemStateChanged(ItemEvent e) {

  int r2, c2;
  Integer index   = (Integer) e.getItem();
  String  theWord = (String) p.getWordList().elementAt( index.intValue() );
  Answer  a       = p.findWord( theWord );

    //  Calculate ending position
    r2 = a.row +
          Direction.deltaY[a.direction.intValue()] * ( theWord.length() - 1 );
    c2 = a.col +
          Direction.deltaX[a.direction.intValue()] * ( theWord.length() - 1 );

if (e.getID() != ItemEvent.ITEM_STATE_CHANGED) {
  System.err.println( "Unexpected ItemEvent: " + e );
  return;
  }
    //  Highlight or Unhighlight -- ignore extraneous requests.
    if ( e.getStateChange() == ItemEvent.SELECTED ) {

      if ( F.equals( ht.get(theWord) ) ) {

        pc.highlight(a.row, a.col, r2, c2);
        ht.put(theWord, T);

        }

      }

    else {

      if ( T.equals( ht.get( theWord ) ) ) {

        pc.unhighlight(a.row, a.col, r2, c2);
        ht.put(theWord, F);

        }

      }
    pc.repaint();

    }

  //  eh()
  //  ---------------------------------------------------------------
  /**
    *   Debugging interface to the canvas.
    */
  public void eh(){pc.showHighlight();}

  }



