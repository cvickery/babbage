//  AGUI.java
//
//    Applet version of the WordFind puzzle project.
//
//    @author C. Vickery
//

import java.applet.*;
import java.awt.*;

public class AGUI extends Applet {

private WF_Frame  wff;
private Puzzle    p;

  public void init() {

    try {
      p = new Puzzle( this );
      wff = new WF_Frame( p.getPuzzleName(), p );
      }
    catch (Exception e) {
    
      add (new Label() );
      add (new Label( e.getMessage() ) );
      
      }

    add (new Label( " WordFind: " + p.getPuzzleName() ) );      
//    resize( 100, 100 );

    }
    
  }