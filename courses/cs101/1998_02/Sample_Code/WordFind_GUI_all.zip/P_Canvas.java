//  P_Canvas.java
//

import java.awt.*;

public class P_Canvas extends Component {

private char[][]    theChars;
private int[][]     highlight;
private int         numRows, numCols;
private char[]      aChar = new char[ 1 ];

private Font        nFont = new Font("Monospaced", Font.PLAIN, 20);
private Font        bFont = new Font("Monospaced", Font.BOLD, 20);
private FontMetrics fm = getFontMetrics( nFont );

private int         cellHeight, cellWidth, cellPad=5;

  public P_Canvas( char[][] c ) {

    theChars = c;
    numRows = theChars.length;
    numCols = theChars[0].length;
    highlight = new int[numRows][numCols];
    setFont( nFont );
    cellHeight = fm.getHeight() + 2 * cellPad;
    cellWidth  = fm.charWidth( 'W' ) + 2 * cellPad;
    setSize( 50 + cellWidth * numCols, 50 + cellHeight * numRows );


    }

  //  getPreferredSize()
  //  ---------------------------------------------------------------
  /**
    *   Report this component's preferred size.  Must be provided to
    *   make this class compatible with Canvas, at least for current
    *   implementations.
    */
  public Dimension getPreferredSize() {

    return new Dimension( 50 + cellWidth * numCols, 50 + cellHeight * numRows);

    }

  //  paint()
  //  ---------------------------------------------------------------
  /**
    *   Draw the grid to hold the letters, and draw the letters in
    *   their boxes.
    */
  public void paint( Graphics g ) {

    //  Draw the grid
    for (int row = 0; row <= numRows; row++)
      g.drawLine( 25,                       25 + cellHeight * row,
                  25 + cellWidth * numCols, 25 + cellHeight * row);
    for (int col = 0; col <= numCols; col++)
      g.drawLine( 25 + cellWidth * col, 25,
                  25 + cellWidth * col, 25 + cellHeight * numRows);

    //  Draw each character
    for (int row = 0; row < numRows; row++) {

      for (int col = 0; col < numCols; col++) {

        aChar[0] = theChars[row][col];
        if (highlight[row][col] > 0) {
          g.setColor(Color.red);
          g.setFont( bFont );
          }
        else {
          g.setColor(Color.black);
          g.setFont(nFont);
          }
        g.drawChars(aChar, 0, 1,  25 + cellPad + cellWidth  * col,
                                  25 - cellPad + cellHeight * (1 +  row) );
        g.setColor(Color.black);
        }

      }

    }

public void showHighlight() {
  for (int i=0; i<numRows; i++) {
    for (int j=0; j <numCols; j++) {
      System.err.print(highlight[i][j]);
      }
    System.err.println();
    }
  System.err.println();
  }

  //  highlight()
  //  ---------------------------------------------------------------
  /**
    *   This is a wrapper for doHighlight().
    */
  public void highlight(int r1, int c1, int r2, int c2) {
    doHighlight(r1, c1, r2, c2, true);
    }

  //  unhighlight()
  //  ---------------------------------------------------------------
  /**
    *   This is a wrapper for doHighlight().
    */
  public void unhighlight(int r1, int c1, int r2, int c2) {
    doHighlight(r1, c1, r2, c2, false);
    }

  //  doHighlight()
  //  ---------------------------------------------------------------
  /**
    *   DDA algorithm for selecting cells to highlight or unhighlight.
    */
  private void doHighlight( int r1, int c1,
                            int r2, int c2, boolean val ) {

  int x, y, t, deltaY, deltaX;

    deltaY = r1 == r2 ? 0 : (r1 < r2 ? +1 : -1);
    deltaX = c1 == c2 ? 0 : (c1 < c2 ? +1 : -1);

    if ( deltaX != 0 ) {

      //  Not vertical
      if (c1 > c2) {
        // Right to left, so swap ends.
        t  = c1;
        c1 = c2;
        c2 = t;
        r1 = r2;
        deltaY = -deltaY;
        }

      y = r1;
      for (x = c1; x <= c2; x++) {

        highlight[y][x] += val ? +1 : -1;
        y += deltaY;

        }

      }

    else {
      
      // Vertical
      if (r1 > r2) {
        // Bottom to top, so swap ends.
        t  = r1;
        r1 = r2;
        r2 = t;
        }

      x = c1;
      for (y = r1; y <= r2; y++) {

        highlight[y][x] += val ? +1 : -1;

        }

      }
    }

  }