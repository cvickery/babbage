//  contours.js

//  Global Variables
//  ------------------------------------------------------------------
var gridSpacingInput      = null;
var contourIntervalInput  = null;
var firstElevationInput   = null;
var secondElevationInput  = null;
var slopePara             = null;
var numContourPara        = null;
var contourTableDiv       = null;
var contourPrecision      = 0;
var nsStr                 = "http://w3.org/1999/xhtml";
var newItem               = null;
var newText               = null;
var ContourTable          = new Object();

//  formatVal()
//  ------------------------------------------------------------------
/*    Generates a string representation of val with precision fraction
 *    digits.
 */
  function formatVal( val, precision )
  {
    var p = Math.pow(10, precision);
    var v = Math.round(val * p) / p;
    var str = v.toString();
    
    var decIndex = str.indexOf('.');
    if ((precision > 0) && decIndex < 0)
    {
      decIndex = str.length;
      str += '.';
    }
    while (decIndex + precision + 1 > str.length)
    {
      str += '0';
    }
    return str;
  }

//  eventHandler()
//  ------------------------------------------------------------------
/*    Responds to all user input events: changes to values of the
 *    text fields, and all Enter keystrokes.
 */
  function eventHandler( evt )
  {
  //  Numeric values for:
  /*  gridSpacingInput, contourIntervalInput, firstElevationInput,
   *  secondElevationInput
   *  Generate a new table if all parameters are defined.
   */
    var gridVal, contourInterval, firstVal, secondVal;

    if (  (gridSpacingInput.value != null) && 
          (gridSpacingInput.textLength != 0) )
    {
      gridVal = parseFloat(gridSpacingInput.value);
      if ( isNaN(gridVal) || (Math.abs(gridVal) < 1e-4) )
      {
        return;
      }
    }
    else
    {
      return;
    }

    if (  (contourIntervalInput.value != null) &&
          (contourIntervalInput.textLength != 0) )
    {
      contourInterval = parseFloat(contourIntervalInput.value);
      if ( isNaN(contourInterval) )
      {
        return;
      }
      var decIndex = contourIntervalInput.value.indexOf('.');
      if (decIndex < 0)
      {
        contourPrecision = 0;
      }
      else
      {
        contourPrecision = contourIntervalInput.value.length - decIndex - 1;
      }
    }
    else
    {
      return;
    }

    if (  (firstElevationInput.value != null) &&
          (firstElevationInput.textLength != 0) )
    {
      firstVal = parseFloat(firstElevationInput.value);
      if (isNaN(firstVal))
      {
        return;
      }
    }
    else
    {
      return;
    }
    if (  (secondElevationInput.value != null) &&
          (secondElevationInput.textLength != 0) )
    {
      secondVal = parseFloat(secondElevationInput.value);
      if (isNaN(secondVal))
      {
        return;
      }
    }
    else
    {
      return;
    }

    //  Generate Results
    //  --------------------------------------------------------------
    var low = firstVal, high = secondVal;
    var lowStr = 'Distance from ' + firstVal;

    if (low > high)
    {
      low   = secondVal;
      lowStr  = 'Distance from ' + secondVal;
      high  = firstVal;
    }

    //  Slope
    var slopeVal = (high - low) / gridVal;
    var slopeStr = formatVal(slopeVal, 3);
    var str = "The slope is (";
    str = str + high + " - " + low + ") / " + gridVal + " = " +
          slopeStr + ".";
    slopePara.nodeValue = str;

    //  Remove previous table of contours and create a new one.
    while (contourTableDiv.firstChild != null)
    {
      contourTableDiv.removeChild(contourTableDiv.firstChild);
    }
    var contourTable = document.createElement('table');
    var contourTableBody = document.createElement('tbody');

    //  Heading Row	
    newRow = document.createElement('tr');
    newCol = document.createElement('th');
    newCol.appendChild(document.createTextNode('Elevation'));
    newRow.appendChild(newCol);
    newCol = document.createElement('th');
    newCol.appendChild(document.createTextNode('Proportion'));
    newRow.appendChild(newCol);
    newCol = document.createElement('th');
    newCol.appendChild(document.createTextNode(lowStr));
    newRow.appendChild(newCol);
    contourTableBody.appendChild(newRow);

    //  Body Rows
    var numContours = 0;
    var thisContour = Math.ceil(low / contourInterval) * contourInterval;
    if ( high > low ) //  Skip data rows if endpoints are the same
    {
      //  Generate data rows
      while (thisContour <= high)
      {
        var proportion = (thisContour - low) / (high - low);
        var contourStr = formatVal(thisContour, contourPrecision);
        var proportionStr = formatVal(proportion, 3);
        var distanceStr   = formatVal(proportion * gridVal, 3);

        newRow = document.createElement('tr');

        newCol = document.createElement('td');
        newText = document.createTextNode(contourStr);
        newCol.appendChild(newText);
        newRow.appendChild(newCol);

        var proportionVal = (thisContour - low) / (high - low);
        var proportionStr = formatVal(proportionVal, 3);
        newCol = document.createElement('td');
        newText = document.createTextNode(proportionStr);
        newCol.appendChild(newText);
        newRow.appendChild(newCol);

        var distanceStr = formatVal(gridVal * proportionVal, 3);
        newCol = document.createElement('td');
        newText = document.createTextNode(distanceStr);
        newCol.appendChild(newText);
        newRow.appendChild(newCol);

        contourTableBody.appendChild(newRow);

        thisContour += contourInterval;
        numContours++;
      }

      contourTable.appendChild(contourTableBody);
      contourTableDiv.appendChild(contourTable);

      //  Check if there is a listener for table update events
      //  ----------------------------------------------------
      if (typeof ContourTable.notifyOnUpdate == "function")
      {
        ContourTable.notifyOnUpdate(contourTable);
      }
    }

    //  Number of Contours Paragraph
    switch (numContours)
    {
      case 0:   numContourPara.nodeValue = "There are no contour lines.";
                return;
      case 1:   numContourPara.nodeValue = "There is one contour line:";
                break;
      default:
      {
        var str = "There are " + numContours + " contour lines:";
        numContourPara.nodeValue = str;
      }
    }

    //  Display the results
    document.getElementById('slope').style.display = 'block';
    document.getElementById('num_contours').style.display = 'block';
    document.getElementById('contours').style.display = 'block';
  }


//  keyReleased()
//  ----------------------------------------------------------------
/*
 *    Check all keystrokes for Enter, and call the event handler to
 *    update the display when detected.
 */
  function keyReleased(evt)
  {
    evt = evt ? evt : window.event;
    //  ASCII code for Enter is 13.
    if (evt.keyCode == 13)
    {
      eventHandler(evt);
    }
  }

//  window.onload
//  ------------------------------------------------------------------
/*
 *    Initialize the application.
 */
  window.onload = function()
  {
    gridSpacingInput     = document.getElementById('grid_spacing');
    contourIntervalInput = document.getElementById('contour_interval');
    firstElevationInput  = document.getElementById('first_elevation');
    secondElevationInput = document.getElementById('second_elevation');

    slopePara       = document.getElementById('slope').firstChild;
    numContourPara  = document.getElementById('num_contours').firstChild;
    contourTableDiv = document.getElementById('contours');

    //  Set up event handlers using W3C model if possible.
    if (typeof gridSpacingInput.addEventListener != 'undefined')
    {
      gridSpacingInput    .addEventListener('change', eventHandler, false);
      contourIntervalInput.addEventListener('change', eventHandler, false);
      firstElevationInput .addEventListener('change', eventHandler, false);
      secondElevationInput.addEventListener('change', eventHandler, false);
      document.getElementsByTagName('body')[0]
                            .addEventListener('keyup', keyReleased, false);
    }
    else if (typeof gridSpacingInput.attachEvent != 'undefined')
    {
      //  Fall back to DOM 0 event handling model.
      gridSpacingInput    .attachEvent('onchange', eventHandler, false);
      contourIntervalInput.attachEvent('onchange', eventHandler, false);
      firstElevationInput .attachEvent('onchange', eventHandler, false);
      secondElevationInput.attachEvent('onchange', eventHandler, false);
      document.attachEvent('onkeyup', keyReleased, false);
    }
    else
    {
      alert("Sorry, this program does not work with your browser.");
    }
  };
